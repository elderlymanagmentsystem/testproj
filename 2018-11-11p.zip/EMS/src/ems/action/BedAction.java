package ems.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.BedBean;
import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneGrpBean;
import ems.db.EmsDB;
import ems.module.BedModule;
import ems.module.OrgModule;
import ems.module.UserModule;


public class BedAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private ZoneGrpBean zoneGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "010200";
	
	
	public String execute()
	{
		UserBean userBean = (UserBean)session.get("userBean");
		
		BedModule bedMod = new BedModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			bedMod.performEnqBed(zoneGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			bedMod.performAddZone(zoneGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			bedMod.performModZone(zoneGrpBean, userBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL)){
			bedMod.performDelZone(zoneGrpBean, userBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD_SUB)){
			bedMod.performAddBed(zoneGrpBean, userBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD_SUB)){
			bedMod.performModBed(zoneGrpBean, userBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL_SUB)){
			bedMod.performDelBed(zoneGrpBean, userBean);			
		}

		if(zoneGrpBean.getMsg()==null||zoneGrpBean.getMsg().length()==0) {
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("zoneGrpBean", zoneGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(zoneGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("zoneGrpBean", zoneGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(zoneGrpBean==null)
			zoneGrpBean = new ZoneGrpBean();
		
		for(int i=0;i<zoneGrpBean.getFields().size();i++){
			zoneGrpBean.getFields().get(i).setFormValue(request.getParameter(zoneGrpBean.getFields().get(i).getName()));
		}

		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {

			zoneGrpBean.setOrgId(userBean.getAccOrgId());
			
			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)) {
				if(!zoneGrpBean.validate())
					validated = false;
			}

			if((funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL)) && zoneGrpBean.getZoneId().length()==0) {
				zoneGrpBean.getField("ZON_ID").setMsg("必需輸入");
				zoneGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(!validated) {
				BedModule bedMod = new BedModule();
				bedMod.performEnqBed(zoneGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("zoneGrpBean", zoneGrpBean);
				addActionError(zoneGrpBean.getMsg());
			}			
			
			
		}else if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD_SUB) || funcId.substring(4).equals(EmsDB.FUNC_MOD_SUB) || funcId.substring(4).equals(EmsDB.FUNC_DEL_SUB))) {

			zoneGrpBean.setBedBeanList(new ArrayList<BedBean>());
			String[] tempBedIdList = request.getParameterValues("BED_ID");
			String[] tempBedNameList = request.getParameterValues("BED_NAME");
			
			if(zoneGrpBean.getZoneId().length()==0) {
				zoneGrpBean.getField("ZON_ID").setMsg("必需輸入");
				zoneGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(tempBedIdList!=null) {
				for(int i=0;i<tempBedIdList.length;i++) {
					BedBean tempBedBean = new BedBean();
					tempBedBean.setBedId(tempBedIdList[i]);
					tempBedBean.setZoneId(zoneGrpBean.getZoneId());
					tempBedBean.setOrgId(userBean.getOrgId());
					if(tempBedNameList!=null && tempBedNameList.length>i) {
						tempBedBean.setBedName(tempBedNameList[i]);
						
					}
					zoneGrpBean.addBedBeanList(tempBedBean);
				}
			}else if(tempBedNameList!=null){
				for(int i=0;i<tempBedNameList.length;i++) {
					BedBean tempBedBean = new BedBean();
					tempBedBean.setZoneId(zoneGrpBean.getZoneId());
					tempBedBean.setOrgId(userBean.getOrgId());
					tempBedBean.setBedName(tempBedNameList[i]);
					zoneGrpBean.addBedBeanList(tempBedBean);
				}
			}
			
			if(zoneGrpBean.getBedBeanList().size()==0) {
				zoneGrpBean.setMsg("輸入錯誤");
				validated = false;
			}
			
			if(!validated) {
				BedModule bedMod = new BedModule();
				bedMod.performEnqBed(zoneGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("zoneGrpBean", zoneGrpBean);
				addActionError(zoneGrpBean.getMsg());
			}			

		
		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
			
	}

	public ZoneGrpBean getZoneGrpBean() {
		return zoneGrpBean;
	}

	public void setOrgBean(ZoneGrpBean zoneGrpBean) {
		this.zoneGrpBean = zoneGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}


}
