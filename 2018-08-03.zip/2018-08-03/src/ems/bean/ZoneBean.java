package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class ZoneBean extends BasicBean {
	
	private ArrayList<BedBean> bedBeanList = new ArrayList<BedBean>();
		
	public ZoneBean() {
		for(int i=0; i<EmsDB.EM_ZON_ZONE.length;i++) {
			fields.add(new Field(EmsDB.EM_ZON_ZONE[i]));
		}
	}
	
	public String getZoneId() {
		return getField("ZON_ID").getFormValue();
	}
	public void setZoneId(String zoneId) {
		getField("ZON_ID").setFormValue(zoneId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getZoneName() {
		return getField("ZON_NAME").getFormValue();
	}
	public void setZoneName(String zoneName) {
		getField("ZON_NAME").setFormValue(zoneName);
	}
	
	
	public ArrayList<String> getBedIdList(){
		ArrayList<String> bedIdList = new ArrayList<String>();
		for(int i=0;i<bedBeanList.size();i++) {
			bedIdList.add(bedBeanList.get(i).getBedId());
		}
		
		return bedIdList;
	}
	
	public BedBean getBedBean(String bedId){
		for(int i=0;i<bedBeanList.size();i++) {
			if(bedId != null && bedId.equals(bedBeanList.get(i).getBedId())){
				return bedBeanList.get(i);
			}
		}
		return null;
	}	
	
	public void setBedBeanList(ArrayList<BedBean> bedBeanList) {
		this.bedBeanList = bedBeanList;
	}

	public ArrayList<BedBean> getBedBeanList() {
		return bedBeanList;
	}
	public void addBedBeanList(BedBean bedBean) {
		bedBeanList.add(bedBean);
	}



}
