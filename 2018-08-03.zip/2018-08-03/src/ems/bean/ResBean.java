package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class ResBean extends BasicBean {
	
	PerBean perBean = new PerBean();
	BedBean bedBean = new BedBean();
	
	public ResBean() {
		for(int i=0; i<EmsDB.EM_RES_RECORD.length;i++) {
			fields.add(new Field(EmsDB.EM_RES_RECORD[i]));
		}
	}
	
	public String getResId() {
		return getField("RES_ID").getFormValue();
	}
	public void setResId(String resId) {
		getField("RES_ID").setFormValue(resId);
	}

	public String getBedId() {
		return getField("BED_ID").getFormValue();
	}
	public void setBedId(String bedId) {
		getField("BED_ID").setFormValue(bedId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getZoneId() {
		return getField("ZON_ID").getFormValue();
	}
	public void setZoneId(String zoneId) {
		getField("ZON_ID").setFormValue(zoneId);
	}
	
	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}
	
	public PerBean getPerBean() {
		return perBean;
	}
	public void setPerBean(PerBean perBean) {
		this.perBean = perBean;
	}
	
	public BedBean getBedBean() {
		return bedBean;
	}
	public void setBedBean(BedBean bedBean) {
		this.bedBean = bedBean;
	}
	
	
}
