package ems.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.UserBean;
import ems.module.PatModule;

public class AjaxPatAction extends ActionSupport implements SessionAware {
	private PatGrpBean patGrpBean;
	private int enqPerId;
	private Map<String, Object> session;
	private String pcoChiName = "";
	private String pcoRel = "";
	private String pcoTel = "";
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(patGrpBean.getEnqPatId() != null && patGrpBean.getEnqPatId().length()>0)
			patMod.performEnqPatDetail(patGrpBean, userBean);
		
		if(patGrpBean.getPcoPerBeanList().size()>0) {
			setPcoChiName(patGrpBean.getPcoPerBeanList().get(0).getField("PER_CHI_NAME").getFormValue());
			setPcoTel(patGrpBean.getPcoPerBeanList().get(0).getField("PER_TEL").getFormValue());
			if(patGrpBean.getPcoRelList().size()>0)
				setPcoRel(patGrpBean.getPcoRelList().get(0));
		}
		
		return SUCCESS;
	}
	
	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public String getPcoChiName() {
		return pcoChiName;
	}

	public void setPcoChiName(String pcoChiName) {
		this.pcoChiName = pcoChiName;
	}

	public String getPcoRel() {
		return pcoRel;
	}

	public void setPcoRel(String pcoRel) {
		this.pcoRel = pcoRel;
	}

	public String getPcoTel() {
		return pcoTel;
	}

	public void setPcoTel(String pcoTel) {
		this.pcoTel = pcoTel;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	
	
}
