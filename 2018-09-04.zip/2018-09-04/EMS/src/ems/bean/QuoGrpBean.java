package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class QuoGrpBean extends PerBean {
	
	String enqPerType = "";
	String enqPerName = "";
	String enqPerId = "";
	
	private ArrayList<ZoneBean> zoneBeanList = new ArrayList<ZoneBean>();
	private ArrayList<PerBean> perBeanList = new ArrayList<PerBean>();
		
	public QuoGrpBean() {
	}
	

	public String getEnqPerType() {
		return enqPerType;
	}


	public void setEnqPerType(String enqPerType) {
		this.enqPerType = enqPerType;
	}


	public String getEnqPerName() {
		return enqPerName;
	}

	public void setEnqPerName(String enqPerName) {
		this.enqPerName = enqPerName;
	}

	public String getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(String enqPerId) {
		this.enqPerId = enqPerId;
	}

	public ArrayList<PerBean> getPerBeanList(){
		return perBeanList;
	}
	
	public void setPerBeanList(ArrayList<PerBean> perBeanList) {
		this.perBeanList = perBeanList;
	}

	public void addPerBeanList(PerBean perBean) {
		perBeanList.add(perBean);
	}


	
	
	public ArrayList<ZoneBean> getZoneBeanList(){
		return zoneBeanList;
	}
	
	public void setZoneBeanList(ArrayList<ZoneBean> zoneBeanList) {
		this.zoneBeanList = zoneBeanList;
	}

	public void addZoneBeanList(ZoneBean zoneBean) {
		zoneBeanList.add(zoneBean);
	}

	public ZoneBean getZoneBean(String zoneId, String orgId){
		for(int i=0;i<zoneBeanList.size();i++) {
			if(zoneId != null && orgId != null && zoneId.equals(zoneBeanList.get(i).getZoneId()) && orgId.equals(zoneBeanList.get(i).getOrgId())){
				return zoneBeanList.get(i);
			}
		}
		return null;
	}
	
	public PerBean getPerBean(String perId, String orgId){
		for(int i=0;i<perBeanList.size();i++) {
			if(perId != null && orgId != null && perId.equals(perBeanList.get(i).getPerId()) && orgId.equals(perBeanList.get(i).getOrgId())){
				return perBeanList.get(i);
			}
		}
		return null;
	}
	
	public void cleanup() {
		setQuoBeanList(new ArrayList<QuoBean>());
		setPcoBeanList(new ArrayList<PcoBean>());
		super.cleanup();
	}
	
	public boolean validate() {
		boolean successFlag = true;
		msg = "";
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
