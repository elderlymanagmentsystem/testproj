package ems.module;

import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.QuoBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.QuoGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PerDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class QuoteModule {

	public boolean performEnqPerDetail(QuoGrpBean quoGrpBean, UserBean userBean) {
		PerDB perDB = new PerDB();
		perDB.performEnqPerDetail(quoGrpBean, userBean);

		if (quoGrpBean!=null && (quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performEnqQuoteList(QuoGrpBean quoGrpBean, UserBean userBean) {
		PerDB perDB = new PerDB();
		quoGrpBean.setZoneBeanList(new ArrayList<ZoneBean>());
		quoGrpBean.setPerBeanList(new ArrayList<PerBean>());

		if(quoGrpBean.getEnqPerName()!=null && quoGrpBean.getEnqPerName().length()>0) {
			perDB.performEnqQuoteList(quoGrpBean, userBean);
		}
		
		perDB.performEnqQuoteList(quoGrpBean, userBean);
		
			
		if (quoGrpBean!=null && (quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdatePer(QuoGrpBean quoGrpBean, UserBean userBean, boolean hasImageUpload) {
		quoGrpBean.setMsg("");

//Update DB
		PerDB perDB = new PerDB();
		
		quoGrpBean.setOrgId(userBean.getAccOrgId());
		quoGrpBean.getField("PER_STATUS").setValue("Y");
		quoGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
		if(hasImageUpload) {
			quoGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+quoGrpBean.getOrgId()+"-"+quoGrpBean.getPerId()+".jpg");
		}
		quoGrpBean.getField("PAT_STATUS").setValue("Y");
		quoGrpBean.getField("PAT_MOD_BY").setValue(userBean.getUserId());

		
		if(quoGrpBean.getPerId()==null || quoGrpBean.getPerId().length()==0) {
			quoGrpBean.setPerId(perDB.getNextPerId(userBean.getOrgId()));
			perDB.performAddPer(quoGrpBean, userBean);
		}else {
			perDB.performModPer(quoGrpBean, userBean);
		}
		
		if(quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0) {
			if(quoGrpBean.getPerId()==null || quoGrpBean.getPerId().length()==0) {
				quoGrpBean.setPerId(perDB.getNextPerId(userBean.getOrgId()));
				perDB.performAddPat(quoGrpBean, userBean);
			}else {
				perDB.performModPat(quoGrpBean, userBean);
			}
		}
		
		if(quoGrpBean.getQuoBeanList().size()>0) {
			QuoBean quoBean = quoGrpBean.getQuoBeanList().get(0);
			quoBean.setOrgId(userBean.getAccOrgId());
			quoBean.setPerId(quoGrpBean.getPerId());
			quoBean.getField("LIV_STATUS").setValue("Y");
			quoBean.getField("LIV_MOD_BY").setValue(userBean.getUserId());
			
			if(quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0) {
				if(quoBean.getBedId()!=null && quoBean.getZoneId()!=null && quoBean.getBedId().length()>0 && quoBean.getZoneId().length()>0) {
					if(quoBean.getQuoId()==null || quoBean.getQuoId().length()==0) {
						quoBean.setQuoId(perDB.getNextQuoId(userBean.getOrgId()));
						perDB.performAddToBed(quoGrpBean, userBean);
					}else {
						perDB.performChangeBed(quoGrpBean, userBean);
					}
				}
			}
		}
		
		perDB.performCleanPco(quoGrpBean, userBean);
		
		if(quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0) {
			if(quoGrpBean.getPcoBeanList().size()>0) {
				for(int i=0;i<quoGrpBean.getPcoBeanList().size();i++) {
					PerBean pcoPerBean = quoGrpBean.getPcoBeanList().get(i).getPerBean();
	
					if(pcoPerBean.getField("PER_CHI_NAME").getFormValue().length()>0 && pcoPerBean.getField("PER_TEL").getFormValue().length()>0) {
						perDB.getPerBeanByNameTel(pcoPerBean);
						pcoPerBean.getField("PER_NATURE").setValue("C");
						pcoPerBean.getField("PER_STATUS").setValue("Y");
						pcoPerBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
	
						if(pcoPerBean.getPerId()==null || pcoPerBean.getPerId().length()==0) {
							pcoPerBean.setPerId(perDB.getNextPerId(pcoPerBean.getOrgId()));
							perDB.performAddPcoPer(pcoPerBean, userBean);
						}else {
							perDB.performModPcoPer(pcoPerBean, userBean);
						}
						
						if(pcoPerBean.getMsg().length()>0) {
							quoGrpBean.setMsg(pcoPerBean.getMsg());
						}else {
							PcoBean pcoBean = quoGrpBean.getPcoBeanList().get(i);
							pcoBean.getField("PER_ID").setFormValue(quoGrpBean.getPerId());
							pcoBean.getField("PCO_PER_ID").setFormValue(pcoPerBean.getField("PER_ID").getFormValue());
							pcoBean.getField("PCO_STATUS").setValue("Y");
							pcoBean.getField("PCO_MOD_BY").setValue(userBean.getUserId());
	
							perDB.performAddPco(pcoBean, userBean);
							if(pcoBean.getMsg().length()>0) {
								quoGrpBean.setMsg(pcoBean.getMsg());
							}
						}
					}
				}
			}
		}
		
//Retrieve new Pat List
		perDB.performEnqQuoteList(quoGrpBean, userBean);
		
		if (quoGrpBean!=null && (quoGrpBean.getMsg()==null || quoGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		

}
