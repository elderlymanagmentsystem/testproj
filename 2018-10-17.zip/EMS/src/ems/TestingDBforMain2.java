package ems;
import java.sql.*;

import ems.util.DBUtil;

public class TestingDBforMain2  {
	public static void main(String [] args) {
		Connection conn = null;
		Statement stmt = null;
		try {
			//connect to hyper sql example
			Class.forName("org.hsqldb.jdbc.JDBCDriver");  
			String dbURL = "jdbc:hsqldb:hsql://localhost/EMS_DB";
	        String user = "SA";
	        String pass = "";
	        conn = DriverManager.getConnection(dbURL, user, pass);
	        stmt = conn.createStatement();
	        String sql;
	        sql = "SELECT username, password from em_user_detail";
	        ResultSet rs = stmt.executeQuery(sql);
	        while(rs.next()){
	        	String username = rs.getString("username");
	            String password = rs.getString("password");
	            System.out.println(username + " "+ password);
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}
}
