package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.CitemBean;
import ems.bean.CperBean;
import ems.bean.FuncBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.QuoBean;
import ems.bean.QuoGrpBean;
import ems.bean.RolBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;

public class PatDB extends PerDB{

	public PatGrpBean performEnqZoneList(PatGrpBean patGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT ORG_ID, ZON_ID, ZON_NAME, ZON_STATUS, ZON_MOD_BY, ZON_MOD_DATE, " + 
					"					BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " + 
					"					LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_LIVING_FEE, LIV_NURSING_FEE, LIV_TYPE, LIV_EXIT_REASON, LIV_EXIT_REMARK, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"					PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"					PER_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, PER_STATUS, PER_MOD_BY, PER_MOD_DATE " + 
					"					FROM EM_ZON_ZONE ZON LEFT JOIN " + 
					"					       (SELECT BED.ORG_ID, BED.ZON_ID, BED.BED_ID, BED.BED_NAME, BED.BED_STATUS, BED.BED_MOD_BY, BED.BED_MOD_DATE, " + 
					"					        LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_LIVING_FEE, LIV_NURSING_FEE, LIV_TYPE, LIV_EXIT_REASON, LIV_EXIT_REMARK, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"						PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"						PER_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, PER_STATUS, PER_MOD_BY, PER_MOD_DATE " + 
					"						FROM EM_BED_INFO BED LEFT JOIN " + 
					"							(SELECT LIV_ID, LIV.ORG_ID, LIV.ZON_ID, LIV.BED_ID, LIV_START_DATE, LIV_END_DATE, LIV_LIVING_FEE, LIV_NURSING_FEE, LIV_TYPE, LIV_EXIT_REASON, LIV_EXIT_REMARK, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"							PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"							PER.PER_ID, PER.PER_CHI_NAME, PER.PER_ENG_NAME, PER.PER_HKID, PER.PER_GENDER, PER.PER_NBIRTH, PER.PER_LBIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_IMAGE_LINK, PER.PER_LDS_REF, PER.PER_LDS_RESULT, PER.PER_LDS_DATE, PER.PER_ASS1, PER.PER_ASS2, PER.PER_ASS2_OTH, PER.PER_ASS3, PER.PER_ASS3_OTH, PER.PER_ASS4, PER.PER_REFERAL, PER.PER_REFERAL_OTH, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE " + 
					"							FROM EM_LIV_RECORD LIV, EM_PAT_PATIENT_INFO PAT, EM_PER_PERSONAL_PARTICULAR PER " + 
					"							WHERE LIV.PAT_ID = PAT.PAT_ID AND LIV.ORG_ID = PAT.ORG_ID AND LIV_STATUS = 'Y' AND PAT_STATUS = 'Y' " + 
					"							AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID) LIV " + 
					"							ON BED.ORG_ID = LIV.ORG_ID AND BED.ZON_ID = LIV.ZON_ID AND BED.BED_ID = LIV.BED_ID " + 
					"						WHERE BED.BED_STATUS = 'Y' AND BED.ORG_ID = ?) BED" + 
					"					ON ZON.ORG_ID = BED.ORG_ID AND ZON.ZON_ID = BED.ZON_ID " + 
					"					WHERE ZON.ZON_STATUS = 'Y' AND ZON.ORG_ID = ?" + 
					"					ORDER BY ZON.ZON_ID, BED.BED_ID, LIV_START_DATE DESC ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			rs = pst.executeQuery();
			while(rs.next()){
				String zoneId = rs.getString("ZON_ID");
				String bedId = rs.getString("BED_ID");
				String livId = rs.getString("LIV_ID");
				String orgId = rs.getString("ORG_ID");
				
				ZoneBean zoneBean = patGrpBean.getZoneBean(zoneId, orgId);
				if(zoneBean == null) {
					zoneBean = new ZoneBean();
					for(int i=0;i<zoneBean.getFields().size();i++) {
						zoneBean.getFields().get(i).setFormValue(rs.getString(zoneBean.getFields().get(i).getName()));
					}
					patGrpBean.addZoneBeanList(zoneBean);
				}
				
				BedBean bedBean = zoneBean.getBedBean(bedId);
				if(bedBean == null && bedId != null && bedId.length()>0) {
					bedBean = new BedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
					zoneBean.addBedBeanList(bedBean);
				
					LivBean livBean = bedBean.getLivBean(livId, orgId);
					if(livBean == null && livId != null && livId.length()>0) {
						livBean = new LivBean();
						for(int i=0;i<livBean.getFields().size();i++) {
							livBean.getFields().get(i).setFormValue(rs.getString(livBean.getFields().get(i).getName()));
						}
						bedBean.addLivBeanList(livBean);
					
						PatBean patBean = livBean.getPatBean();
						for(int i=0;i<patBean.getFields().size();i++) {
							patBean.getFields().get(i).setFormValue(rs.getString(patBean.getFields().get(i).getName()));
						}
					}
				}
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}

	public PatGrpBean performEnqPatList(PatGrpBean patGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT PER_ID, ORG_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, PER_STATUS, PER_MOD_BY, PER_MOD_DATE, " + 
					"					PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"					LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_LIVING_FEE, LIV_NURSING_FEE, LIV_TYPE, LIV_EXIT_REASON, LIV_EXIT_REMARK, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"					ZON_ID, ZON_ID, ZON_NAME, ZON_STATUS, ZON_MOD_BY, ZON_MOD_DATE, " +
					"					BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE " + 
					"	  FROM EM_PAT_PATIENT_INFO PAT, EM_PER_PERSONAL_PARTICULAR PER, EM_LIV_RECORD LIV, EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
					"	  WHERE PAT_STATUS = 'Y' AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID " +
					"	  AND PAT.PAT_ID = LIV.PAT_ID AND PAT.ORG_ID = LIV.ORG_ID " + 
					"	  AND BED_STATUS = 'Y' AND LIV.ORG_ID = BED.ORG_ID AND LIV.ZON_ID = BED.ZON_ID AND LIV.BED_ID = BED.BED_ID " +
					"	  AND ZON_STATUS = 'Y' AND LIV.ORG_ID = ZON.ORG_ID AND LIV.ZON_ID = ZON.ZON_ID "+
					"	  AND PAT.ORG_ID = ? ";  

					if(patGrpBean.getEnqPatName()!=null && patGrpBean.getEnqPatName().length()>0) {
						if("S".equals(patGrpBean.getEnqPatType()))
							sql = sql + "AND PAT.PAT_ID = ? ";
						else if("I".equals(patGrpBean.getEnqPatType()))
							sql = sql + "AND PER.PER_HKID LIKE ? ";
						else if("N".equals(patGrpBean.getEnqPatType())) 
							sql = sql + "AND PER_CHI_NAME LIKE ? ";
						else if("B".equals(patGrpBean.getEnqPatType())) 
							sql = sql + "AND BED_NAME LIKE ? ";
					}
					
					if(patGrpBean.getEnqLivStatus()!=null && patGrpBean.getEnqLivStatus().length()>0) {
						sql = sql + "AND LIV_STATUS = ? "; 
					}

					if(patGrpBean.getEnqLivExitReason()!=null && patGrpBean.getEnqLivExitReason().length()>0) {
						sql = sql + "AND LIV_EXIT_REASON = ? "; 
					}

					if(patGrpBean.getEnqDate()!=null && patGrpBean.getEnqDate().length()>0) {
						if(patGrpBean.getEnqLivStatus()!=null && patGrpBean.getEnqLivStatus().equals("N")) {
							sql = sql + "AND LIV_END_DATE <= ? "; 
						}else{
							sql = sql + "AND LIV_START_DATE <= ? AND LIV_END_DATE IS NULL ";
						}
					}
					
					
					sql = sql+ "	  ORDER BY BED.ZON_ID, BED.BED_ID, LIV.LIV_START_DATE DESC ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));

			if(patGrpBean.getEnqPatName()!=null && patGrpBean.getEnqPatName().length()>0) {
				if("S".equals(patGrpBean.getEnqPatType()))
					pst.setString(pos++, patGrpBean.getEnqPatName());
				else if("I".equals(patGrpBean.getEnqPatType()))
					pst.setString(pos++, "%"+patGrpBean.getEnqPatName()+"%");
				else 
					pst.setString(pos++, "%"+patGrpBean.getEnqPatName()+"%");
			}

			if(patGrpBean.getEnqLivStatus()!=null && patGrpBean.getEnqLivStatus().length()>0) {
				pst.setString(pos++, patGrpBean.getEnqLivStatus());
			}

			if(patGrpBean.getEnqLivExitReason()!=null && patGrpBean.getEnqLivExitReason().length()>0) {
				pst.setString(pos++, patGrpBean.getEnqLivExitReason());
			}

			if(patGrpBean.getEnqDate()!=null && patGrpBean.getEnqDate().length()>0 && patGrpBean.getEnqLivStatus()!=null) {
				pst.setDate(pos++, DataTypeUtil.formDate2BeanDate(patGrpBean.getEnqDate()));
			}
			
			
			rs = pst.executeQuery();
			while(rs.next()){
				String patId = rs.getString("PAT_ID");
				String bedId = rs.getString("BED_ID");
				String livId = rs.getString("LIV_ID");
				String orgId = rs.getString("ORG_ID");
				
				PatBean patBean = patGrpBean.getPatBean(patId, orgId);
				if(patBean == null) {
					patBean = new PatBean();
					for(int i=0;i<patBean.getFields().size();i++) {
						patBean.getFields().get(i).setFormValue(rs.getString(patBean.getFields().get(i).getName()));
					}
					patGrpBean.addPatBeanList(patBean);
				}
				
				LivBean livBean = patBean.getLivBean(livId, orgId);
				if(livBean == null && livId != null && livId.length()>0) {
					livBean = new LivBean();
					for(int i=0;i<livBean.getFields().size();i++) {
						livBean.getFields().get(i).setFormValue(rs.getString(livBean.getFields().get(i).getName()));
					}
					patBean.addLivBeanList(livBean);
				
					BedBean bedBean = livBean.getBedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				}
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}
	
	public PatGrpBean performEnqPatDetail(PatGrpBean patGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT PER_ID, ORG_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, PER_STATUS, PER_MOD_BY, PER_MOD_DATE, " + 
					"					PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"					LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_LIVING_FEE, LIV_NURSING_FEE, LIV_TYPE, LIV_EXIT_REASON, LIV_EXIT_REMARK, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"					ZON.ZON_NAME, BED.ZON_ID, BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " +
					"                   PCO_PER_ID, PCO_RELATION, PCO_CHI_NAME, PCO_TEL, PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE, " + 
					"					TRA_ID, RES_ID, TRA_NAME, TRA_TYPE, TRA_DATE, TRA_AMOUNT, TRA_METHOD, TRA_NOTE, TRA_RECEIPT_ID, TRA_STATUS, TRA_MOD_BY, TRA_MOD_DATE " +
					"	  FROM EM_PAT_PATIENT_INFO PAT, EM_LIV_RECORD LIV LEFT JOIN " +
					"	  (SELECT TRA_ID, ORG_ID, LIV_ID, RES_ID, TRA_NAME, TRA_TYPE, TRA_DATE, TRA_AMOUNT, TRA_METHOD, TRA_NOTE, TRA_RECEIPT_ID, TRA_STATUS, TRA_MOD_BY, TRA_MOD_DATE " +
					"     FROM EM_TRA_TRANSACTIONS WHERE TRA_STATUS = 'Y') TRA ON LIV.ORG_ID = TRA.ORG_ID AND LIV.LIV_ID = TRA.LIV_ID " +
					"     , EM_BED_INFO BED, EM_ZON_ZONE ZON, EM_PER_PERSONAL_PARTICULAR PER LEFT JOIN " +
					"			(SELECT PCO.PER_ID, PCO.ORG_ID, PCO.PCO_PER_ID, PCO.PCO_RELATION, PER.PER_CHI_NAME PCO_CHI_NAME, PER.PER_TEL PCO_TEL, PER.PER_EMAIL PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE " +
					"			FROM EM_PCO_PERSONAL_CONTACT PCO, EM_PER_PERSONAL_PARTICULAR PER " +
					"			WHERE PCO.PCO_STATUS = 'Y' AND PER.PER_STATUS = 'Y' " +
					"			AND PCO.PCO_PER_ID = PER.PER_ID AND PCO.ORG_ID = PER.ORG_ID) PCO " +
					"			ON PER.PER_ID = PCO.PER_ID AND PER.ORG_ID = PCO.ORG_ID " +
					"	  WHERE PAT_STATUS = 'Y' AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID " +
					"	  AND PAT.PAT_ID = LIV.PAT_ID AND PAT.ORG_ID = LIV.ORG_ID " + 
					"	  AND BED_STATUS = 'Y' AND LIV.ORG_ID = BED.ORG_ID AND LIV.ZON_ID = BED.ZON_ID AND LIV.BED_ID = BED.BED_ID " + 
					"	  AND ZON_STATUS = 'Y' AND BED.ORG_ID = ZON.ORG_ID AND BED.ZON_ID = ZON.ZON_ID " + 
					"	  AND PAT.ORG_ID = ? AND PAT.PAT_ID = ? " +  
					"	  ORDER BY LIV.LIV_START_DATE DESC, PCO.PCO_SEQ ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getEnqPatId()));

			rs = pst.executeQuery();
			patGrpBean.setZoneBeanList(new ArrayList<ZoneBean>());
			patGrpBean.setPatBeanList(new ArrayList<PatBean>());
			patGrpBean.setTransBeanList(new ArrayList<TransBean>());
			while(rs.next()){
				String patId = rs.getString("PAT_ID");
				String pcoPerId = rs.getString("PCO_PER_ID");
				String livId = rs.getString("LIV_ID");
				String orgId = rs.getString("ORG_ID");
				
				for(int i=0;i<patGrpBean.getFields().size();i++) {
					patGrpBean.getFields().get(i).setFormValue(rs.getString(patGrpBean.getFields().get(i).getName()));
				}

				if(pcoPerId != null && pcoPerId.length() >0) {
					PcoBean pcoBean = patGrpBean.getPcoBean(pcoPerId, orgId);

					if(pcoBean==null) {
						pcoBean = new PcoBean();
						for(int i=0;i<pcoBean.getFields().size();i++) {
							pcoBean.getFields().get(i).setFormValue(rs.getString(pcoBean.getFields().get(i).getName()));
						}
						pcoBean.getPerBean().setPerId(pcoPerId);
						pcoBean.getPerBean().setOrgId(orgId);
						pcoBean.getPerBean().getField("PER_CHI_NAME").setValue((rs.getString("PCO_CHI_NAME")));
						pcoBean.getPerBean().getField("PER_TEL").setValue(rs.getString("PCO_TEL"));
						pcoBean.getPerBean().getField("PER_EMAIL").setValue(rs.getString("PCO_EMAIL"));
						
						patGrpBean.addPcoBeanList(pcoBean);
					}
				}
				
				LivBean livBean = patGrpBean.getLivBean(livId, orgId);
				if(livBean == null && livId != null && livId.length()>0) {
					livBean = new LivBean();
					for(int i=0;i<livBean.getFields().size();i++) {
						livBean.getFields().get(i).setFormValue(rs.getString(livBean.getFields().get(i).getName()));
					}
					patGrpBean.addLivBeanList(livBean);
				
					BedBean bedBean = livBean.getBedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				}
				
				TransBean transBean = new TransBean();
				for(int i=0;i<transBean.getFields().size();i++) {
					transBean.getFields().get(i).setFormValue(rs.getString(transBean.getFields().get(i).getName()));
				}
				patGrpBean.addTransBeanList(transBean);

			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}
		
	
	public String getNextPatId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String patId = "10001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(PAT_ID)+1 NEW_PAT_ID FROM EM_PAT_PATIENT_INFO WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_PAT_ID")!=null)
	        		patId = rs.getString("NEW_PAT_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patId;
	}	
	
	public String getNextLivId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String livId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(LIV_ID)+1 NEW_LIV_ID FROM EM_LIV_RECORD WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_LIV_ID")!=null)
	        		livId = rs.getString("NEW_LIV_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return livId;
	}	
	
	public PatGrpBean performAddPat(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			pos = 1;
			String sql = "INSERT INTO EM_PAT_PATIENT_INFO PAT ( ";
					for(int i=0;i<EmsDB.EM_PAT_PATIENT_INFO.length-1;i++) {
						if(i != EmsDB.EM_PAT_PATIENT_INFO.length-2)
							sql = sql + EmsDB.EM_PAT_PATIENT_INFO[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PAT_PATIENT_INFO[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PAT_PATIENT_INFO.length-1;i++) {
						if(i != EmsDB.EM_PAT_PATIENT_INFO.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PAT_PATIENT_INFO.length-1;i++) {
				
				if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能新增院友");
			}

		}catch(SQLException se){
			patGrpBean.setMsg("不能新增院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能新增院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}		

	public PatGrpBean performModPat(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Patient 
			String sql = "UPDATE EM_PAT_PATIENT_INFO PAT SET ";
					for(int i=2;i<EmsDB.EM_PAT_PATIENT_INFO.length-1;i++) {
						if(i != EmsDB.EM_PAT_PATIENT_INFO.length-2)
							sql = sql + EmsDB.EM_PAT_PATIENT_INFO[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PAT_PATIENT_INFO[i][0] + " = ? ";
					}
					sql = sql + "WHERE PAT.PAT_ID = ? AND PAT.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PAT_PATIENT_INFO.length-1;i++) {
				
				if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else if(EmsDB.EM_PAT_PATIENT_INFO[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getField(EmsDB.EM_PAT_PATIENT_INFO[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getPatId()));
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	

	public PatGrpBean performInactPat(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Pat
			String sql = "UPDATE EM_PAT_PATIENT_INFO PAT SET PAT_STATUS = 'N', PAT_MOD_BY = ? WHERE PAT.PAT_ID = ? AND PAT.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, userBean.getUserId());
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getPatId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
		
	public PatGrpBean performInactLiv(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Pat
			String sql = "UPDATE EM_LIV_RECORD LIV SET LIV_STATUS = 'N', LIV_END_DATE = ?, LIV_EXIT_REASON = ?, LIV_EXIT_REMARK = ?, LIV_MOD_BY = ? WHERE LIV.LIV_ID = ? AND LIV.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			if(patGrpBean.getLivBeanList().get(0).getField(EmsDB.EM_LIV_RECORD[6][0]).getValue()!=null)
				pst.setDate(pos++, (Date)patGrpBean.getLivBeanList().get(0).getField(EmsDB.EM_LIV_RECORD[6][0]).getValue());
			else
				pst.setDate(pos++, null);
			pst.setString(pos++, patGrpBean.getLivBeanList().get(0).getField(EmsDB.EM_LIV_RECORD[10][0]).getFormValue());
			pst.setString(pos++, patGrpBean.getLivBeanList().get(0).getField(EmsDB.EM_LIV_RECORD[11][0]).getFormValue());
			pst.setString(pos++, userBean.getUserId());
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getLivBeanList().get(0).getLivId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
			
	
	public PatGrpBean performAddToBed(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			LivBean livBean = patGrpBean.getLivBeanList().get(0);
			LivBean oriLivBean = new LivBean();
			oriLivBean.setOrgId(livBean.getOrgId());
			oriLivBean.setZoneId(livBean.getZoneId());
			oriLivBean.setBedId(livBean.getBedId());
			oriLivBean = getLivBeanByBedId(oriLivBean, userBean);

			pos = 1;
			String sql = "INSERT INTO EM_LIV_RECORD LIV ( ";
					for(int i=0;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
						if(i != EmsDB.EM_LIV_RECORD.length-2)
							sql = sql + EmsDB.EM_LIV_RECORD[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_LIV_RECORD[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
						if(i != EmsDB.EM_LIV_RECORD.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
				
				if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能加到床位");
			}else if(oriLivBean.getPatId()!=null && oriLivBean.getPatId().length()>0) {

				pos = 1;
				sql = "UPDATE EM_LIV_RECORD LIV SET LIV_STATUS = 'N' WHERE LIV.LIV_ID = ? AND LIV.ORG_ID = ? ";
				pst = conn.prepareStatement(sql);
				
				pst.setInt(pos++, Integer.parseInt(oriLivBean.getLivId()));
				pst.setInt(pos++, Integer.parseInt(oriLivBean.getOrgId()));
				row = pst.executeUpdate();
				if (row != 1)
				{
					patGrpBean.setMsg("不能轉床位");
				}				
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能加到床位");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能加到床位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}		

	public PatGrpBean performDeposit(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			TransBean transBean = patGrpBean.getTransBean();
			transBean.setTransId(getNextTransId(userBean.getOrgId()));
			transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTransRecId(userBean.getOrgId()));
			pos = 1;
			String sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
							sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
				
				if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
				else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
				else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
				else
					pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
			}
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能繳交按金");
			}

					
		}catch(SQLException se){
			patGrpBean.setMsg("不能繳交按金");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能繳交按金");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}		

	public PatGrpBean performChangeBed(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			LivBean livBean = patGrpBean.getLivBeanList().get(0);
			
			LivBean oriLivBean = new LivBean();
			oriLivBean.setOrgId(livBean.getOrgId());
			oriLivBean.setZoneId(livBean.getZoneId());
			oriLivBean.setBedId(livBean.getBedId());
			oriLivBean = getLivBeanByBedId(oriLivBean, userBean);
			if(oriLivBean.getPatId()!=null && oriLivBean.getPatId().length()>0) {
				LivBean tempLivBean = getLivBeanByPatId(livBean, userBean);
				oriLivBean.setZoneId(tempLivBean.getZoneId());
				oriLivBean.setBedId(tempLivBean.getBedId());
			}
			
			//update Bed 
			String sql = "UPDATE EM_LIV_RECORD LIV SET ";
					for(int i=2;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
						if(i != EmsDB.EM_LIV_RECORD.length-2)
							sql = sql + EmsDB.EM_LIV_RECORD[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_LIV_RECORD[i][0] + " = ? ";
					}
					sql = sql + "WHERE LIV.LIV_ID = ? AND LIV.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
				
				if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(livBean.getLivId()));
			pst.setInt(pos++, Integer.parseInt(livBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能更新院友");
			}else if(oriLivBean.getPatId()!=null && oriLivBean.getPatId().length()>0) {
				pos = 1;
				pst = conn.prepareStatement(sql);
				
				for(int i=2;i<EmsDB.EM_LIV_RECORD.length-1;i++) {
					
					if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)oriLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)oriLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
					else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)oriLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
					else if(EmsDB.EM_LIV_RECORD[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)oriLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getValue());
					else
						pst.setString(pos++, (String)oriLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).getFormValue());
				}
				
				pst.setInt(pos++, Integer.parseInt(oriLivBean.getLivId()));
				pst.setInt(pos++, Integer.parseInt(oriLivBean.getOrgId()));
				row = pst.executeUpdate();
				if (row != 1)
				{
					patGrpBean.setMsg("不能轉床位");
				}				
			}
			
			
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	

	public LivBean getLivBeanByBedId(LivBean livBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ";
			for(int i=0;i<EmsDB.EM_LIV_RECORD.length;i++) {
				if(i != EmsDB.EM_LIV_RECORD.length-1)
					sql = sql + EmsDB.EM_LIV_RECORD[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_LIV_RECORD[i][0] + " ";
			}
			sql = sql + "FROM EM_LIV_RECORD LIV ";
			sql = sql + "WHERE LIV.ORG_ID = ? AND ZON_ID = ? AND BED_ID = ? AND LIV_STATUS = 'Y' ";

			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(livBean.getOrgId()));
			pst.setInt(pos++, Integer.parseInt(livBean.getZoneId()));
			pst.setInt(pos++, Integer.parseInt(livBean.getBedId()));

			rs = pst.executeQuery();
	        while(rs.next()){
				for(int i=0;i<EmsDB.EM_LIV_RECORD.length;i++) {
					livBean.getField(EmsDB.EM_LIV_RECORD[i][0]).setFormValue(rs.getString(EmsDB.EM_LIV_RECORD[i][0]));
				}
	        }

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return livBean;
	}	

	public LivBean getLivBeanByPatId(LivBean livBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		LivBean tempLivBean = new LivBean();
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ";
			for(int i=0;i<EmsDB.EM_LIV_RECORD.length;i++) {
				if(i != EmsDB.EM_LIV_RECORD.length-1)
					sql = sql + EmsDB.EM_LIV_RECORD[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_LIV_RECORD[i][0] + " ";
			}
			sql = sql + "FROM EM_LIV_RECORD LIV ";
			sql = sql + "WHERE LIV.ORG_ID = ? AND PAT_ID = ? AND LIV_STATUS = 'Y' ";

			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(livBean.getOrgId()));
			pst.setInt(pos++, Integer.parseInt(livBean.getPatId()));

			rs = pst.executeQuery();
	        while(rs.next()){
				for(int i=0;i<EmsDB.EM_LIV_RECORD.length;i++) {
					tempLivBean.getField(EmsDB.EM_LIV_RECORD[i][0]).setFormValue(rs.getString(EmsDB.EM_LIV_RECORD[i][0]));
				}
	        }

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return tempLivBean;
	}	

	
	public String getNextPerId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String perId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(PER_ID)+1 NEW_PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_PER_ID")!=null)
	        		perId = rs.getString("NEW_PER_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perId;
	}	
	
	public PerBean getPerBeanByNameTel(PerBean perBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ? AND PER_CHI_NAME = ? AND PER_TEL = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(perBean.getOrgId()));
			pst.setString(pos++, perBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, perBean.getField("PER_TEL").getFormValue());
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("PER_ID")!=null)
	        		perBean.setPerId(rs.getString("PER_ID"));
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perBean;
	}	
	
	public PatGrpBean performAddPer(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PAT ( ";
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能新增院友");
			}
			
		}catch(SQLException se){
			patGrpBean.setMsg("不能新增院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能新增院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}			
	
	public PerBean performAddPcoPer(PerBean pcoPerBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PAT (PER_ID, ORG_ID, PER_CHI_NAME, PER_TEL, PER_EMAIL, PER_NATURE, PER_STATUS, PER_MOD_BY) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ";

			pst = conn.prepareStatement(sql);
			
			pst.setObject(pos++, (Integer)pcoPerBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)pcoPerBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);
			pst.setString(pos++, pcoPerBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_TEL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_EMAIL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_NATURE").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_STATUS").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_MOD_BY").getFormValue());
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoPerBean.setMsg("不能新增連絡人");
			}
			
		}catch(SQLException se){
			pcoPerBean.setMsg("不能新增連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoPerBean.setMsg("不能新增連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoPerBean;
	}			
	
	public PcoBean performAddPco(PcoBean pcoBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PCO_PERSONAL_CONTACT PCO ( ";
					for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
						if(i != EmsDB.EM_PCO_PERSONAL_CONTACT.length-2)
							sql = sql + EmsDB.EM_PCO_PERSONAL_CONTACT[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PCO_PERSONAL_CONTACT[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
						if(i != EmsDB.EM_PCO_PERSONAL_CONTACT.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
				
				if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else
					pst.setString(pos++, (String)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoBean.setMsg("不能新增連絡人");
			}
			
		}catch(SQLException se){
			pcoBean.setMsg("不能新增連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoBean.setMsg("不能新增連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoBean;
	}			
	
	
	public PatGrpBean performModPer(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET ";
					for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? ";
					}
					sql = sql + "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	

	public PerBean performModPcoPer(PerBean pcoPerBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET PER_CHI_NAME = ?, "
					+ "PER_TEL = ?, PER_EMAIL = ?, PER_STATUS = ?, PER_MOD_BY = ? "
					+ "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, pcoPerBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_TEL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_EMAIL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_STATUS").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_MOD_BY").getFormValue());
			pst.setObject(pos++, (Integer)pcoPerBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)pcoPerBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);

			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoPerBean.setMsg("不能更新連絡人");
			}
		}catch(SQLException se){
			pcoPerBean.setMsg("不能更新連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoPerBean.setMsg("不能更新連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoPerBean;
	}	

	public PatGrpBean performCleanPco(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Clean Existing Contact
			String sql = "DELETE FROM EM_PCO_PERSONAL_CONTACT PCO WHERE PCO.PER_ID = ? AND PCO.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			
			pst.setObject(pos++, (Integer)patGrpBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)patGrpBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);

			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能清除連絡人");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能清除連絡人");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能清除連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
	
	public String getNextCperId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String cperId = "10000001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(CHP_ID)+1 NEW_CHP_ID FROM EM_CHP_CHARGE_PERSON WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_CHP_ID")!=null)
	        		cperId = rs.getString("NEW_CHP_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return cperId;
	}	
	
	public PatGrpBean performEnqCperList(PatGrpBean patGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			patGrpBean.setCperBeanList(new ArrayList<CperBean>());
			
			String sql = "SELECT CHP_ID, ORG_ID, PER_ID, CHP.CHI_ID, CHP_NATURE, CHP_QUANTITY, CHP_UNIT_PRICE, CHP_AMOUNT, CHP_START_DATE, CHP_END_DATE, CHP_CURRENT_PAY_DATE, CHP_REMARK, CHP_STATUS, CHP_MOD_BY, CHP_MOD_DATE, "
					+ "					CHI.CHC_ID, CHI_NAME, CHI_UNIT, CHI_UNIT_PRICE, CHI_REMARK, CHI_STATUS, CHI_MOD_BY, CHI_MOD_DATE, " + 
					"					CHC_NAME, CHC_STATUS, CHC_MOD_BY, CHC_MOD_DATE " + 
					"					FROM EM_CHP_CHARGE_PERSON CHP, EM_CHI_CHARGE_ITEM CHI, EM_CHC_CHARGE_CAT CHC " + 
					"					WHERE CHP.CHP_STATUS = 'Y' AND CHP.ORG_ID = ?" +
					"					AND CHI.CHI_STATUS = 'Y' AND CHI.CHI_ID = CHP.CHI_ID AND CHI.ORG_ID = CHP.ORG_ID " +
					"					AND CHC.CHC_STATUS = 'Y' AND CHC.ORG_ID = CHI.ORG_ID AND CHC.CHC_ID = CHI.CHC_ID " +
					"					ORDER BY CHP.CHP_ID ";
					
					
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));

			rs = pst.executeQuery();
			while(rs.next()){
				
				CperBean cperBean = new CperBean();
				for(int i=0;i<cperBean.getFields().size();i++) {
					cperBean.getFields().get(i).setFormValue(rs.getString(cperBean.getFields().get(i).getName()));
				}
				for(int i=0;i<patGrpBean.getPatBeanList().size();i++) {
					if(patGrpBean.getPatBeanList().get(i).getPerId().equals(cperBean.getPerId()))
						patGrpBean.getPatBeanList().get(i).addCperBeanList(cperBean);
				}
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}

	public PatGrpBean performAddCper(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			pos = 1;
			String sql = "INSERT INTO EM_CHP_CHARGE_PERSON CHP ( ";
					for(int i=0;i<EmsDB.EM_CHP_CHARGE_PERSON.length-1;i++) {
						if(i != EmsDB.EM_CHP_CHARGE_PERSON.length-2)
							sql = sql + EmsDB.EM_CHP_CHARGE_PERSON[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_CHP_CHARGE_PERSON[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_CHP_CHARGE_PERSON.length-1;i++) {
						if(i != EmsDB.EM_CHP_CHARGE_PERSON.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_CHP_CHARGE_PERSON.length-1;i++) {
				
				if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getCperBean().getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getCperBean().getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getCperBean().getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getCperBean().getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getCperBean().getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能新增項");
			}

		}catch(SQLException se){
			patGrpBean.setMsg("不能新增帳項");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能新增帳項");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}		

	public PatGrpBean performModCper(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Patient 
			String sql = "UPDATE EM_CHP_CHARGE_PERSON CHP SET ";
					for(int i=2;i<EmsDB.EM_CHP_CHARGE_PERSON.length-1;i++) {
						if(i != EmsDB.EM_CHP_CHARGE_PERSON.length-2)
							sql = sql + EmsDB.EM_CHP_CHARGE_PERSON[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_CHP_CHARGE_PERSON[i][0] + " = ? ";
					}
					sql = sql + "WHERE CHP.CHP_ID = ? AND CHI.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_CHP_CHARGE_PERSON.length-1;i++) {
				
				if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)patGrpBean.getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)patGrpBean.getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)patGrpBean.getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else if(EmsDB.EM_CHP_CHARGE_PERSON[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)patGrpBean.getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getValue());
				else
					pst.setString(pos++, (String)patGrpBean.getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getCperBean().getCperId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				patGrpBean.setMsg("不能更新帳項");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新帳項");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新帳項");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	


	public PatGrpBean performInactCper(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Pat
			String sql = "UPDATE EM_CHP_CHARGE_PERSON CHP SET CHP_STATUS = 'N', CHP_MOD_BY = ? WHERE CHP.CHP_ID = ? AND CHP.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, userBean.getUserId());
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getCperBean().getCperId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能更新帳項");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能更新帳項");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能更新帳項");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
		

}
