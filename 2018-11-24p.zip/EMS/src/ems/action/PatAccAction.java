package ems.action;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.PatGrpBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PcoBean;
import ems.bean.QuoBean;
import ems.bean.ResBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.PatModule;
import ems.module.BedModule;
import ems.module.UserModule;


public class PatAccAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private PatGrpBean patGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "030100";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			patMod.performEnqCperList(patGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			patMod.performAddOrUpdateCper(patGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			patMod.performAddOrUpdateCper(patGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL)){
			patMod.performInactCper(patGrpBean, userBean);			
		}

		if(patGrpBean.getMsg()==null||patGrpBean.getMsg().length()==0) {
			patGrpBean.cleanup();
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(patGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(patGrpBean==null)
			patGrpBean = new PatGrpBean();

		patGrpBean.setMsg("");
		
		for(int i=0;i<patGrpBean.getCperBean().getFields().size();i++){
			patGrpBean.getCperBean().getFields().get(i).setFormValue(request.getParameter(patGrpBean.getCperBean().getFields().get(i).getName()));
		}

		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {
			
			patGrpBean.setOrgId(userBean.getAccOrgId());
			patGrpBean.getCperBean().setOrgId(userBean.getAccOrgId());
			
			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)) {

				if(!patGrpBean.getCperBean().validate()) {
					patGrpBean.setMsg("輸入錯誤");
					validated = false;
				}
			
			}

			if((funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL)) && patGrpBean.getCperBean().getCperId().length()==0) {
				patGrpBean.getCperBean().getField("CHP_ID").setMsg("必需輸入");
				patGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(!validated) {
				PatModule patMod = new PatModule();
				patMod.performEnqCperList(patGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("patGrpBean", patGrpBean);
				addActionError(patGrpBean.getMsg());
			}					

		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}


}
