package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class PatBean extends PerBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
//	private ArrayList<String> orgNameList = new ArrayList<String>();
		
	public PatBean() {
		for(int i=0; i<EmsDB.EM_PAT_PATIENT_INFO.length;i++) {
			fields.add(new Field(EmsDB.EM_PAT_PATIENT_INFO[i]));
		}
	}
	
	public String getPatId() {
		return getField("PAT_ID").getFormValue();
	}
	public void setPatId(String patId) {
		getField("PAT_ID").setFormValue(patId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

}
