package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.sql.Date;

import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.UserBean;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;

public class OrgDB {

	public OrgBean getOrgBean(OrgBean orgBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ";
					for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
						if(i != EmsDB.EM_ORG_ORGANIZATION.length-1)
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + " ";
					}
					sql = sql + "FROM EM_ORG_ORGANIZATION ORG ";
					sql = sql + "WHERE ORG.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgBean.getOrgId()));
			rs = pst.executeQuery();
	        while(rs.next()){
				for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
					orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).setFormValue(rs.getString(EmsDB.EM_ORG_ORGANIZATION[i][0]));
				}
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}
	
	public ArrayList<OrgBean> getOrgBeanList(ArrayList<String> orgIdList) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		ArrayList<OrgBean> orgBeanList = new ArrayList<OrgBean>();
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ";
					for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
						if(i != EmsDB.EM_ORG_ORGANIZATION.length-1)
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + " ";
					}
					sql = sql + "FROM EM_ORG_ORGANIZATION ORG ";
					for(int i=0;i<orgIdList.size();i++) {
						if(orgIdList.size()==1)
							sql = sql + "WHERE ORG.ORG_ID = ? ";
						else if(i==0)
							sql = sql + "WHERE (ORG.ORG_ID = ? ";
						else if(i==orgIdList.size()-1)
							sql = sql + "OR ORG.ORG_ID = ?) ";
						else 
							sql = sql + "OR ORG.ORG_ID = ? ";
							
					}			
					
					
			pst = conn.prepareStatement(sql);
			for(int i=0;i<orgIdList.size();i++)
				pst.setInt(pos++, Integer.parseInt(orgIdList.get(i)));
			
			rs = pst.executeQuery();
	        while(rs.next()){
	        	OrgBean orgBean = new OrgBean();
				for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
					orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).setFormValue(rs.getString(EmsDB.EM_ORG_ORGANIZATION[i][0]));
				}
				orgBeanList.add(orgBean);
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBeanList;
	}	
	
	public OrgBean updOrg(OrgBean orgBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "UPDATE EM_ORG_ORGANIZATION ORG SET ";
					for(int i=1;i<EmsDB.EM_ORG_ORGANIZATION.length-1;i++) {
						if(i != EmsDB.EM_ORG_ORGANIZATION.length-2)
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + " = ? ";
					}
					sql = sql + "WHERE ORG.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=1;i<EmsDB.EM_ORG_ORGANIZATION.length-1;i++) {
				
				if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else
					pst.setString(pos++, (String)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(orgBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				orgBean.setMsg("不能更新院舍資料");
			}
			
		}catch(SQLException se){
			orgBean.setMsg("不能更新院舍資料");
			se.printStackTrace();
		}catch(Exception e){
			orgBean.setMsg("不能更新院舍資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}	
	
	public OrgBean addOrg(OrgBean orgBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_ORG_ORGANIZATION ORG ( ";
					for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length-1;i++) {
						if(i != EmsDB.EM_ORG_ORGANIZATION.length-2)
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length-1;i++) {
						if(i != EmsDB.EM_ORG_ORGANIZATION.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length-1;i++) {
				
				if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else if(EmsDB.EM_ORG_ORGANIZATION[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getValue());
				else
					pst.setString(pos++, (String)orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				orgBean.setMsg("不能新增院舍資料");
			}
			
		}catch(SQLException se){
			orgBean.setMsg("不能新增院舍資料");
			se.printStackTrace();
		}catch(Exception e){
			orgBean.setMsg("不能新增院舍資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}		
	
	public OrgBean addOrgRole(OrgBean orgBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			String orgId = userBean.getOrgId();
			String perId = userBean.getPerId();
			String userId = userBean.getUserId();
			String accOrgId = orgBean.getOrgId();
			
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_URR_USER_ROLE_REL URR (ORG_ID, PER_ID, ACC_ORG_ID, URR_MOD_BY) VALUES (?, ?, ?, ?) ";
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, orgId);
			pst.setString(pos++, perId);
			pst.setString(pos++, accOrgId);
			pst.setString(pos++, userId);
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				orgBean.setMsg("不能新增院舍資料");
			}
			
		}catch(SQLException se){
			orgBean.setMsg("不能新增院舍資料");
			se.printStackTrace();
		}catch(Exception e){
			orgBean.setMsg("不能新增院舍資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}			
	
	public String getNextOrgId() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String orgId = "";
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(ORG_ID)+1 NEW_ORG_ID FROM EM_ORG_ORGANIZATION";
			
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
	        while(rs.next()){
	        	orgId = rs.getString("NEW_ORG_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgId;
	}	
	
	public OrgBean updIntChrg(OrgBean orgBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Pat
			String sql = "UPDATE EM_ORG_ORGANIZATION ORG SET ORG_MOD_BY = ?, ORG_INT_RATE = ?, ORG_CHARGE = ? WHERE ORG.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, userBean.getUserId());
			pst.setBigDecimal(pos++, (BigDecimal)orgBean.getField("ORG_INT_RATE").getValue());
			pst.setBigDecimal(pos++, (BigDecimal)orgBean.getField("ORG_CHARGE").getValue());
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				orgBean.setMsg("不能更新利率");
			}
		}catch(SQLException se){
			orgBean.setMsg("不能更新利率");
			se.printStackTrace();
		}catch(Exception e){
			orgBean.setMsg("不能更新利率");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}	
			
	
}
