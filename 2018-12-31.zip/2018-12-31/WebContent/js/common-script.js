var formNum = 0; 
//0=enq
//1=add
//2=mod

function w3_open() {
    document.getElementById("mySidebar1").style.display = "block";
    document.getElementById("mySidebar2").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar1").style.display = "none";
    document.getElementById("mySidebar2").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

function setTitle(myTitle){
	document.getElementById('myHeaderSpan').innerHTML = myTitle;
}

function setMenuButtonGlow(funcId){
	funcId = funcId.substr(0, 4);
	var element = document.querySelectorAll("[id^='menu']");
	for (var i=0;i<element.length;i++){
		element[i].className.replace(" color2", "");
	}
	document.getElementById("menu"+funcId).className  += " color2";
}

function ddlFunc(dropdownlist) {
    var x = document.getElementById(dropdownlist);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        //x.previousElementSibling.className += " color2";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        //x.previousElementSibling.className = 
        //x.previousElementSibling.className.replace(" color2", "");
    }
}

// confirm message - start//
function showConfirmMessage(msg,type){
	var theMsg = msg;
	if (arguments.length == 0){
		//no argument, use default message 是否確定？
		theMsg = unescape("%u662F%u5426%u78BA%u5B9A%uFF1F");
		document.getElementById("confirmMessageLogo1").style.display = "inline";
		document.getElementById("confirmMessageLogo2").style.display = "none";
	} else if (arguments.length == 2) {
		//2 argument, use define message and different logo
		document.getElementById("confirmMessageLogo1").style.display = "none";
		document.getElementById("confirmMessageLogo2").style.display = "inline";
	} 
	document.getElementById('confirmMessageContent').innerHTML = theMsg;
	document.getElementById('confirmMessage').style.display = 'block';
}

function confirmMessage(flag){
	if ("Y" == flag){
		submitAction();
		document.getElementById('confirmMessage').style.display = 'none';
	}else{
		document.getElementById('confirmMessage').style.display = 'none';
	}
}
function submitAction(){
	document.forms[formNum].submit();
}

//confirm message - end//

function validateFileType(element,msgElement){
    var fileName = element.value;
    if (fileName != null && fileName!=""){
	    var idxDot = fileName.lastIndexOf(".") + 1;
	    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
	    if (extFile!="jpg"){
	    	document.getElementById(msgElement).innerHTML = "只限 jpg檔";
	    	element.value = "";
	    } else {
	    	document.getElementById(msgElement).innerHTML = "";
	    }
    }
}

function clearErrMsg(){
	var element = document.getElementsByClassName("w3-text-red mc-italic");
	for(var i = 0; i < element.length; i++)
	{
		element[i].innerHTML = "";
	}
}

function showScreen(screenId){
	var element = document.querySelectorAll("[id$='Screen']");
	for (var i=0;i<element.length;i++){
		element[i].style.display = "none";
	}
	document.getElementById(screenId).style.display = "block";

	if(screenId.indexOf("enq")!=-1)
		formNum = 1;
	else if(screenId.indexOf("addScreen")!=-1)
		formNum = 2;
	else if(screenId.indexOf("modScreen")!=-1)
		formNum = 3;
	else if(screenId.indexOf("delScreen")!=-1)
		formNum = 4;
	else if(screenId.indexOf("addSubScreen")!=-1)
		formNum = 5;
	else if(screenId.indexOf("modSubScreen")!=-1)
		formNum = 6;
	else if(screenId.indexOf("delSubScreen")!=-1)
		formNum = 7;
	else if(screenId.indexOf("add")!=-1)
		formNum = 2;
	else if(screenId.indexOf("mod")!=-1)
		formNum = 3;
	else if(screenId.indexOf("del")!=-1)
		formNum = 4;
}

function expBtn(elementId) {
    var element = document.querySelectorAll("[id*='ExpBtn']");
	for (var i=0;i<element.length;i++){
		if (elementId == element[i].id)
			if (element[i].className.indexOf("w3-show") == -1)
				element[i].className += " w3-show";
			else
				element[i].className = element[i].className.replace(" w3-show", "");
		else
			element[i].className = element[i].className.replace(" w3-show", "");
	}
}

function switchTabPage(tabIdPrefix, num) {
	var element = document.querySelectorAll("[id^='"+tabIdPrefix+"TabPage']");
	for (var i=0;i<element.length;i++){
		element[i].style.display = "none";
	}
	var element = document.querySelectorAll("[id^='"+tabIdPrefix+"TabBtn']");
	for (var i=0;i<element.length;i++){
		element[i].className = element[i].className.replace(" color1", " w3-grey");
	}
	document.getElementById(tabIdPrefix+"TabPage"+num).style.display = "block";
	document.getElementById(tabIdPrefix+"TabBtn"+num).className = document.getElementById(tabIdPrefix+"TabBtn"+num).className.replace(" w3-grey", " color1");
	document.getElementById(tabIdPrefix+"TabBtn"+num).blur();}

function padzero(number, length) {
    var str = '' + number;
    while (str.length < length) {
        str = '0' + str;
    }
    return str;
}


//disable hover event for touch screen decives
function hasTouch() {
    return 'ontouchstart' in document.documentElement
           || navigator.maxTouchPoints > 0
           || navigator.msMaxTouchPoints > 0;
}

if (hasTouch()) { // remove all :hover stylesheets
    try { // prevent exception on browsers not supporting DOM styleSheets properly
        for (var si in document.styleSheets) {
            var styleSheet = document.styleSheets[si];
            if (!styleSheet.rules) continue;

            for (var ri = styleSheet.rules.length - 1; ri >= 0; ri--) {
                if (!styleSheet.rules[ri].selectorText) continue;

                if (styleSheet.rules[ri].selectorText.match(':hover')) {
                	styleSheet.rules[ri].selectorText = styleSheet.rules[ri].selectorText.replace(':hover','');
                }
            }
        }
    } catch (ex) {}
}

//check is mobile device
function isMobile(){
	return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
}