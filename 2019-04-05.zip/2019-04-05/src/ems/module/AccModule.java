package ems.module;

import java.math.BigDecimal;
import java.util.ArrayList;

import ems.bean.AccGrpBean;
import ems.bean.BedBean;
import ems.bean.CitemBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.AccDB;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PatDB;
import ems.db.PerDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class AccModule {

	public boolean performEnqCitemList(AccGrpBean accGrpBean, UserBean userBean) {
		AccDB accDB = new AccDB();
		PatDB patDB = new PatDB();
		accGrpBean.setCitemBeanList(new ArrayList<CitemBean>());
		
		accDB.performEnqCitemList(accGrpBean, userBean);
		accDB.performEnqCitemCatList(accGrpBean, userBean);
		
		if (accGrpBean!=null && (accGrpBean.getMsg()==null || accGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdateCitem(AccGrpBean accGrpBean, UserBean userBean) {
		accGrpBean.setMsg("");

//Update DB
		AccDB accDB = new AccDB();
		
		accGrpBean.setOrgId(userBean.getAccOrgId());
		accGrpBean.getField("CHC_STATUS").setValue("Y");
		accGrpBean.getField("CHC_MOD_BY").setValue(userBean.getUserId());
		accGrpBean.getField("CHI_STATUS").setValue("Y");
		accGrpBean.getField("CHI_MOD_BY").setValue(userBean.getUserId());

		
		if(accGrpBean.getField("CHC_ID").getFormValue()==null || accGrpBean.getField("CHC_ID").getFormValue().length()==0) {
			accGrpBean.getField("CHC_ID").setFormValue(accDB.getNextCitemCatId(userBean.getAccOrgId()));
			accDB.performAddCitemCat(accGrpBean, userBean);
		}

		if(accGrpBean.getCitemId()==null || accGrpBean.getCitemId().length()==0) {
			accGrpBean.setCitemId(accDB.getNextCitemId(userBean.getAccOrgId()));
			accDB.performAddCitem(accGrpBean, userBean);
		}else {
			accDB.performModCitem(accGrpBean, userBean);
		}
		
//Retrieve new Citem List
		accDB.performEnqCitemList(accGrpBean, userBean);
		accDB.performEnqCitemCatList(accGrpBean, userBean);
		
		
		if (accGrpBean!=null && (accGrpBean.getMsg()==null || accGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		

	
	public boolean performInactCitem(AccGrpBean accGrpBean, UserBean userBean) {
		accGrpBean.setMsg("");

//Update DB
		AccDB accDB = new AccDB();
		
		if(accGrpBean.getMsg()==null || accGrpBean.getMsg().length()==0) {
			if(accGrpBean.getCitemId()!=null && accGrpBean.getCitemId().length()>0) {
				accDB.performInactCitem(accGrpBean, userBean);
			}
		}
		

//Retrieve new Citem List
		accDB.performEnqCitemList(accGrpBean, userBean);
		
		if (accGrpBean!=null && (accGrpBean.getMsg()==null || accGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}			
	
	
}
