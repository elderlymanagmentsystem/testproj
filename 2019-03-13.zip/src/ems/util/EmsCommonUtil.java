package ems.util;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ems.bean.BankBean;
import ems.bean.FuncBean;
import ems.bean.RolBean;
public class EmsCommonUtil {

	public static ArrayList<RolBean> rolBeanList = null;
	public static ArrayList<BankBean> bankBeanList = null;
	public static String projectPath = null;
	public static String runtimePath = null;

	public static RolBean getRolBean(String rolId) {
		RolBean rolBean = null;
		for(int i=0;i<getRolBeanList().size();i++) 
			if(getRolBeanList().get(i).getRolId().equals(rolId)) {
				rolBean = getRolBeanList().get(i);
				break;
			}
		
		return rolBean;
	}
	
	public static String getBankName(String bankId) {
		
		for(int i=0;i<getBankBeanList().size();i++) 
			if(getBankBeanList().get(i).getBankId().equals(bankId)) {
				return getBankBeanList().get(i).getBankName();
				
			}
		
		return "";
	}	
	
	public static ArrayList<RolBean> getRolBeanList() {
	
		if(rolBeanList==null) {
			Connection conn = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			
			try {
	        	if(rolBeanList == null)
	        		rolBeanList = new ArrayList<RolBean>();

				conn = DBUtil.getDataSource().getConnection();
				String sql = "SELECT ROL.ROL_ID, ROL.ROL_NAME, ROL.ROL_STATUS, ROL.ROL_MOD_BY, ROL.ROL_MOD_DATE, "
						+ "FUN.FUN_ID, FUN.FUN_PARENT_ID, FUN.FUN_NAME, FUN.FUN_NAVI, FUN.FUN_URL, FUN.FUN_STATUS, FUN.FUN_MOD_BY, FUN.FUN_MOD_DATE "
						+ "FROM EM_ROL_ROLE ROL, EM_FUN_FUNCTION FUN, EM_RFR_ROL_FUN_REL RFR "
						+ "WHERE ROL.ROL_STATUS = 'Y' "
						+ "AND RFR.RFR_STATUS = 'Y' AND ROL.ROL_ID = RFR.ROL_ID "
						+ "AND FUN.FUN_STATUS ='Y' AND RFR.FUN_ID = FUN.FUN_ID "
						+ "ORDER BY ROL.ROL_ID";
				
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
		        while(rs.next()){
		        		
		        	String rolId = rs.getString("ROL_ID");
		        	RolBean rolBean = null;
		        	for(int i=0;i<rolBeanList.size();i++)
		        		if(rolBeanList.get(i).getRolId().equals(rolId)) {
		        			rolBean = rolBeanList.get(i);
		        			break;
		        		}
		        	
		        	if(rolBean == null) {
		        		rolBean = new RolBean();
		        		for(int i=0;i<rolBean.getFields().size();i++) {
		        			rolBean.getFields().get(i).setFormValue(rs.getString(rolBean.getFields().get(i).getName()));
		        		}
		        		rolBeanList.add(rolBean);
		        	}
		        	
		        	String funcId = rs.getString("FUN_ID");
		        	if(rolBean.getFuncBean(funcId)==null) {
		        		FuncBean funcBean = new FuncBean();
		        		for(int i=0;i<funcBean.getFields().size();i++) {
		        			funcBean.getFields().get(i).setFormValue(rs.getString(funcBean.getFields().get(i).getName()));
		        		}
		        		rolBean.addFuncBeanList(funcBean);
		        		
		        	}
		        	
		        }
			}catch(SQLException se){
				se.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
	        } finally {
	            try {
	                if (conn != null && !conn.isClosed()) {
	                    conn.close();
	                }
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	            try {
	        		rs.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	            try {
	            	pst.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }

		}
		
		return rolBeanList;
	}
	
	public static ArrayList<BankBean> getBankBeanList() {
		
		if(bankBeanList==null) {
			Connection conn = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			
			try {
				conn = DBUtil.getDataSource().getConnection();
	        	if(bankBeanList == null)
	        		bankBeanList = new ArrayList<BankBean>();

				String sql = "SELECT BAN_ID, BAN_NAME, BAN_STATUS, BAN_MOD_BY, BAN_MOD_DATE " + 
						"					FROM EM_BAN_BANK_CODE BAN " + 
						"					WHERE BAN_STATUS = 'Y' ";
				
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
				while(rs.next()){

					BankBean bankBean = new BankBean();
					for(int i=0;i<bankBean.getFields().size();i++) {
						bankBean.getFields().get(i).setFormValue(rs.getString(bankBean.getFields().get(i).getName()));
					}
					bankBeanList.add(bankBean);
		        }				
				
			}catch(SQLException se){
				se.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
	        } finally {
	            try {
	                if (conn != null && !conn.isClosed()) {
	                    conn.close();
	                }
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	            try {
	        		rs.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	            try {
	            	pst.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }

		}
		
		return bankBeanList;
	}	
	
	public String toSelSQL(String[][] dbSpec) {
		String toSelSQL = "";
		
		for(int i=0;i<dbSpec.length;i++) {
			if(i != dbSpec.length-1)
				toSelSQL = toSelSQL + dbSpec[i][0] + ", ";
			else
				toSelSQL = toSelSQL + dbSpec[i][0];
			
		}
		
		return toSelSQL;
	}
	
	public static void setProjPath(String path) {
		projectPath = path;
	}
	public static void setRuntimePath(String path) {
		runtimePath = path;
	}
	public static String getProjPath() {
		String path = projectPath;
		if (path == null || path.trim().length() == 0) {
			path = System.getProperty("user.dir") + File.separator + "WebContent" + File.separator;
		}
		return path;
	}
	public static String getRuntimePath() {
		String path = runtimePath;
		if (path == null || path.trim().length() == 0) {
			path = System.getProperty("user.dir") + File.separator + "WebContent" + File.separator;
		}
		return path;
	}
	
	public static String getTraMethodWording(String traMethod) {
		if ("1".equals(traMethod)){return "現金";}
		else if ("2".equals(traMethod)) {return "支票";}
		else if ("3".equals(traMethod)){return "自動轉賬";}
		return "";
	}
	
	public static String getTraTypeWording(String traType) {
		if ("R".equals(traType)){return "訂金";}
		else if ("D".equals(traType)){return "按金";}
		else if ("S".equals(traType)){return "月結";}
		return "";
	}
	
/*	
	public void bean2XMLRecord(String[][] fieldList, Object javaBean, XmlMultiDataHash dest) throws BisException {
		if (fieldList == null || fieldList.length == 0 || dest == null || javaBean == null) return;
		
		try {
			PropertyDescriptor propertyDescriptor = null;
			BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
			PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

			for (int i = 0; i < fieldList.length; i++) {
				propertyDescriptor = null;
				for (int j=0, n=descriptor.length; j<n; j++) {
					if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][0])) {
						propertyDescriptor = descriptor[j];
						break;
					}
				}
				if (propertyDescriptor == null) 
					throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][0], javaBean.getClass().getName()));				
				
				Method readMethod = propertyDescriptor.getReadMethod();
				Object value = readMethod.invoke(javaBean, (Object[]) null);

				if (value instanceof String) dest.put(fieldList[i][1], value);
				else if (value instanceof Integer) dest.put(fieldList[i][1], DataTypeUtil.beanNumber2FormNumber((Integer) value));
				else if (value instanceof Date) dest.put(fieldList[i][1], DataTypeUtil.beanDate2FormDate((Date) value));
				else if (value instanceof BigDecimal)
					dest.put(fieldList[i][1], fieldList[i][0].indexOf("Rate") >= 0 || fieldList[i][0].indexOf("BillsSpread") >= 0 ? 
						DataTypeUtil.beanRate2FormRate((BigDecimal) value) : DataTypeUtil.beanAmt2FormAmt((BigDecimal) value));
			}
		}
		catch (Exception e) {
			e.printStackTrace();			
			throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
		}
	}

	public void xmlRecord2Bean(String[][] fieldList, XmlMultiDataHash source, Object javaBean) throws BisException {
		if (fieldList == null || fieldList.length == 0 || source == null || javaBean == null) return;
		
		try {
			PropertyDescriptor propertyDescriptor = null;
			BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
			PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

			for (int i = 0; i < fieldList.length; i++) {
				propertyDescriptor = null;
				for (int j=0, n=descriptor.length; j<n; j++) {
					if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][1])) {
						propertyDescriptor = descriptor[j];
						break;
					}
				}
				if (propertyDescriptor == null) 
					throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][1], javaBean.getClass().getName()));				
				
				String value = (String) source.get(fieldList[i][0]);
				Object[] objects = new Object[1];
				String type = propertyDescriptor.getPropertyType().toString();
				int index = type.lastIndexOf('.');
				if (index > 0) type = type.substring(index + 1);
				if (type.equalsIgnoreCase("String")) objects[0] = value;
				else if (type.equalsIgnoreCase("Integer")) objects[0] = DataTypeUtil.formNumber2BeanNumber(value);
				else if (type.equalsIgnoreCase("Date")) objects[0] = DataTypeUtil.hostDate2BeanDate(value);
				else if (type.equalsIgnoreCase("BigDecimal")) objects[0] = DataTypeUtil.formAmt2BeanAmt(value);
			
				Method writeMethod = propertyDescriptor.getWriteMethod();
				writeMethod.invoke(javaBean, objects);
			}
		}
		catch (Exception e) {
			e.printStackTrace();			
			throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
		}
	}
	
    public void bean2XMLRecord(String[][] fieldList, Object javaBean, XmlMultiDataHash dest, int from, int to) throws BisException {
        if (fieldList == null || fieldList.length == 0 || dest == null || javaBean == null) return;
        
        try {
            PropertyDescriptor propertyDescriptor = null;
            BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
            PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

            for (int i = 0; i < fieldList.length; i++) {
                if(fieldList[i][from] == null || fieldList[i][from].trim().length() == 0 || fieldList[i][to] == null || fieldList[i][to].length() == 0)
                    continue;
                propertyDescriptor = null;
                for (int j=0, n=descriptor.length; j<n; j++) {
                    if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][from])) {
                        propertyDescriptor = descriptor[j];
                        break;
                    }
                }
                if (propertyDescriptor == null) 
                    throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][from], javaBean.getClass().getName()));               
                
                Method readMethod = propertyDescriptor.getReadMethod();
                Object value = readMethod.invoke(javaBean, (Object[]) null);

                if (value instanceof String) dest.put(fieldList[i][to], value);
                else if (value instanceof Integer) dest.put(fieldList[i][to], DataTypeUtil.beanNumber2FormNumber((Integer) value));
                else if (value instanceof Date) dest.put(fieldList[i][to], DataTypeUtil.beanDate2FormDate((Date) value));
                else if (value instanceof Timestamp) dest.put(fieldList[i][to], DataTypeUtil.beanTimestamp2FormTimestamp((Timestamp) value));
                else if (value instanceof BigDecimal){
                    if(((BigDecimal)value).scale() > 2)
                        dest.put(fieldList[i][to], DataTypeUtil.beanRate2FormRate((BigDecimal) value));
                    else
                        dest.put(fieldList[i][to], DataTypeUtil.beanAmt2FormAmt((BigDecimal) value));
                }else{
                    dest.put(fieldList[i][to], value);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();            
            throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
        }
    }

    public void xmlRecord2bean(String[][] fieldList, XmlMultiDataHash source, Object javaBean, int from, int to) throws BisException {
        if (fieldList == null || fieldList.length == 0 || source == null || javaBean == null) return;
        
        try {
            PropertyDescriptor propertyDescriptor = null;
            BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
            PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

            for (int i = 0; i < fieldList.length; i++) {
                if(fieldList[i][from] == null || fieldList[i][from].trim().length() == 0 || fieldList[i][to] == null || fieldList[i][to].length() == 0)
                    continue;
                propertyDescriptor = null;
                for (int j=0, n=descriptor.length; j<n; j++) {
                    if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][to])) {
                        propertyDescriptor = descriptor[j];
                        break;
                    }
                }
                if (propertyDescriptor == null) 
                    throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][to], javaBean.getClass().getName()));               
                
                Object[] objects = new Object[1];
                    
                if(source.get(fieldList[i][from]) instanceof String){
                    String value = (String) source.get(fieldList[i][from]);
                    String type = propertyDescriptor.getPropertyType().toString();
                    int index = type.lastIndexOf('.');
                    if (index > 0) type = type.substring(index + 1);
                    if (type.equalsIgnoreCase("String")) objects[0] = value;
                    else if (type.equalsIgnoreCase("Integer")) objects[0] = DataTypeUtil.formNumber2BeanNumber(value);
                    else if (type.equalsIgnoreCase("Date")) objects[0] = DataTypeUtil.hostDate2BeanDate(value);
                    else if (type.equalsIgnoreCase("BigDecimal")) objects[0] = DataTypeUtil.formAmt2BeanAmt(value);
                    else if (type.equalsIgnoreCase("Timestamp")) objects[0] = DataTypeUtil.formTimestamp2BeanTimestamp(value);
                }else{
                    objects[0] = source.get(fieldList[i][from]);
                }
                Method writeMethod = propertyDescriptor.getWriteMethod();
                writeMethod.invoke(javaBean, objects);                
                
            }
        }
        catch (Exception e) {
            e.printStackTrace();            
            throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
        }
    }       	
*/	
}
