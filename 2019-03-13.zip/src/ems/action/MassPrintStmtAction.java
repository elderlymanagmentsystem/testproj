package ems.action;

import com.opensymphony.xwork2.ActionSupport;

import ems.bean.UserBean;
import ems.util.EmsCommonUtil;
import ems.util.PDFUtil;

import java.io.File;
import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

public class MassPrintStmtAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private String funcId;
	private String flag;
	private String month;
	private String year;
	private String pdfPath;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		if (month == null) {
			Calendar now = Calendar.getInstance();
			month = Integer.toString(now.get(Calendar.MONTH) + 1);
		}
		if (year == null) {
			Calendar now = Calendar.getInstance();
			year = Integer.toString(now.get(Calendar.YEAR));
		}
		pdfPath = "";
		
		if ("Y".equals(flag)) {
			pdfPath = "file" + File.separator + "org" + userBean.getOrgId() + File.separator + "massPrintStmt" + userBean.getOrgId() + ".pdf";
			PDFUtil.massPrintStmt(userBean.getOrgId(),Integer.parseInt(year),Integer.parseInt(month),pdfPath);
			return SUCCESS;
		} else {
			return INPUT;
		}
	}
	
	public void validate() {
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getPdfPath() {
		return pdfPath;
	}

	public void setPdfPath(String pdfPath) {
		this.pdfPath = pdfPath;
	}
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}
	
}
