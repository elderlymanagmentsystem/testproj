package ems.action;

import com.opensymphony.xwork2.ActionSupport;

import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PerBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.db.EmsDB;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;
import ems.util.EmsCommonUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

public class RcpAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private PatGrpBean patGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private String flag;
	private String enqType;
	private String enqMethod;
	private String enqInOut;
	private String enqFrom;
	private String enqTo;
	
	public static final String DEFAULT_FUNC_ID = "050200";
	
	public String execute() throws Exception {
		
		if(patGrpBean==null)
			patGrpBean = new PatGrpBean();
		
		if ("Y".equals(flag)) {
			int pos = 1;
			String sql = "SELECT TRA_ID, PER.ORG_ID, PER.PER_ID, PER.PER_CHI_NAME, LIV_ID, RES_ID, STM_ID, TRA_NAME, TRA_TYPE, TRA_DATE, TRA_AMOUNT, TRA_METHOD, TRA_NOTE, TRA_RECEIPT_ID, TRA_REMARK1, TRA_REMARK2, TRA_REMARK3, TRA_ACC_BAL, TRA_PDF_FILE, TRA_STATUS, TRA_MOD_BY, TRA_MOD_DATE " + 
					"FROM EM_TRA_TRANSACTIONS TRA, EM_PER_PERSONAL_PARTICULAR PER  " + 
					"WHERE TRA.PER_ID = PER.PER_ID " + 
					"AND TRA.ORG_ID = PER.ORG_ID " ;
			
			if(!"".equals(enqType))
				sql = sql + "AND TRA.TRA_TYPE = ? "; 
			
			if(!"".equals(enqMethod))
				sql = sql + "AND TRA.TRA_METHOD = ? "; 

			if(!"".equals(enqFrom))
				sql = sql + "AND TRA.TRA_DATE > ? "; 

			if(!"".equals(enqTo))
				sql = sql + "AND TRA.TRA_DATE < ? "; 

			sql = sql + "ORDER BY TRA_TYPE, TRA_RECEIPT_ID" ;
			
			Connection conn = DBUtil.getDataSource().getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			if(!"".equals(enqType))
				pst.setString(pos++, enqType); 

			if(!"".equals(enqMethod)) 
					pst.setString(pos++, enqMethod);
			
			if(!"".equals(enqFrom))
				pst.setDate(pos++, (Date)DataTypeUtil.formDate2BeanDate(enqFrom));
			
			if(!"".equals(enqTo)) 
				pst.setDate(pos++, (Date)DataTypeUtil.formDate2BeanDate(enqTo));
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()){
				
				
				
				TransBean transBean = new TransBean();
				for(int i=0;i<transBean.getFields().size();i++) {
					transBean.getFields().get(i).setFormValue(rs.getString(transBean.getFields().get(i).getName()));
				}
				if(!"".equals(enqInOut)) {
					if("I".equals(enqInOut)) {
						if(((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).compareTo(new BigDecimal("0"))<=0)
							continue;
					}
					if("O".equals(enqInOut)) {
						if(((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).compareTo(new BigDecimal("0"))>0)
							continue;
					}
				}

				
				patGrpBean.addTransBeanList(transBean);
				
				PatBean patBean = new PatBean();
				patBean.setPerId(rs.getString("PER_ID"));
				patBean.getField("PER_CHI_NAME").setFormValue(rs.getString("PER_CHI_NAME"));
				patGrpBean.addPatBeanList(patBean);
			}

		}
		
		addActionMessage("");

		if(funcId.length()==6)
			funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
		request.setAttribute("funcId", funcId);
		request.setAttribute("patGrpBean", patGrpBean);
		request.setAttribute("enqType", enqType);
		request.setAttribute("enqMethod", enqMethod);
		request.setAttribute("enqInOut", enqInOut);
		request.setAttribute("enqFrom", enqFrom);
		request.setAttribute("enqTo", enqTo);

		return SUCCESS;
			
	}
	
	public void validate() {
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(patGrpBean==null)
			patGrpBean = new PatGrpBean();

		if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
			userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
		}		
	
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public String getEnqType() {
		return enqType;
	}

	public void setEnqType(String enqType) {
		this.enqType = enqType;
	}

	public String getEnqMethod() {
		return enqMethod;
	}

	public void setEnqMethod(String enqMethod) {
		this.enqMethod = enqMethod;
	}

	public String getEnqInOut() {
		return enqInOut;
	}

	public void setEnqInOut(String enqInOut) {
		this.enqInOut = enqInOut;
	}

	public String getEnqFrom() {
		return enqFrom;
	}

	public void setEnqFrom(String enqFrom) {
		this.enqFrom = enqFrom;
	}

	public String getEnqTo() {
		return enqTo;
	}

	public void setEnqTo(String enqTo) {
		this.enqTo = enqTo;
	}

	
}
