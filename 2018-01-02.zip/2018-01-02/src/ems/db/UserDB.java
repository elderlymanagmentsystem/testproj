package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import ems.bean.FuncBean;
import ems.bean.OrgBean;
import ems.bean.PerBean;
import ems.bean.RolBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.util.DBUtil;

public class UserDB {

	public UserBean login(UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT USE.PER_ID, USE.ORG_ID, USE.USE_ID, USE.USE_PWD, USE.ROL_ID, USE.USE_STATUS, USE.USE_MOD_BY, USE.USE_MOD_DATE, "
					+ "PER.PER_CHI_NAME, PER.PER_ENG_NAME, PER_HKID, PER.PER_GENDER, PER.PER_NBIRTH, PER.PER_LBIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_IMAGE_LINK, PER.PER_LDS_REF, PER.PER_LDS_RESULT, PER.PER_LDS_DATE, PER.PER_ASS1, PER.PER_ASS2, PER.PER_ASS2_OTH, PER.PER_ASS3, PER.PER_ASS3_OTH, PER.PER_ASS4, PER.PER_REFERAL, PER.PER_REFERAL_OTH, PER.BAN_ID, PER.PER_BANK_ACC_NO, PER.PER_BANK_ACC_NAME, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE, "
					+ "URR.ACC_ORG_ID, ORG2.ORG_STATUS "
					+ "FROM EM_USE_USER_ACCT USE, EM_ORG_ORGANIZATION ORG, EM_ORG_ORGANIZATION ORG2, EM_PER_PERSONAL_PARTICULAR PER, "
					+ "EM_URR_USER_ROLE_REL URR "
					+ "WHERE USE.USE_STATUS = 'Y' AND USE.ORG_ID = ? AND USE.USE_ID = ? AND USE.USE_PWD = ? "
					+ "AND ORG.ORG_STATUS = 'Y' AND USE.ORG_ID = ORG.ORG_ID "
					+ "AND PER.PER_STATUS = 'Y' AND USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID "
					+ "AND URR.URR_STATUS = 'Y' AND USE.PER_ID = URR.PER_ID AND USE.ORG_ID = URR.ORG_ID "
					+ "AND URR.ACC_ORG_ID = ORG2.ORG_ID "
					+ "ORDER BY URR.ACC_ORG_ID";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getOrgId()));
			pst.setString(pos++, userBean.getUserId());
			pst.setString(pos++, userBean.getPwd());
			rs = pst.executeQuery();
			userBean.setAccOrgBeanList(new ArrayList<OrgBean>());
			while(rs.next()){
	        	if(userBean.getPerId()==null||userBean.getPerId().length()==0) {
	        		for(int i=0;i<userBean.getFields().size();i++) {
						if(userBean.getFields().get(i).getName().equals("ROL_ID")) {
	        				userBean.setRolId(rs.getString(userBean.getFields().get(i).getName()));
						}else if(userBean.getFields().get(i).getName().equals("ORG_ID")) {
		    				userBean.setOrgId(rs.getString(userBean.getFields().get(i).getName()));
		    				userBean.setAccOrgId(rs.getString(userBean.getFields().get(i).getName()));
						}else {
	        				userBean.getFields().get(i).setFormValue(rs.getString(userBean.getFields().get(i).getName()));
						}
	        		}
	        	}
	        	OrgBean orgBean = new OrgBean();
	        	orgBean.setOrgId(rs.getString("ACC_ORG_ID"));
	        	OrgDB orgDB = new OrgDB();
	        	userBean.addAccOrgBeanList(orgDB.getOrgBean(orgBean));
	        	

	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userBean;
	}

	public UserBean getUserBean(UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT USE.PER_ID, USE.ORG_ID, USE.USE_ID, USE.USE_PWD, USE.ROL_ID, USE.USE_STATUS, USE.USE_MOD_BY, USE.USE_MOD_DATE, "
					+ "PER.PER_CHI_NAME, PER.PER_ENG_NAME, PER_HKID, PER.PER_GENDER, PER.PER_NBIRTH, PER.PER_LBIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_IMAGE_LINK, PER.PER_LDS_REF, PER.PER_LDS_RESULT, PER.PER_LDS_DATE, PER.PER_ASS1, PER.PER_ASS2, PER.PER_ASS2_OTH, PER.PER_ASS3, PER.PER_ASS3_OTH, PER.PER_ASS4, PER.PER_REFERAL, PER.PER_REFERAL_OTH, PER.BAN_ID, PER.PER_BANK_ACC_NO, PER.PER_BANK_ACC_NAME, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE, "
					+ "URR.ACC_ORG_ID, ORG2.ORG_STATUS "
					+ "FROM EM_USE_USER_ACCT USE, EM_ORG_ORGANIZATION ORG, EM_ORG_ORGANIZATION ORG2, EM_PER_PERSONAL_PARTICULAR PER, "
					+ "EM_URR_USER_ROLE_REL URR "
					+ "WHERE USE.USE_STATUS = 'Y' AND USE.ORG_ID = ? AND USE.PER_ID = ? "
					+ "AND ORG.ORG_STATUS = 'Y' AND USE.ORG_ID = ORG.ORG_ID "
					+ "AND PER.PER_STATUS = 'Y' AND USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID "
					+ "AND URR.URR_STATUS = 'Y' AND USE.PER_ID = URR.PER_ID AND USE.ORG_ID = URR.ORG_ID "
					+ "AND URR.ACC_ORG_ID = ORG2.ORG_ID "
					+ "ORDER BY URR.ACC_ORG_ID";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getOrgId()));
			pst.setString(pos++, userBean.getPerId());
			rs = pst.executeQuery();
			userBean.setAccOrgBeanList(new ArrayList<OrgBean>());
			while(rs.next()){
	        	if(userBean.getPerId()==null||userBean.getPerId().length()==0) {
	        		for(int i=0;i<userBean.getFields().size();i++) {
						if(userBean.getFields().get(i).getName().equals("ROL_ID")) {
	        				userBean.setRolId(rs.getString(userBean.getFields().get(i).getName()));
						}else if(userBean.getFields().get(i).getName().equals("ORG_ID")) {
		    				userBean.setOrgId(rs.getString(userBean.getFields().get(i).getName()));
		    				userBean.setAccOrgId(rs.getString(userBean.getFields().get(i).getName()));
						}else {
	        				userBean.getFields().get(i).setFormValue(rs.getString(userBean.getFields().get(i).getName()));
						}
	        		}
	        	}
	        	OrgBean orgBean = new OrgBean();
	        	orgBean.setOrgId(rs.getString("ACC_ORG_ID"));
	        	OrgDB orgDB = new OrgDB();
	        	userBean.addAccOrgBeanList(orgDB.getOrgBean(orgBean));
	        	

	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userBean;
	}

	public boolean isUserExist(UserGrpBean userGrpBean) {
		boolean exist = false;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT USE.PER_ID, USE.ORG_ID "
					+ "FROM EM_USE_USER_ACCT USE "
					+ "WHERE USE.ORG_ID = ? AND USE.USE_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
			pst.setString(pos++, userGrpBean.getUserId());
			rs = pst.executeQuery();
			if(rs.next()){
				exist = true;
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return exist;
	}
	
	
	public UserGrpBean performEnqUserGrp(UserGrpBean userGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			
			String sql = "SELECT ";
			for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length;i++) {
				if(i != EmsDB.EM_USE_USER_ACCT.length-1)
					sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
			}

			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
				if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1)
					sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " ";
			}

			sql = sql + "FROM EM_USE_USER_ACCT USE, EM_PER_PERSONAL_PARTICULAR PER ";
			sql = sql + "WHERE USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID ";

			if(userBean.getAccOrgId()!=null && userBean.getAccOrgId().length()>0)
				sql = sql + "AND USE.ORG_ID = ? ";
			else {
				for(int i=0;i<userBean.getAccOrgBeanList().size();i++) {
					if(userBean.getAccOrgBeanList().size()==1)
						sql = sql + "AND USE.ORG_ID = ? ";
					else if(i==0)
						sql = sql + "AND (USE.ORG_ID = ? ";
					else if(i==userBean.getAccOrgBeanList().size()-1)
						sql = sql + "OR USE.ORG_ID = ?) ";
					else 
						sql = sql + "OR USE.ORG_ID = ? ";
						
				}
			}
			
			if(userGrpBean.getEnqRolId()!=null && userGrpBean.getEnqRolId().length()>0)
				sql = sql + "AND USE.ROL_ID = ? ";

			if(userGrpBean.getEnqUserId()!=null && userGrpBean.getEnqUserId().length()>0)
				sql = sql + "AND USE.USE_ID LIKE ? ";


			pst = conn.prepareStatement(sql);

			if(userBean.getAccOrgId()!=null && userBean.getAccOrgId().length()>0)
				pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			else 
				for(int i=0;i<userBean.getAccOrgBeanList().size();i++)
					pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgBeanList().get(i).getOrgId()));
			
			if(userGrpBean.getEnqRolId()!=null && userGrpBean.getEnqRolId().length()>0)
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getEnqRolId()));
			if(userGrpBean.getEnqUserId()!=null && userGrpBean.getEnqUserId().length()>0)
				pst.setString(pos++, "%"+userGrpBean.getEnqUserId()+"%");
			
			rs = pst.executeQuery();
			userGrpBean.setUserBeanList(new ArrayList<UserBean>());
	        while(rs.next()){
				UserBean tempUserBean = new UserBean();
				
				for(int i=0;i<tempUserBean.getFields().size();i++){
					if(tempUserBean.getFields().get(i).getName().equals("ROL_ID"))
        				tempUserBean.setRolId(rs.getString(tempUserBean.getFields().get(i).getName()));
					else if(tempUserBean.getFields().get(i).getName().equals("ORG_ID"))
	    				tempUserBean.setOrgId(rs.getString(tempUserBean.getFields().get(i).getName()));
        			else
        				tempUserBean.getFields().get(i).setFormValue(rs.getString(tempUserBean.getFields().get(i).getName()));
				}

				getAccOrgId(tempUserBean);
				userGrpBean.addUserBeanList(tempUserBean);
					
	        }

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}	

	public UserBean getAccOrgId(UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ACC_ORG_ID FROM EM_URR_USER_ROLE_REL WHERE PER_ID = ? AND ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getOrgId()));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("ACC_ORG_ID")!=null)
	        		userBean.addAccOrgBeanList(rs.getString("ACC_ORG_ID"));
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userBean;
	}	
	
	public String getNextPerId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String perId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(PER_ID)+1 NEW_PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_PER_ID")!=null)
	        		perId = rs.getString("NEW_PER_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perId;
	}	
	
	public UserGrpBean performAddUser(UserGrpBean userGrpBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PER ( ";
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				userGrpBean.setMsg("不能新增院友資料");
			}else{
				
				pos = 1;
				sql = "INSERT INTO EM_USE_USER_ACCT USE ( ";
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
					else
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ") VALUES ( ";
				}
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + "?, ";
					else
						sql = sql + "?) ";
				}

				pst = conn.prepareStatement(sql);
				
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					
					if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else
						pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getFormValue());
				}
		
				row = pst.executeUpdate();
				if (row != 1)
				{
					userGrpBean.setMsg("不能更新用戶資料");
				}else {
					updateAccOrg(userGrpBean);
				}				
				
				
			}
			
		}catch(SQLException se){
			userGrpBean.setMsg("不能新增用戶資料");
			se.printStackTrace();
		}catch(Exception e){
			userGrpBean.setMsg("不能新增用戶資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}		
		
	
	public UserGrpBean performModUser(UserGrpBean userGrpBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			boolean updPassword = false;
			
			if(userGrpBean.getField("USE_PWD").getFormValue().length()>0)
				updPassword = true;
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET ";
					for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? ";
					}
					sql = sql + "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				userGrpBean.setMsg("不能更新用戶資料");
			}else{
				
				pos = 1;
				//update User Acct 
				sql = "UPDATE EM_USE_USER_ACCT USE SET ";
				for(int i=2;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(!updPassword && i==3)
						continue;
					
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + " = ? , ";
					else
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + " = ? ";
				}
				sql = sql + "WHERE USE.PER_ID = ? AND USE.ORG_ID = ?";
		
				pst = conn.prepareStatement(sql);
				
				for(int i=2;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(!updPassword && i==3)
						continue;
					
					if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else
						pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getFormValue());
				}
				
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
				row = pst.executeUpdate();
				if (row != 1)
				{
					userGrpBean.setMsg("不能更新用戶資料");
				}else {
					updateAccOrg(userGrpBean);
				}
				
				
			}
		}catch(SQLException se){
			userGrpBean.setMsg("不能更新用戶資料");
			se.printStackTrace();
		}catch(Exception e){
			userGrpBean.setMsg("不能更新用戶資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}	

	public UserBean updateAccOrg(UserGrpBean userGrpBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "DELETE FROM EM_URR_USER_ROLE_REL WHERE PER_ID = ? AND ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
			int row = pst.executeUpdate();

			for(int i=0;i<userGrpBean.getAccOrgBeanList().size();i++) {
				pos = 1;
				sql = "INSERT INTO EM_URR_USER_ROLE_REL (ORG_ID, PER_ID, ACC_ORG_ID, URR_MOD_BY) VALUES (?, ?, ?, ?) ";
				pst = conn.prepareStatement(sql);
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getAccOrgBeanList().get(i).getOrgId()));
				pst.setString(pos++, userGrpBean.getField("USE_MOD_BY").getFormValue());
				row = pst.executeUpdate();
			}
			
		}catch(SQLException se){
			userGrpBean.setMsg("不能更新用戶資料");
			se.printStackTrace();
		}catch(Exception e){
			userGrpBean.setMsg("不能更新用戶資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}		
	
	
}
