package ems.module;

import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class BedModule {

	public boolean performEnqBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		BedDB bedDB = new BedDB();
		bedDB.performEnqZoneList(zoneGrpBean, userBean);

		return true;
	}	
	
	public boolean performAddZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

//Update DB
		BedDB bedDB = new BedDB();
		zoneGrpBean.setZoneId(bedDB.getNextZoneId(userBean.getOrgId()));
		zoneGrpBean.getField("ZON_MOD_BY").setValue(userBean.getUserId());
		zoneGrpBean.getField("ZON_STATUS").setValue("Y");
		
		bedDB.performAddZone(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();

//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		
	
	public boolean performAddBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

//Update DB
		ArrayList<BedBean> bedBeanList = zoneGrpBean.getBedBeanList();
		BedDB bedDB = new BedDB();
		int bedId = Integer.parseInt(bedDB.getNextBedId(userBean.getOrgId(), zoneGrpBean.getZoneId()));
		for(int i=0;i<bedBeanList.size();i++){
			bedBeanList.get(i).setBedId(new Integer(bedId++).toString());
			bedBeanList.get(i).getField("BED_MOD_BY").setValue(userBean.getUserId());
			bedBeanList.get(i).getField("BED_STATUS").setValue("Y");
		}
		
		bedDB.performAddBed(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();
//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performModZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

//Update DB
		BedDB bedDB = new BedDB();
		zoneGrpBean.getField("ZON_MOD_BY").setValue(userBean.getUserId());
		zoneGrpBean.getField("ZON_STATUS").setValue("Y");
		bedDB.performModZone(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();
		
//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performModBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

//Update DB
		ArrayList<BedBean> bedBeanList = zoneGrpBean.getBedBeanList();
		BedDB bedDB = new BedDB();
		for(int i=0;i<bedBeanList.size();i++){
			bedBeanList.get(i).getField("BED_MOD_BY").setValue(userBean.getUserId());
			bedBeanList.get(i).getField("BED_STATUS").setValue("Y");
		}

		bedDB.performModBed(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();
		
//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
		
	public boolean performDelZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

//Update DB
		BedDB bedDB = new BedDB();
		bedDB.performDelZone(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();
		
//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performDelBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		zoneGrpBean.setMsg("");

		ArrayList<BedBean> bedBeanList = zoneGrpBean.getBedBeanList();
		BedDB bedDB = new BedDB();
		for(int i=0;i<bedBeanList.size();i++){
			bedBeanList.get(i).getField("BED_MOD_BY").setValue(userBean.getUserId());
		}

		bedDB.performDelBed(zoneGrpBean, userBean);
		if(zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)
			zoneGrpBean.cleanup();
		
//Retrieve new Zone List
		bedDB.performEnqZoneList(zoneGrpBean, userBean);
		
		if (zoneGrpBean!=null && (zoneGrpBean.getMsg()==null || zoneGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
			
}
