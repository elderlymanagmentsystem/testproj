myTitle = "EMS 老人院管理系統";

function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}

function resizeIFrameToFitContent(myFrame) {
	myContent = document.getElementById("myContent");
	iFrame = document.getElementById(myFrame);
	//reset scrollheight first
	iFrame.height = iFrame.contentWindow.document.body.offsetHeight;
	//set iframe height to scroll height, so that iframe will long enough to not having scroll bar
    iFrame.height = iFrame.contentWindow.document.body.scrollHeight;
    iFrame.width  = myContent.offsetWidth;
}
function onMyFrameLoad(myFrame) {
	document.getElementById('myHeaderSpan').innerHTML = myTitle;
};
function setTitle(newTitle){
	myTitle = newTitle;
}

function ddlFunc(dropdownlist) {
    var x = document.getElementById(dropdownlist);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}
