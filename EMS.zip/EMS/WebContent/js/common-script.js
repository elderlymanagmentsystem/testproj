function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}

function setTitle(myTitle){
	document.getElementById('myHeaderSpan').innerHTML = myTitle;
}

function ddlFunc(dropdownlist) {
    var x = document.getElementById(dropdownlist);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}

function collapseAllddl(str){
	var x=document.getElementsByTagName('div');
	for(var i=0;i<x.length;i++){
		if(x[i].id.indexOf(str)==0){
			x[i].className = x[i].className.replace(" w3-show", "");
			x[i].previousElementSibling.className = 
			x[i].previousElementSibling.className.replace(" w3-green", "");
		}
	 }
}

// confirm message - start//
function showConfirmMessage(){
	document.getElementById('confirmMessage').style.display = 'block';
}
function confirmMessage(flag){
	if ("Y" == flag){
		submitAction();
		document.getElementById('confirmMessage').style.display = 'none';
	}else{
		document.getElementById('confirmMessage').style.display = 'none';
	}
}
function submitAction(){
	alert("haha");
	document.forms[0].submit();
}
//confirm message - end//