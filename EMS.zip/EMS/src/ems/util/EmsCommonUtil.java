package ems.util;

public class EmsCommonUtil {

/*	
	public void bean2XMLRecord(String[][] fieldList, Object javaBean, XmlMultiDataHash dest) throws BisException {
		if (fieldList == null || fieldList.length == 0 || dest == null || javaBean == null) return;
		
		try {
			PropertyDescriptor propertyDescriptor = null;
			BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
			PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

			for (int i = 0; i < fieldList.length; i++) {
				propertyDescriptor = null;
				for (int j=0, n=descriptor.length; j<n; j++) {
					if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][0])) {
						propertyDescriptor = descriptor[j];
						break;
					}
				}
				if (propertyDescriptor == null) 
					throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][0], javaBean.getClass().getName()));				
				
				Method readMethod = propertyDescriptor.getReadMethod();
				Object value = readMethod.invoke(javaBean, (Object[]) null);

				if (value instanceof String) dest.put(fieldList[i][1], value);
				else if (value instanceof Integer) dest.put(fieldList[i][1], DataTypeUtil.beanNumber2FormNumber((Integer) value));
				else if (value instanceof Date) dest.put(fieldList[i][1], DataTypeUtil.beanDate2FormDate((Date) value));
				else if (value instanceof BigDecimal)
					dest.put(fieldList[i][1], fieldList[i][0].indexOf("Rate") >= 0 || fieldList[i][0].indexOf("BillsSpread") >= 0 ? 
						DataTypeUtil.beanRate2FormRate((BigDecimal) value) : DataTypeUtil.beanAmt2FormAmt((BigDecimal) value));
			}
		}
		catch (Exception e) {
			e.printStackTrace();			
			throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
		}
	}

	public void xmlRecord2Bean(String[][] fieldList, XmlMultiDataHash source, Object javaBean) throws BisException {
		if (fieldList == null || fieldList.length == 0 || source == null || javaBean == null) return;
		
		try {
			PropertyDescriptor propertyDescriptor = null;
			BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
			PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

			for (int i = 0; i < fieldList.length; i++) {
				propertyDescriptor = null;
				for (int j=0, n=descriptor.length; j<n; j++) {
					if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][1])) {
						propertyDescriptor = descriptor[j];
						break;
					}
				}
				if (propertyDescriptor == null) 
					throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][1], javaBean.getClass().getName()));				
				
				String value = (String) source.get(fieldList[i][0]);
				Object[] objects = new Object[1];
				String type = propertyDescriptor.getPropertyType().toString();
				int index = type.lastIndexOf('.');
				if (index > 0) type = type.substring(index + 1);
				if (type.equalsIgnoreCase("String")) objects[0] = value;
				else if (type.equalsIgnoreCase("Integer")) objects[0] = DataTypeUtil.formNumber2BeanNumber(value);
				else if (type.equalsIgnoreCase("Date")) objects[0] = DataTypeUtil.hostDate2BeanDate(value);
				else if (type.equalsIgnoreCase("BigDecimal")) objects[0] = DataTypeUtil.formAmt2BeanAmt(value);
			
				Method writeMethod = propertyDescriptor.getWriteMethod();
				writeMethod.invoke(javaBean, objects);
			}
		}
		catch (Exception e) {
			e.printStackTrace();			
			throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
		}
	}
	
    public void bean2XMLRecord(String[][] fieldList, Object javaBean, XmlMultiDataHash dest, int from, int to) throws BisException {
        if (fieldList == null || fieldList.length == 0 || dest == null || javaBean == null) return;
        
        try {
            PropertyDescriptor propertyDescriptor = null;
            BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
            PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

            for (int i = 0; i < fieldList.length; i++) {
                if(fieldList[i][from] == null || fieldList[i][from].trim().length() == 0 || fieldList[i][to] == null || fieldList[i][to].length() == 0)
                    continue;
                propertyDescriptor = null;
                for (int j=0, n=descriptor.length; j<n; j++) {
                    if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][from])) {
                        propertyDescriptor = descriptor[j];
                        break;
                    }
                }
                if (propertyDescriptor == null) 
                    throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][from], javaBean.getClass().getName()));               
                
                Method readMethod = propertyDescriptor.getReadMethod();
                Object value = readMethod.invoke(javaBean, (Object[]) null);

                if (value instanceof String) dest.put(fieldList[i][to], value);
                else if (value instanceof Integer) dest.put(fieldList[i][to], DataTypeUtil.beanNumber2FormNumber((Integer) value));
                else if (value instanceof Date) dest.put(fieldList[i][to], DataTypeUtil.beanDate2FormDate((Date) value));
                else if (value instanceof Timestamp) dest.put(fieldList[i][to], DataTypeUtil.beanTimestamp2FormTimestamp((Timestamp) value));
                else if (value instanceof BigDecimal){
                    if(((BigDecimal)value).scale() > 2)
                        dest.put(fieldList[i][to], DataTypeUtil.beanRate2FormRate((BigDecimal) value));
                    else
                        dest.put(fieldList[i][to], DataTypeUtil.beanAmt2FormAmt((BigDecimal) value));
                }else{
                    dest.put(fieldList[i][to], value);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();            
            throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
        }
    }

    public void xmlRecord2bean(String[][] fieldList, XmlMultiDataHash source, Object javaBean, int from, int to) throws BisException {
        if (fieldList == null || fieldList.length == 0 || source == null || javaBean == null) return;
        
        try {
            PropertyDescriptor propertyDescriptor = null;
            BeanInfo beanInfo = Introspector.getBeanInfo(javaBean.getClass());
            PropertyDescriptor descriptor[] = beanInfo.getPropertyDescriptors();

            for (int i = 0; i < fieldList.length; i++) {
                if(fieldList[i][from] == null || fieldList[i][from].trim().length() == 0 || fieldList[i][to] == null || fieldList[i][to].length() == 0)
                    continue;
                propertyDescriptor = null;
                for (int j=0, n=descriptor.length; j<n; j++) {
                    if (descriptor[j].getName().equalsIgnoreCase(fieldList[i][to])) {
                        propertyDescriptor = descriptor[j];
                        break;
                    }
                }
                if (propertyDescriptor == null) 
                    throw (new BisException(ReturnCode.FIELD_NOT_FOUND_ERR, fieldList[i][to], javaBean.getClass().getName()));               
                
                Object[] objects = new Object[1];
                    
                if(source.get(fieldList[i][from]) instanceof String){
                    String value = (String) source.get(fieldList[i][from]);
                    String type = propertyDescriptor.getPropertyType().toString();
                    int index = type.lastIndexOf('.');
                    if (index > 0) type = type.substring(index + 1);
                    if (type.equalsIgnoreCase("String")) objects[0] = value;
                    else if (type.equalsIgnoreCase("Integer")) objects[0] = DataTypeUtil.formNumber2BeanNumber(value);
                    else if (type.equalsIgnoreCase("Date")) objects[0] = DataTypeUtil.hostDate2BeanDate(value);
                    else if (type.equalsIgnoreCase("BigDecimal")) objects[0] = DataTypeUtil.formAmt2BeanAmt(value);
                    else if (type.equalsIgnoreCase("Timestamp")) objects[0] = DataTypeUtil.formTimestamp2BeanTimestamp(value);
                }else{
                    objects[0] = source.get(fieldList[i][from]);
                }
                Method writeMethod = propertyDescriptor.getWriteMethod();
                writeMethod.invoke(javaBean, objects);                
                
            }
        }
        catch (Exception e) {
            e.printStackTrace();            
            throw new BisException(ReturnCode.BEANINFO_ERR, e.getMessage());
        }
    }       	
*/	
}
