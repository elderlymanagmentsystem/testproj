package ems.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ems.bean.FuncBean;
import ems.bean.UserBean;
import ems.util.DBUtil;

public class UserDB {

	public UserBean getUserBean(UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT USE.PER_ID, FUN.FUN_ID, URR.ACC_ORG_ID, FUN.FUN_PARENT_ID, FUN.FUN_NAME, FUN.FUN_NAVI, FUN.FUN_URL "
					+ "FROM EM_USE_USER_ACCT USE, EM_ORG_ORGANIZATION ORG, EM_ORG_ORGANIZATION ORG2, EM_PER_PERSONAL_PARTICULAR PER, "
					+ "EM_ROL_ROLE ROL, EM_FUN_FUNCTION FUN, EM_URR_USER_ROLE_REL URR, EM_RFR_ROL_FUN_REL RFR "
					+ "WHERE USE.USE_STATUS = 'Y' AND USE.ORG_ID = ? AND USE.USE_ID = ? AND USE.USE_PWD = ? "
					+ "AND ORG.ORG_STATUS = 'Y' AND USE.ORG_ID = ORG.ORG_ID "
					+ "AND PER.PER_STATUS = 'Y' AND USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID "
					+ "AND URR.URR_STATUS = 'Y' AND USE.PER_ID = URR.PER_ID AND USE.ORG_ID = URR.ORG_ID "
					+ "AND ORG2.ORG_STATUS = 'Y' AND URR.ACC_ORG_ID = ORG2.ORG_ID "
					+ "AND ROL.ROL_STATUS = 'Y' AND URR.ROL_ID = ROL.ROL_ID "
					+ "AND RFR.RFR_STATUS = 'Y' AND ROL.ROL_ID = RFR.ROL_ID "
					+ "AND FUN.FUN_STATUS ='Y' AND RFR.FUN_ID = FUN.FUN_ID "
					+ "ORDER BY FUN.FUN_ID, URR.ACC_ORG_ID";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getOrgId()));
			pst.setString(pos++, userBean.getUserId());
			pst.setString(pos++, userBean.getPwd());
			rs = pst.executeQuery();
	        while(rs.next()){
	        	userBean.setPerId(rs.getString("PER_ID"));
	        	String funcId = rs.getString("FUN_ID");
	        	String funcParentId = rs.getString("FUN_PARENT_ID");
	        	String funcName = rs.getString("FUN_NAME");
	        	String funcNavi = rs.getString("FUN_NAVI");
	        	String funcURL = rs.getString("FUN_URL");
	        	String orgId = rs.getString("ACC_ORG_ID");
	        	FuncBean funcBean = userBean.getFuncBean(funcId); 
	        	if(funcBean==null) {
	        		funcBean = new FuncBean(funcId, funcParentId, funcName, funcNavi, funcURL);
	        		funcBean.addOrgId(orgId);
	        		userBean.addFunBean(funcBean);
	        	}else {
	        		funcBean.addOrgId(orgId);
	        	}
	        	
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userBean;
	}
	
}
