package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import ems.bean.FuncBean;
import ems.bean.OrgBean;
import ems.bean.PerBean;
import ems.bean.RolBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.util.DBUtil;

public class UserDB {

	public UserBean getUserBean(UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT USE.PER_ID, USE.ROL_ID, FUN.FUN_ID, URR.ACC_ORG_ID, FUN.FUN_PARENT_ID, FUN.FUN_NAME, FUN.FUN_NAVI, FUN.FUN_URL, ORG2.ORG_STATUS "
					+ "FROM EM_USE_USER_ACCT USE, EM_ORG_ORGANIZATION ORG, EM_ORG_ORGANIZATION ORG2, EM_PER_PERSONAL_PARTICULAR PER, "
					+ "EM_ROL_ROLE ROL, EM_FUN_FUNCTION FUN, EM_URR_USER_ROLE_REL URR, EM_RFR_ROL_FUN_REL RFR "
					+ "WHERE USE.USE_STATUS = 'Y' AND USE.ORG_ID = ? AND USE.USE_ID = ? AND USE.USE_PWD = ? "
					+ "AND ORG.ORG_STATUS = 'Y' AND USE.ORG_ID = ORG.ORG_ID "
					+ "AND PER.PER_STATUS = 'Y' AND USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID "
					+ "AND URR.URR_STATUS = 'Y' AND USE.PER_ID = URR.PER_ID AND USE.ORG_ID = URR.ORG_ID "
					+ "AND URR.ACC_ORG_ID = ORG2.ORG_ID "
					+ "AND ROL.ROL_STATUS = 'Y' AND USE.ROL_ID = ROL.ROL_ID "
					+ "AND RFR.RFR_STATUS = 'Y' AND ROL.ROL_ID = RFR.ROL_ID "
					+ "AND FUN.FUN_STATUS ='Y' AND RFR.FUN_ID = FUN.FUN_ID "
					+ "ORDER BY FUN.FUN_ID, URR.ACC_ORG_ID";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getOrgId()));
			pst.setString(pos++, userBean.getUserId());
			pst.setString(pos++, userBean.getPwd());
			rs = pst.executeQuery();
			userBean.setFunBeanList(new ArrayList<FuncBean>());
	        while(rs.next()){
	        	userBean.setPerId(rs.getString("PER_ID"));
	        	userBean.setRolId(rs.getString("ROL_ID"));
	        	String funcId = rs.getString("FUN_ID");
	        	String funcParentId = rs.getString("FUN_PARENT_ID");
	        	String funcName = rs.getString("FUN_NAME");
	        	String funcNavi = rs.getString("FUN_NAVI");
	        	String funcURL = rs.getString("FUN_URL");
	        	String orgId = rs.getString("ACC_ORG_ID");
	        	String orgStatus = rs.getString("ORG_STATUS");
	        	if(funcId.substring(0, 2).equals(EmsDB.FUNC_GROUP_SET) || orgStatus.equals("Y")) {
		        	FuncBean funcBean = userBean.getFuncBean(funcId); 
		        	if(funcBean==null) {
		        		funcBean = new FuncBean(funcId, funcParentId, funcName, funcNavi, funcURL);
		        		funcBean.addOrgId(orgId);
		        		userBean.addFunBean(funcBean);
		        	}else {
		        		funcBean.addOrgId(orgId);
		        	}
	        	}
	        	
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userBean;
	}

	public UserGrpBean performEnqUserGrp(UserGrpBean userGrpBean, ArrayList<String> accOrgList) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			
			String sql = "SELECT ROL.ROL_NAME, ";
			for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length;i++) {
				if(i != EmsDB.EM_USE_USER_ACCT.length-1)
					sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
			}

			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
				if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1)
					sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " ";
			}

			sql = sql + "FROM EM_USE_USER_ACCT USE, EM_PER_PERSONAL_PARTICULAR PER, EM_ROL_ROLE ROL ";
			sql = sql + "WHERE USE.ROL_ID = ROL.ROL_ID AND USE.PER_ID = PER.PER_ID AND USE.ORG_ID = PER.ORG_ID ";

			if(userGrpBean.getEnqOrgId()!=null && userGrpBean.getEnqOrgId().length()>0)
				sql = sql + "AND USE.ORG_ID = ? ";
			else {
				for(int i=0;i<accOrgList.size();i++) {
					if(accOrgList.size()==1)
						sql = sql + "AND USE.ORG_ID = ? ";
					else if(i==0)
						sql = sql + "AND (USE.ORG_ID = ? ";
					else if(i==accOrgList.size()-1)
						sql = sql + "OR USE.ORG_ID = ?) ";
					else 
						sql = sql + "OR USE.ORG_ID = ? ";
						
				}
			}
			
			if(userGrpBean.getEnqRolId()!=null && userGrpBean.getEnqRolId().length()>0)
				sql = sql + "AND USE.ROL_ID = ? ";

			if(userGrpBean.getEnqUserId()!=null && userGrpBean.getEnqUserId().length()>0)
				sql = sql + "AND USE.USE_ID LIKE ? ";


			pst = conn.prepareStatement(sql);

			if(userGrpBean.getEnqOrgId()!=null && userGrpBean.getEnqOrgId().length()>0)
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getEnqOrgId()));
			else 
				for(int i=0;i<accOrgList.size();i++)
					pst.setInt(pos++, Integer.parseInt(accOrgList.get(i)));
			
			if(userGrpBean.getEnqRolId()!=null && userGrpBean.getEnqRolId().length()>0)
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getEnqRolId()));
			if(userGrpBean.getEnqUserId()!=null && userGrpBean.getEnqUserId().length()>0)
				pst.setString(pos++, "%"+userGrpBean.getEnqUserId()+"%");
			
			rs = pst.executeQuery();
			userGrpBean.setUserBeanList(new ArrayList<UserBean>());
	        while(rs.next()){
				UserBean userBean = new UserBean();
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length;i++) {
					userBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).setFormValue(rs.getString(EmsDB.EM_USE_USER_ACCT[i][0]));
				}
				
				PerBean perBean = new PerBean();
				for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
					perBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).setFormValue(rs.getString(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]));
				}
				userBean.setPerBean(perBean);

				userBean.setRolName(rs.getString("ROL_NAME"));
				userGrpBean.addUserBeanList(userBean);
					
	        }

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}	

	public String getNextPerId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String perId = "";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(PER_ID)+1 NEW_PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	perId = rs.getString("NEW_PER_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perId;
	}	
	
	public UserGrpBean performAddUser(UserGrpBean userGrpBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PER ( ";
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				userGrpBean.setMsg("不能新增院友資料");
			}else{
				
				pos = 1;
				sql = "INSERT INTO EM_USE_USER_ACCT USE ( ";
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ", ";
					else
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + ") VALUES ( ";
				}
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + "?, ";
					else
						sql = sql + "?) ";
				}

				pst = conn.prepareStatement(sql);
				
				for(int i=0;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					
					if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else
						pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getFormValue());
				}
		
				row = pst.executeUpdate();
				if (row != 1)
				{
					userGrpBean.setMsg("不能更新用戶資料");
				}				
				
				
			}
			
		}catch(SQLException se){
			userGrpBean.setMsg("不能新增院友資料");
			se.printStackTrace();
		}catch(Exception e){
			userGrpBean.setMsg("不能新增院友資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}		
		
	
	public UserGrpBean performModUser(UserGrpBean userGrpBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			boolean updPassword = false;
			
			if(userGrpBean.getField("USE_PWD").getFormValue().length()>0)
				updPassword = true;
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET ";
					for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? ";
					}
					sql = sql + "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)userGrpBean.getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				userGrpBean.setMsg("不能更新用戶資料");
			}else{
				
				pos = 1;
				//update User Acct 
				sql = "UPDATE EM_USE_USER_ACCT USE SET ";
				for(int i=2;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(!updPassword && i==3)
						continue;
					
					if(i != EmsDB.EM_USE_USER_ACCT.length-2)
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + " = ? , ";
					else
						sql = sql + EmsDB.EM_USE_USER_ACCT[i][0] + " = ? ";
				}
				sql = sql + "WHERE USE.PER_ID = ? AND USE.ORG_ID = ?";
		
				pst = conn.prepareStatement(sql);
				
				for(int i=2;i<EmsDB.EM_USE_USER_ACCT.length-1;i++) {
					if(!updPassword && i==3)
						continue;
					
					if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else if(EmsDB.EM_USE_USER_ACCT[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getValue());
					else
						pst.setString(pos++, (String)userGrpBean.getField(EmsDB.EM_USE_USER_ACCT[i][0]).getFormValue());
				}
				
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getPerId()));
				pst.setInt(pos++, Integer.parseInt(userGrpBean.getOrgId()));
				row = pst.executeUpdate();
				if (row != 1)
				{
					userGrpBean.setMsg("不能更新用戶資料");
				}				
				
				
			}
		}catch(SQLException se){
			userGrpBean.setMsg("不能更新用戶資料");
			se.printStackTrace();
		}catch(Exception e){
			userGrpBean.setMsg("不能更新用戶資料");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return userGrpBean;
	}	

	public ArrayList<RolBean> getRolBeanList() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		ArrayList<RolBean> rolBeanList = new ArrayList<RolBean>();
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			
			String sql = "SELECT ";
			for(int i=0;i<EmsDB.EM_ROL_ROLE.length;i++) {
				if(i != EmsDB.EM_ROL_ROLE.length-1)
					sql = sql + EmsDB.EM_ROL_ROLE[i][0] + ", ";
				else
					sql = sql + EmsDB.EM_ROL_ROLE[i][0] + " ";
			}
			sql = sql + "FROM EM_ROL_ROLE ROL ";

			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();

	        while(rs.next()){
				RolBean rolBean = new RolBean();
				for(int i=0;i<EmsDB.EM_ROL_ROLE.length;i++) {
					rolBean.getField(EmsDB.EM_ROL_ROLE[i][0]).setFormValue(rs.getString(EmsDB.EM_ROL_ROLE[i][0]));
				}
				rolBeanList.add(rolBean);
	        }

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return rolBeanList;
	}	
	
	
}
