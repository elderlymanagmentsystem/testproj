package ems.db;

public class EmsDB {

	public static final String[] EM_USE_USER_ACCT = {"USE_ID", 
													 "USE_PWD", 
													 "USE_NAME", 
													 "USE_TEL", 
													 "USE_EMAIL",
													 "USE_DESC",
													 "USE_STATIC",
													 "USE_CREATE_DATE",
													 "USE_CLOSE_DATE"};
	
	public static final String[] EM_ORG_ORGANIZATION = {"ORG_ID", 
		     											"ORG_ENG_NAME", 
			 											"ORG_CHI_NAME",
			 											"ORG_ENG_ADDR",
			 											"ORG_CHI_ADDR",
			 											"ORG_TEL",
			 											"ORG_FAX",
			 											"ORG_WEBSITE",
			 											"ORG_EMAIL",
			 											"ORG_LICENSE_NO",
			 											"ORG_LICENSE_EXP_DATE",
			 											"ORG_BR_NO",
			 											"ORG_NATURE",
			 											"ORG_TOTAL_BED",
			 											"ORG_GOV_BED",
			 											"ORG_SERVICE_AIM",
			 											"ORG_IMAGE_LINK",
			 											"ORG_STATUS",
			 											"ORG_START_DATE",
			 											"ORG_END_DATE"};
		
	public static final String[] EM_URR_USER_ROLE_REL = {"ORG_ID", 
		     											 "ROL_ID", 
			 											 "USE_ID"};
	
	public static final String[] EM_ROL_ROLE = {"ROL_ID", 
				 								"ROL_NAME"};
	
	public static final String[] EM_RFR_ROL_FUN_REL = {"ROL_ID", 
													   "FUN_ID"};
	
	public static final String[] EM_FUN_FUNCTION = {"FUN_ID", 
	   												"FUN_PARENT_ID",
	   												"FUN_NAME",
	   												"FUN_DESC",
	   												"FUN_URL"};
	

}
