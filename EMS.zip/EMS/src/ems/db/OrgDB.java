package ems.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ems.bean.OrgBean;
import ems.util.DBUtil;

public class OrgDB {

	public OrgBean getOrgBean(OrgBean orgBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT ";
					for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION[0].length;i++) {
						sql = sql + EmsDB.EM_ORG_ORGANIZATION[i][0] + " ";
					}
					sql = sql + "FROM EM_ORG_ORGANIZATION ORG ";
					sql = sql + "WHERE ORG.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgBean.getOrgId()));
			rs = pst.executeQuery();
	        while(rs.next()){
				for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION[0].length;i++) {
					orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).setFormValue(rs.getString(EmsDB.EM_ORG_ORGANIZATION[i][0]));
				}
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return orgBean;
	}
	
}
