package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class OrgBean extends BasicBean {
	
	private ArrayList<String> orgIdList = new ArrayList<String>();
	private ArrayList<String> orgNameList = new ArrayList<String>();
		
	public OrgBean() {
		for(int i=0; i<EmsDB.EM_ORG_ORGANIZATION[0].length;i++) {
			fields.add(new Field(EmsDB.EM_ORG_ORGANIZATION[i]));
		}
	}
	
	public OrgBean(String orgId, String userId, String pwd) {
		this();
		setOrgId(orgId);
		setUserId(userId);
		setPwd(pwd);
	}
	
	public String getOrgId() {
		return getField("orgId").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("orgId").setFormValue(orgId);
	}
	public String getUserId() {
		return getField("userId").getFormValue();
	}
	public void setUserId(String userId) {
		getField("userId").setFormValue(userId);
	}
	public String getPwd() {
		return getField("pwd").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("pwd").setFormValue(pwd);
	}
	
	public ArrayList<String> getOrgIdList(){
		return orgIdList;
	}
	
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgIdList(ArrayList<String> orgIdList) {
		this.orgIdList = orgIdList;
	}

	public void addOrgIdList(String orgId) {
		orgIdList.add(orgId);
	}


	public ArrayList<String> getOrgNameList(){
		return orgNameList;
	}
	
	public boolean isOrgNameExist(String orgName){
		for(int i=0;i<orgNameList.size();i++) {
			if(orgName != null && orgName.equals(orgNameList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgNameList(ArrayList<String> orgNameList) {
		this.orgNameList = orgNameList;
	}

	public void addOrgNameList(String orgName) {
		orgNameList.add(orgName);
	}

}
