package ems.bean;

import ems.db.EmsDB;

public class RolBean extends BasicBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
//	private ArrayList<String> orgNameList = new ArrayList<String>();
		
	public RolBean() {
		for(int i=0; i<EmsDB.EM_ROL_ROLE.length;i++) {
			fields.add(new Field(EmsDB.EM_ROL_ROLE[i]));
		}
	}
	
	public String getRolId() {
		return getField("ROL_ID").getFormValue();
	}
	public void setRolId(String rolId) {
		getField("ROL_ID").setFormValue(rolId);
	}

	public String getRolName() {
		return getField("ROL_NAME").getFormValue();
	}
	public void setRolName(String rolName) {
		getField("ROL_NAME").setFormValue(rolName);
	}

/*	
	public ArrayList<String> getOrgIdList(){
		return orgIdList;
	}
	
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgIdList(ArrayList<String> orgIdList) {
		this.orgIdList = orgIdList;
	}

	public void addOrgIdList(String orgId) {
		orgIdList.add(orgId);
	}


	public ArrayList<String> getOrgNameList(){
		return orgNameList;
	}
	
	public boolean isOrgNameExist(String orgName){
		for(int i=0;i<orgNameList.size();i++) {
			if(orgName != null && orgName.equals(orgNameList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgNameList(ArrayList<String> orgNameList) {
		this.orgNameList = orgNameList;
	}

	public void addOrgNameList(String orgName) {
		orgNameList.add(orgName);
	}
*/
}
