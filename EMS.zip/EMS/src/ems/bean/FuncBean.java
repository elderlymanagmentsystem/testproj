package ems.bean;

import java.util.ArrayList;

public class FuncBean extends BasicBean {
	
	private String funcId = "";
	private String funcParentId = "";
	private String funcName = "";
	private String funcNavi = "";
	private String funcURL = "";
	private ArrayList<String> orgIdList = new ArrayList<String>();
	
	public FuncBean(String funcId, String funcParentId, String funcName, String funcNavi, String funcURL) {
		setFuncId(funcId);
		setFuncParentId(funcParentId);
		setFuncName(funcName);
		setFuncNavi(funcNavi);
		setFuncURL(funcURL);
	}
	
	public FuncBean(String funcId) {
		setFuncId(funcId);
	}
	
	public String getFuncId() {
		return funcId;
	}
	
	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFuncParentId() {
		return funcParentId;
	}

	public void setFuncParentId(String funcParentId) {
		this.funcParentId = funcParentId;
	}

	public String getFuncName() {
		return funcName;
	}

	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}

	public String getFuncNavi() {
		return funcNavi;
	}

	public void setFuncNavi(String funcNavi) {
		this.funcNavi = funcNavi;
	}

	public String getFuncURL() {
		return funcURL;
	}

	public void setFuncURL(String funcURL) {
		this.funcURL = funcURL;
	}

	public ArrayList<String> getOrgIdList(){
		return orgIdList;
	}
	
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgIdList(ArrayList<String> orgIdList) {
		this.orgIdList = orgIdList;
	}

	public void addOrgId(String orgId) {
		orgIdList.add(orgId);
	}
}
