package ems.bean;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.math.BigDecimal;

import ems.util.DataTypeUtil;

public class BasicBean {
	
	protected String msg = "";
	protected ArrayList<Field> fields = new ArrayList<Field>();
	
	public Field getField(String name) {

		for(int i=0;i<fields.size();i++) {
			if(name!=null && name.equals(fields.get(i).getName())){
				return fields.get(i);
			}
		}
		return null;
	}
	
	public boolean validate() {
		boolean successFlag = true;
		msg = "";
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "OK";
		return successFlag;
	}
	
	
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public class Field{
	
		private String name;
		private String label;
		private String type;
		private String maxlen;
		private String msg;
		private boolean mandatory;
		private Object value;
		
		public Field(String[] beanSpec) {
			if(beanSpec == null || beanSpec.length < 6)
				new BasicBean();
			else {
				if(beanSpec[0]!=null)
					this.name = beanSpec[0];
				else
					this.name = "";
				
				if(beanSpec[1]!=null)
					this.label = beanSpec[1];
				else
					this.label = "";
				
				if(beanSpec[2]!=null)
					this.type = beanSpec[2];
				else
					this.type = "";
	
				if(beanSpec[3]!=null)
					this.maxlen = beanSpec[3];
				else
					this.maxlen = "";
	
				if(beanSpec[4]!=null)
					this.msg = beanSpec[4];
				else
					this.msg = "";
				
				if(beanSpec[5]!=null && beanSpec[5].equalsIgnoreCase("Y"))
					this.mandatory = true;
				else
					this.mandatory = false;
				
			}
		}
		
		public Field() {
			name="";
			label="";
			type="";
			maxlen="";
			msg="";
			mandatory=false;
			value = new Object();
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getMaxlen() {
			return maxlen;
		}
		public void setMaxlen(String maxlen) {
			this.maxlen = maxlen;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public boolean isMandatory() {
			return mandatory;
		}
		public void setMandatory(boolean mandatory) {
			this.mandatory = mandatory;
		}
		public Object getValue() {
			return value;
		}
		public void setValue(Object value) {
			this.value = value;
		}
	
		public String getFormValue() {
			
			String formValue = "";
			
			if(type.equalsIgnoreCase("String"))
				formValue = (String)value;
			else if(type.equalsIgnoreCase("Integer"))
				formValue = DataTypeUtil.beanNumber2FormNumber((Integer)value);
			else if(type.equalsIgnoreCase("Date"))
				formValue = DataTypeUtil.beanDate2FormDate((Date)value);
			else if(type.equalsIgnoreCase("BigDecimal"))
	            if(((BigDecimal)value).scale() > 2)
	            	formValue = DataTypeUtil.beanRate2FormRate((BigDecimal) value);
	            else
	            	formValue =  DataTypeUtil.beanAmt2FormAmt((BigDecimal) value);
			else if(type.equalsIgnoreCase("Timestamp"))
				formValue = DataTypeUtil.beanTimestamp2FormTimestamp((Timestamp) value);
			
			if(formValue==null)
				formValue = "";
			
			return formValue;
		}
	
		public void setFormValue(String value) {
	
			try {
				if(type.equalsIgnoreCase("String")) {
					this.value = value;
				}else if(type.equalsIgnoreCase("Integer")) {
					this.value = DataTypeUtil.formNumber2BeanNumber(value);
				}else if(type.equalsIgnoreCase("Date")) {
					this.value = DataTypeUtil.formDate2BeanDate(value);
				}else if(type.equalsIgnoreCase("BigDecimal")) {
					this.value = DataTypeUtil.formAmt2BeanAmt(value);
				}else if (type.equalsIgnoreCase("Timestamp")) {
					this.value = DataTypeUtil.formTimestamp2BeanTimestamp(value);
				}else {
					this.value = value;
				}
			}catch(Exception e) {
				this.msg = "";
			}
		}
		
		public boolean validate() {
			boolean successFlag = true;

			setMsg("");
			
			//Check Length
			if(getMaxlen()!=null && getMaxlen().length()>0
					&& getFormValue()!=null && getFormValue().length()>0
					&& getFormValue().length() > DataTypeUtil.formNumber2BeanNumber(getMaxlen()).intValue()) {
				setMsg(getLabel()+"excess max length: "+getMaxlen());
				successFlag = false;
			}
			
			//Check Mandatory
			if(isMandatory() && (getFormValue()==null || getFormValue().length() == 0)) {
				setMsg(getLabel()+"excess max length");
				successFlag = false;
			}
				
			return successFlag;
		}		
	}
	
}
