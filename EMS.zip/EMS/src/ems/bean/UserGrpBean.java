package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class UserGrpBean extends BasicBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
//	private ArrayList<String> orgNameList = new ArrayList<String>();
		
	public UserGrpBean() {
		for(int i=0; i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
			fields.add(new Field(EmsDB.EM_PER_PERSONAL_PARTICULAR[i]));
		}
		for(int i=2; i<EmsDB.EM_USE_USER_ACCT.length;i++) {
			fields.add(new Field(EmsDB.EM_USE_USER_ACCT[i]));
		}
	}
	
	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

/*	
	public ArrayList<String> getOrgIdList(){
		return orgIdList;
	}
	
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgIdList(ArrayList<String> orgIdList) {
		this.orgIdList = orgIdList;
	}

	public void addOrgIdList(String orgId) {
		orgIdList.add(orgId);
	}


	public ArrayList<String> getOrgNameList(){
		return orgNameList;
	}
	
	public boolean isOrgNameExist(String orgName){
		for(int i=0;i<orgNameList.size();i++) {
			if(orgName != null && orgName.equals(orgNameList.get(i))){
				return true;
			}
		}
		return false;
	}
	
	public void setOrgNameList(ArrayList<String> orgNameList) {
		this.orgNameList = orgNameList;
	}

	public void addOrgNameList(String orgName) {
		orgNameList.add(orgName);
	}
*/
}
