package ems.bean;

import java.util.ArrayList;

public class UserBean extends BasicBean {
	
	private ArrayList<FuncBean> funcBeanList = new ArrayList<FuncBean>();
	private String perId = "";
	
	public UserBean() {
		fields.add(new Field(new String[] {"orgId", "院舍編號", "Integer", "4", "", "Y"}));
		fields.add(new Field(new String[] {"userId", "用戶名稱", "String", "50", "", "Y"}));		
		fields.add(new Field(new String[] {"pwd", "密碼", "String", "50", "", "Y"}));
	}
	
	public UserBean(String orgId, String userId, String pwd) {
		this();
		setOrgId(orgId);
		setUserId(userId);
		setPwd(pwd);
	}
	
	public String getOrgId() {
		return getField("orgId").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("orgId").setFormValue(orgId);
	}
	public String getUserId() {
		return getField("userId").getFormValue();
	}
	public void setUserId(String userId) {
		getField("userId").setFormValue(userId);
	}
	public String getPwd() {
		return getField("pwd").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("pwd").setFormValue(pwd);
	}
	
	public String getPerId() {
		return perId;
	}
	
	public void setPerId(String perId) {
		this.perId = perId;
	}

	public ArrayList<String> getFunIdList(){
		ArrayList<String> funIdList = new ArrayList<String>();
		for(int i=0;i<funcBeanList.size();i++) {
			funIdList.add(funcBeanList.get(i).getFuncId());
		}
		return funIdList;
	}
	
	public FuncBean getFuncBean(String funcId) {
		FuncBean funcBean = null;
		for(int i=0;i<funcBeanList.size();i++) {
			if(funcId != null && funcId.equals(funcBeanList.get(i).getFuncId())){
				funcBean = funcBeanList.get(i);
			}
		}
		return funcBean;
	}
	public boolean isFunIdExist(String funcId){
		for(int i=0;i<funcBeanList.size();i++) {
			if(funcId != null && funcId.equals(funcBeanList.get(i).getFuncId())){
				return true;
			}
		}
		return false;
	}
	
	public void setFunBeanList(ArrayList<FuncBean> funcBeanList) {
		this.funcBeanList = funcBeanList;
	}

	public void addFunBean(FuncBean funcBean) {
		funcBeanList.add(funcBean);
	}
}
