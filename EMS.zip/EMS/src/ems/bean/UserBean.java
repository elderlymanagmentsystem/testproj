package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class UserBean extends BasicBean {
	
	private ArrayList<FuncBean> funcBeanList = new ArrayList<FuncBean>();
	private String rolId = "";
	
	public UserBean() {
		for(int i=0; i<EmsDB.EM_USE_USER_ACCT.length;i++) {
			fields.add(new Field(EmsDB.EM_USE_USER_ACCT[i]));
		}
	}
	
	public UserBean(String orgId, String userId, String pwd) {
		this();
		setOrgId(orgId);
		setUserId(userId);
		setPwd(pwd);
	}
	
	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}
	public String getUserId() {
		return getField("USE_ID").getFormValue();
	}
	public void setUserId(String userId) {
		getField("USE_ID").setFormValue(userId);
	}
	public String getPwd() {
		return getField("USE_PWD").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("USE_PWD").setFormValue(pwd);
	}
	
	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	public String getRolId() {
		return rolId;
	}
	
	public void setRolId(String rolId) {
		this.rolId = rolId;
	}

	public ArrayList<String> getFunIdList(){
		ArrayList<String> funIdList = new ArrayList<String>();
		for(int i=0;i<funcBeanList.size();i++) {
			funIdList.add(funcBeanList.get(i).getFuncId());
		}
		return funIdList;
	}
	
	public FuncBean getFuncBean(String funcId) {
		FuncBean funcBean = null;
		for(int i=0;i<funcBeanList.size();i++) {
			if(funcId != null && funcId.equals(funcBeanList.get(i).getFuncId())){
				funcBean = funcBeanList.get(i);
			}
		}
		return funcBean;
	}
	public boolean isFunIdExist(String funcId){
		for(int i=0;i<funcBeanList.size();i++) {
			if(funcId != null && funcId.equals(funcBeanList.get(i).getFuncId())){
				return true;
			}
		}
		return false;
	}
	
	public void setFunBeanList(ArrayList<FuncBean> funcBeanList) {
		this.funcBeanList = funcBeanList;
	}

	public void addFunBean(FuncBean funcBean) {
		funcBeanList.add(funcBean);
	}
}
