package ems.bean;

public class UserBean extends basicBean {
	
	
	public UserBean() {
		fields.add(new Field(new String[] {"userId", "�Τ�W��", "String", "50", "", "Y"}));		
		fields.add(new Field(new String[] {"pwd", "�Τ�K�X", "String", "50", "", "Y"}));
	}
	
	public UserBean(String userId, String pwd) {
		this();
		setUserId(userId);
		setPwd(pwd);
	}
	
	public String getUserId() {
		return getField("userId").getFormValue();
	}
	public void setUserId(String userId) {
		getField("userId").setFormValue(userId);
	}
	public String getPwd() {
		return getField("pwd").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("pwd").setFormValue(pwd);
	}
	
	public boolean isValidUser() {
		if ("123".equals(getPwd())) {
			return true;
		}
		return false;
	}
}
