package ems.bean;

public class UserBean extends BasicBean {
	
	
	public UserBean() {
		fields.add(new Field(new String[] {"userId", "用户名稱", "String", "50", "", "Y"}));		
		fields.add(new Field(new String[] {"pwd", "用户密碼", "String", "50", "", "Y"}));
	}
	
	public UserBean(String userId, String pwd) {
		this();
		setUserId(userId);
		setPwd(pwd);
	}
	
	public String getUserId() {
		return getField("userId").getFormValue();
	}
	public void setUserId(String userId) {
		getField("userId").setFormValue(userId);
	}
	public String getPwd() {
		return getField("pwd").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("pwd").setFormValue(pwd);
	}
	
}
