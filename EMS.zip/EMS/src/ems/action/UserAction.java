package ems.action;

import java.io.File;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.UserModule;


public class UserAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private UserGrpBean userGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "010300";
	
	
	public String execute()
	{
		UserBean userBean = (UserBean)session.get("userBean");
		
		UserModule userMod = new UserModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			userMod.performEnqUserGrp(userGrpBean);
//		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
//			userMod.performAddOrg(userGrpBean, userBean)
//		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
//			userMod.performModOrg(userGrpBean, userBean)
		}

		if(userGrpBean.getMsg()==null||userGrpBean.getMsg().length()==0) {
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);

			return SUCCESS;
			
			
		}else {
			addActionError(userGrpBean.getMsg());

			request.setAttribute("funcId", funcId);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(userGrpBean==null)
			userGrpBean = new UserGrpBean();
		
		for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
			userGrpBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).setFormValue(request.getParameter(EmsDB.EM_ORG_ORGANIZATION[i][0]));
		}
			
		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)))
			if(!userGrpBean.validate()) {
				request.setAttribute("funcId", funcId);
				addActionError(userGrpBean.getMsg());
			}
	}

	public UserGrpBean getUserGrpBean() {
		return userGrpBean;
	}

	public void setUserGrpBean(UserGrpBean userGrpBean) {
		this.userGrpBean = userGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

}
