package ems.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.OrgBean;
import ems.db.EmsDB;
import ems.module.OrgModule;

public class OrgAction extends ActionSupport implements SessionAware, ServletRequestAware {
	private OrgBean orgBean;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	 
	public String execute()
	{
		String funcId = request.getParameter("funcId");
		request.setAttribute("funcId", funcId);

		OrgModule orgMod = new OrgModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			orgMod.performEnqOrg(orgBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			orgMod.performAddOrg(orgBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			orgMod.performModOrg(orgBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_INACT)){
			orgMod.performInactOrg(orgBean);			
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_REACT)){
			orgMod.performReactOrg(orgBean);			
		}

		if(orgBean.getMsg()==null||orgBean.getMsg().length()==0) {
			addActionMessage("");

			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);

			return SUCCESS;
		}else {
			addActionError(orgBean.getMsg());

			request.setAttribute("funcId", funcId);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		String funcId = request.getParameter("funcId");
		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)))
			if(!orgBean.validate()) {
				request.setAttribute("funcId", funcId);
				addActionError(orgBean.getMsg());
			}
	}

	public OrgBean getOrgBean() {
		return orgBean;
	}

	public void setOrgBean(OrgBean orgBean) {
		this.orgBean = orgBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}
	
}
