package ems.action;

import java.util.Map;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;

public class LoginAction extends ActionSupport implements SessionAware {
	private UserBean userBean;
	private Map<String, Object> session;
	 
	public String execute()
	{
		if (userBean != null && userBean.isValidUser()) {
			session.put("userBean", userBean);
			return SUCCESS;
		} else {
			return INPUT;
		}
		
		//UserBean userBean = (UserBean) session.get("userBean");
		/*
		UserBean userBean = (UserBean) session.get("userBean");
		if (userBean != null) {
			System.out.println("userBean exists");
		} else {
			System.out.println("userBean null");
		}
		
		if (userBean != null)
			System.out.println("execute try login " + userBean.getUserId());
		else
			System.out.println("execute null");
		return SUCCESS;
		*/
	}
	 
	public void validate() {
		/*
		if(userBean.validate())
			addActionMessage("Welcome Admin, do some work.");
		else
			addActionError("Error Error!!!");
		*/
		
		/*
		if (userName != null && userName.length() == 0) {
			
		}
		String a = getUserName();
		if (userBean != null)
			System.out.println("validate" + userBean.getMyVar());
		else
			System.out.println("validate null");
			*/
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
}
