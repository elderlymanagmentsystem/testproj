package ems.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;
import ems.module.LoginModule;

public class LoginAction extends ActionSupport implements SessionAware, ServletRequestAware {
	private UserBean userBean;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	
	public String execute()
	{
		System.out.println(request.getParameter("actionType"));
		request.setAttribute("actionType", request.getParameter("actionType"));
		
		LoginModule loginMod = new LoginModule();
		if (userBean != null && loginMod.performLogin(userBean)) {
			session.put("userBean", userBean);
			addActionMessage("成功登入");
			return SUCCESS;
		} else {
			addActionError("用戶名稱或密碼錯誤");
			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		if(!userBean.validate())
			addActionError(userBean.getMsg());
		
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}
	
}
