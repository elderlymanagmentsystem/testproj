package ems.action;

import java.util.Map;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;
import ems.module.LoginModule;

public class LoginAction extends ActionSupport implements SessionAware {
	private UserBean userBean;
	private Map<String, Object> session;
	 
	public String execute()
	{
		LoginModule loginMod = new LoginModule();
		if (userBean != null && loginMod.performLogin(userBean)) {
			session.put("userBean", userBean);
			addActionMessage("success");
			return SUCCESS;
		} else {
			addActionError("用户名稱或密碼錯誤");
			return INPUT;
		}
		
		//UserBean userBean = (UserBean) session.get("userBean");
		/*
		UserBean userBean = (UserBean) session.get("userBean");
		if (userBean != null) {
			System.out.println("userBean exists");
		} else {
			System.out.println("userBean null");
		}
		
		if (userBean != null)
			System.out.println("execute try login " + userBean.getUserId());
		else
			System.out.println("execute null");
		return SUCCESS;
		*/
	}
	 
	public void validate() {
		
		if(!userBean.validate())
			addActionError(userBean.getMsg());
		
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
}
