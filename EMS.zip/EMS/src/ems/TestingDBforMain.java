package ems;
import java.sql.*;

import ems.util.DBUtil;

public class TestingDBforMain  {
	public static void main(String [] args) {
		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			String dbURL = "jdbc:sqlserver://localhost\\SQLEXPRESS;database=EMS_DB";
	        String user = "em_owner";
	        String pass = "owner_em";
	        conn = DriverManager.getConnection(dbURL, user, pass);
	        stmt = conn.createStatement();
	        String sql;
	        sql = "SELECT username, password from em_user_detail";
	        ResultSet rs = stmt.executeQuery(sql);
	        while(rs.next()){
	        	String username = rs.getString("username");
	            String password = rs.getString("password");
	            System.out.println(username + " "+ password);
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}
}
