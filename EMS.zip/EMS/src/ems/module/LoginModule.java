package ems.module;

import ems.bean.UserBean;

public class LoginModule {

	public boolean performLogin(UserBean userBean) {
		if ("123".equals(userBean.getPwd())) {
			return true;
		}
		return false;
	}
	
}
