package ems.module;

import java.util.ArrayList;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.OrgDB;
import ems.db.UserDB;

public class UserModule {

	public boolean performLogin(UserBean userBean) {
		UserDB userDB = new UserDB();
		userBean = userDB.getUserBean(userBean);
		if (userBean!=null && userBean.getFunIdList()!=null && userBean.getFunIdList().size()>0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performEnqUserGrp(UserGrpBean userGrpBean, ArrayList<String> accOrgList) {
		userGrpBean.setMsg("");
		UserDB userDB = new UserDB();
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, accOrgList);
		userGrpBean.setRolBeanList(userDB.getRolBeanList());
		OrgDB orgDB = new OrgDB();
		userGrpBean.setAccOrgBeanList(orgDB.getOrgBeanList(accOrgList));
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddUser(UserGrpBean userGrpBean, UserBean userBean, ArrayList<String> accOrgList) {
		userGrpBean.setMsg("");

//Update DB
		userGrpBean.getField("USE_MOD_BY").setValue(userBean.getUserId());
		userGrpBean.getPerBean().getField("PER_MOD_BY").setValue(userBean.getUserId());
		
		UserDB userDB = new UserDB();
		userGrpBean.setPerId(userDB.getNextPerId(userGrpBean.getOrgId()));
		userGrpBean.getPerBean().setPerId(userGrpBean.getPerId());
		userDB.performAddUser(userGrpBean);
		
//Retrieve new User List
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, accOrgList);
		userGrpBean.setRolBeanList(userDB.getRolBeanList());
		OrgDB orgDB = new OrgDB();
		userGrpBean.setAccOrgBeanList(orgDB.getOrgBeanList(accOrgList));
		
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performModUser(UserGrpBean userGrpBean, UserBean userBean, ArrayList<String> accOrgList) {
		userGrpBean.setMsg("");

//Update DB
		userGrpBean.getField("USE_MOD_BY").setValue(userBean.getUserId());
		userGrpBean.getPerBean().getField("PER_MOD_BY").setValue(userBean.getUserId());

		UserDB userDB = new UserDB();
		userDB.performModUser(userGrpBean);
		
//Retrieve new User List
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, accOrgList);
		userGrpBean.setRolBeanList(userDB.getRolBeanList());
		OrgDB orgDB = new OrgDB();
		userGrpBean.setAccOrgBeanList(orgDB.getOrgBeanList(accOrgList));
		
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
}
