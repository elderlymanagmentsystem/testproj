package ems.module;

import ems.bean.OrgBean;
import ems.db.OrgDB;

public class OrgModule {

	public boolean performEnqOrg(OrgBean orgBean) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performAddOrg(OrgBean orgBean) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performModOrg(OrgBean orgBean) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performInactOrg(OrgBean orgBean) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performReactOrg(OrgBean orgBean) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
}
