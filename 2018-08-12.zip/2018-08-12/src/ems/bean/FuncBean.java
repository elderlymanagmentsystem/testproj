package ems.bean;

import ems.db.EmsDB;

public class FuncBean extends BasicBean {
	
	
	public FuncBean() {
		for(int i=0; i<EmsDB.EM_FUN_FUNCTION.length;i++) {
			fields.add(new Field(EmsDB.EM_FUN_FUNCTION[i]));
		}
	}
	
	public String getFuncId() {
		return getField("FUN_ID").getFormValue();
	}
	public void setFuncId(String funcId) {
		getField("FUN_ID").setFormValue(funcId);
	}

	public String getFuncName() {
		String a = getField("FUN_NAME").getFormValue();
		return a;
	}
	public void setFuncName(String funcName) {
		getField("FUN_NAME").setFormValue(funcName);
	}
	
}
