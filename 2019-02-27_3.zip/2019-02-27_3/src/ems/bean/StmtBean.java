package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class StmtBean extends CitemBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
	public StmtBean() {
		for(int i=0; i<EmsDB.EM_STM_STATEMENT.length;i++) {
			if(getField(EmsDB.EM_STM_STATEMENT[i][0])==null)
				fields.add(new Field(EmsDB.EM_STM_STATEMENT[i]));
		}
	}

	
	
	public String getStmtId() {
		return getField("STM_ID").getFormValue();
	}
	public void setStmtId(String stmtId) {
		getField("STM_ID").setFormValue(stmtId);
	}

	public String getCitemId() {
		return getField("CHI_ID").getFormValue();
	}
	public void setCitemId(String citemId) {
		getField("CHI_ID").setFormValue(citemId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}
}
