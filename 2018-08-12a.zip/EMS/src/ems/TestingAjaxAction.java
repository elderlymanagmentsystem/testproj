package ems;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.PatBean;

public class TestingAjaxAction extends ActionSupport {
	private PatBean patBean;
	private int enqPerId;
	
	public String execute() throws Exception {
		this.patBean = new PatBean();
		this.patBean.getField("PER_ID").setValue(enqPerId);
		this.patBean.getField("PER_CHI_NAME").setValue("陳大文");
		
		return SUCCESS;
	}
	
	public PatBean getPatBean() {
		return patBean;
	}

	public void setPatBean(PatBean patBean) {
		this.patBean = patBean;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	
	
}
