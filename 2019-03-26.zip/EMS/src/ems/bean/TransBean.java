package ems.bean;

import ems.db.EmsDB;

public class TransBean extends BasicBean {
	
	
	public TransBean() {
		for(int i=0; i<EmsDB.EM_TRA_TRANSACTIONS.length;i++) {
			if(getField(EmsDB.EM_TRA_TRANSACTIONS[i][0])==null)
				fields.add(new Field(EmsDB.EM_TRA_TRANSACTIONS[i]));
		}
	}
	
	public String getTransId() {
		return getField("TRA_ID").getFormValue();
	}
	public void setTransId(String transId) {
		getField("TRA_ID").setFormValue(transId);
	}

	public String getPerId() {
		String a = getField("PER_ID").getFormValue();
		return a;
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}
	
	public String getOrgId() {
		String a = getField("ORG_ID").getFormValue();
		return a;
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}
	public String getTransMethodName() {
		String a = getField("TRA_METHOD").getFormValue();
		if(a!=null) {
			if("1".equals(a)) {
				a = "現金";
			}else if("2".equals(a)) {
				a = "支票";
			}else if("3".equals(a)) {
				a = "自動轉帳";
			}
		}else {
			a = "";
		}
		return a;
	}	
}
