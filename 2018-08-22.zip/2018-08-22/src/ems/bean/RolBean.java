package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class RolBean extends BasicBean {
	
	private ArrayList<FuncBean> funcBeanList = new ArrayList<FuncBean>();
//	private ArrayList<String> orgNameList = new ArrayList<String>();
		
	public RolBean() {
		for(int i=0; i<EmsDB.EM_ROL_ROLE.length;i++) {
			fields.add(new Field(EmsDB.EM_ROL_ROLE[i]));
		}
	}
	
	public String getRolId() {
		return getField("ROL_ID").getFormValue();
	}
	public void setRolId(String rolId) {
		getField("ROL_ID").setFormValue(rolId);
	}

	public String getRolName() {
		return getField("ROL_NAME").getFormValue();
	}
	public void setRolName(String rolName) {
		getField("ROL_NAME").setFormValue(rolName);
	}

	public ArrayList<String> getFunIdList(){
		ArrayList<String> funIdList = new ArrayList<String>();
		for(int i=0;i<funcBeanList.size();i++) {
			funIdList.add(funcBeanList.get(i).getFuncId());
		}
		return funIdList;
	}
	
	public ArrayList<FuncBean> getFuncBeanList(){
		return funcBeanList;
	}
	
	public FuncBean getFuncBean(String funcId){
		for(int i=0;i<funcBeanList.size();i++) {
			if(funcId != null && funcId.equals(funcBeanList.get(i).getFuncId())){
				return funcBeanList.get(i);
			}
		}
		return null;
	}
	
	public void setFuncBeanList(ArrayList<FuncBean> funcBeanList) {
		this.funcBeanList = funcBeanList;
	}

	public void addFuncBeanList(FuncBean funcBean) {
		funcBeanList.add(funcBean);
	}

	public boolean isFunIdExist(String funcId) {
		boolean isExist = false;

		for(int i=0;i<getFuncBeanList().size();i++) 
			if(getFuncBeanList().get(i).getFuncId().equals(funcId)) {
				isExist = true;
				break;
			}
				
		return isExist;
	}	
	
}
