package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class ResGrpBean extends PerBean {
	
	String enqPerType = "";
	String enqPerName = "";
	String enqPerId = "";
	String enqStartDate = "";
	String enqEndDate = "";
	String enqStatus = "";
	
	private ArrayList<BedBean> emptyBedBeanList = new ArrayList<BedBean>();
	private ArrayList<ResBean> reserveBeanList = new ArrayList<ResBean>();
	TransBean transBean = new TransBean();	
	
	public ResGrpBean() {
	}
	

	public String getEnqPerType() {
		return enqPerType;
	}


	public void setEnqPerType(String enqPerType) {
		this.enqPerType = enqPerType;
	}


	public String getEnqPerName() {
		return enqPerName;
	}

	public void setEnqPerName(String enqPerName) {
		this.enqPerName = enqPerName;
	}

	public String getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(String enqPerId) {
		this.enqPerId = enqPerId;
	}

	public ArrayList<ResBean> getReserveBeanList(){
		return reserveBeanList;
	}
	
	public void setReserveBeanList(ArrayList<ResBean> reserveBeanList) {
		this.reserveBeanList = reserveBeanList;
	}

	public void addReserveBeanList(ResBean resBean) {
		reserveBeanList.add(resBean);
	}


	
	
	public ArrayList<BedBean> getEmptyBedBeanList(){
		return emptyBedBeanList;
	}
	
	public void setEmptyBedBeanList(ArrayList<BedBean> emptyBedBeanList) {
		this.emptyBedBeanList = emptyBedBeanList;
	}

	public void addEmptyBedBeanList(BedBean bedBean) {
		emptyBedBeanList.add(bedBean);
	}

	public BedBean getEmptyBedBean(String bedId, String orgId){
		for(int i=0;i<emptyBedBeanList.size();i++) {
			if(bedId != null && orgId != null && bedId.equals(emptyBedBeanList.get(i).getBedId()) && orgId.equals(emptyBedBeanList.get(i).getOrgId())){
				return emptyBedBeanList.get(i);
			}
		}
		return null;
	}
	
	public ResBean getResBean(String resId, String orgId){
		for(int i=0;i<reserveBeanList.size();i++) {
			if(resId != null && orgId != null && resId.equals(reserveBeanList.get(i).getResId()) && orgId.equals(reserveBeanList.get(i).getOrgId())){
				return reserveBeanList.get(i);
			}
		}
		return null;
	}
	
	public void cleanup() {
		setPcoBeanList(new ArrayList<PcoBean>());
		setResBeanList(new ArrayList<ResBean>());
		super.cleanup();
	}
	
	public String getEnqStartDate() {
		return enqStartDate;
	}


	public void setEnqStartDate(String enqStartDate) {
		this.enqStartDate = enqStartDate;
	}


	public String getEnqEndDate() {
		return enqEndDate;
	}


	public void setEnqEndDate(String enqEndDate) {
		this.enqEndDate = enqEndDate;
	}


	public String getEnqStatus() {
		return enqStatus;
	}


	public void setEnqStatus(String enqStatus) {
		this.enqStatus = enqStatus;
	}


	public TransBean getTransBean() {
		return transBean;
	}


	public void setTransBean(TransBean transBean) {
		this.transBean = transBean;
	}


	public boolean validate() {
		boolean successFlag = true;
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
