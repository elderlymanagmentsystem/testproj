package ems.action;

import com.opensymphony.xwork2.ActionSupport;

import ems.bean.AccBalBean;
import ems.bean.LivBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PerBean;
import ems.bean.ResBean;
import ems.bean.ResGrpBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.db.EmsDB;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;
import ems.util.EmsCommonUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

public class IncAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private PatGrpBean patGrpBean;
	private ResGrpBean resGrpBean;
	private UserBean userBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private String flag;
	private String enqType;
	private String enqFrom;
	private String enqTo;
	
	public static final String DEFAULT_FUNC_ID = "050300";
	
	public String execute() throws Exception {
		
		patGrpBean = new PatGrpBean();
		resGrpBean = new ResGrpBean();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;		
		
		int pos = 1;
		String sql = "";
		
		if ("Y".equals(flag)) {
			
			try {
				
			
				conn = DBUtil.getDataSource().getConnection();
				
				if("A".equals(enqType)) {
					sql = "SELECT PAT.PAT_ID, PER.ORG_ID, PER.PER_ID, PER.PER_CHI_NAME, LIV.LIV_STATUS, LIV.LIV_START_DATE, BED.BED_NAME, ZON.ZON_NAME, ACC_BALANCE, ACC_BAL_EXC30, ACC_BAL_EXC60 " + 
							"FROM EM_ACC_BALANCE ACC, EM_PER_PERSONAL_PARTICULAR PER, EM_PAT_PATIENT_INFO PAT, EM_LIV_RECORD LIV, EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
							"WHERE ACC.PER_ID = PER.PER_ID AND ACC.ORG_ID = PER.ORG_ID "
							+ "AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID "
							+ "AND LIV.PAT_ID = PAT.PAT_ID AND LIV.ORG_ID = PER.ORG_ID "
							+ "AND LIV.BED_ID = BED.BED_ID AND LIV.ORG_ID = BED.ORG_ID AND LIV.ZON_ID = BED.ZON_ID "
							+ "AND LIV.ZON_ID = ZON.ZON_ID AND LIV.ORG_ID = ZON.ORG_ID "
							+ "AND ACC.ORG_ID = ? "
							+ "ORDER BY PAT_ID ";
						
					pst = conn.prepareStatement(sql);
					
					pst.setString(pos++, userBean.getAccOrgId());
					
					rs = pst.executeQuery();
					
					while(rs.next()){
						
						PatBean patBean = new PatBean();
						patBean.setPerId(rs.getString("PER_ID"));
						patBean.setPatId(rs.getString("PAT_ID"));
						patBean.setOrgId(rs.getString("ORG_ID"));
						patBean.getField("PER_CHI_NAME").setFormValue(rs.getString("PER_CHI_NAME"));
						
						LivBean livBean = new LivBean();
						if(rs.getString("LIV_STATUS").equals("Y"))
							livBean.getField("LIV_STATUS").setFormValue("入住中");
						else
							livBean.getField("LIV_STATUS").setFormValue("已退院");
						
						livBean.getField("LIV_START_DATE").setFormValue(rs.getString("LIV_START_DATE"));
						livBean.getBedBean().setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
						patBean.addLivBeanList(livBean);
						
						AccBalBean accBalBean = new AccBalBean();
						accBalBean.getField("ACC_BALANCE").setFormValue(rs.getString("ACC_BALANCE"));
						accBalBean.getField("ACC_BAL_EXC30").setFormValue(rs.getString("ACC_BAL_EXC30"));
						accBalBean.getField("ACC_BAL_EXC60").setFormValue(rs.getString("ACC_BAL_EXC60"));
						
						patBean.setAccBalBean(accBalBean);
						patGrpBean.addPatBeanList(patBean);
						
					}
				}else if("D".equals(enqType)){
					sql = "SELECT PAT.PAT_ID, PER.ORG_ID, PER.PER_ID, PER.PER_CHI_NAME, LIV.LIV_STATUS, LIV.LIV_START_DATE, BED.BED_NAME, ZON.ZON_NAME, ACC_DEPOSIT " + 
							"FROM EM_ACC_BALANCE ACC, EM_PER_PERSONAL_PARTICULAR PER, EM_PAT_PATIENT_INFO PAT, EM_LIV_RECORD LIV, EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
							"WHERE ACC.PER_ID = PER.PER_ID AND ACC.ORG_ID = PER.ORG_ID AND ACC.ACC_DEPOSIT IS NOT NULL AND ACC.ACC_DEPOSIT > 0"
							+ "AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID "
							+ "AND LIV.PAT_ID = PAT.PAT_ID AND LIV.ORG_ID = PER.ORG_ID "
							+ "AND LIV.BED_ID = BED.BED_ID AND LIV.ORG_ID = BED.ORG_ID AND LIV.ZON_ID = BED.ZON_ID "
							+ "AND LIV.ZON_ID = ZON.ZON_ID AND LIV.ORG_ID = ZON.ORG_ID "
							+ "AND ACC.ORG_ID = ? "
							+ "ORDER BY PAT_ID ";
						
					pst = conn.prepareStatement(sql);
					
					pst.setString(pos++, userBean.getAccOrgId());
					
					rs = pst.executeQuery();
					
					while(rs.next()){
						
						PatBean patBean = new PatBean();
						patBean.setPerId(rs.getString("PER_ID"));
						patBean.setPatId(rs.getString("PAT_ID"));
						patBean.setOrgId(rs.getString("ORG_ID"));
						patBean.getField("PER_CHI_NAME").setFormValue(rs.getString("PER_CHI_NAME"));
						
						LivBean livBean = new LivBean();
						if(rs.getString("LIV_STATUS").equals("Y"))
							livBean.getField("LIV_STATUS").setFormValue("入住中");
						else
							livBean.getField("LIV_STATUS").setFormValue("已退院");
						
						livBean.getField("LIV_START_DATE").setFormValue(rs.getString("LIV_START_DATE"));
						livBean.getBedBean().setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
						patBean.addLivBeanList(livBean);
						
						AccBalBean accBalBean = new AccBalBean();
						accBalBean.getField("ACC_DEPOSIT").setFormValue(rs.getString("ACC_DEPOSIT"));
						
						patBean.setAccBalBean(accBalBean);
						patGrpBean.addPatBeanList(patBean);
					}
				}else if("R".equals(enqType)){
					sql = "SELECT PER.ORG_ID, PER.PER_ID, PER.PER_CHI_NAME, RES.RES_ID, RES.RES_STATUS, RES.RES_START_DATE, BED.BED_NAME, ZON.ZON_NAME, TRA_AMOUNT, TRA_RECEIPT_ID " + 
							"FROM EM_TRA_TRANSACTIONS TRA, EM_PER_PERSONAL_PARTICULAR PER, EM_RES_RECORD RES, EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
							"WHERE TRA.PER_ID = PER.PER_ID AND TRA.ORG_ID = PER.ORG_ID AND TRA.TRA_STATUS = 'Y' AND TRA.TRA_TYPE = 'R' "
							+ "AND RES.RES_ID = TRA.RES_ID AND RES.ORG_ID = TRA.ORG_ID "
							+ "AND RES.BED_ID = BED.BED_ID AND RES.ORG_ID = BED.ORG_ID AND RES.ZON_ID = BED.ZON_ID "
							+ "AND RES.ZON_ID = ZON.ZON_ID AND RES.ORG_ID = ZON.ORG_ID "
							+ "AND TRA.ORG_ID = ? "
							+ "ORDER BY TRA_ID ";
						
					pst = conn.prepareStatement(sql);
					
					pst.setString(pos++, userBean.getAccOrgId());
					
					rs = pst.executeQuery();
					
					while(rs.next()){
						
						if(resGrpBean.getResBean(rs.getString("RES_ID"), rs.getString("ORG_ID")) == null) {
							ResBean resBean = new ResBean();
							resBean.setPerId(rs.getString("PER_ID"));
							resBean.setResId(rs.getString("RES_ID"));
							resBean.setOrgId(rs.getString("ORG_ID"));
							resBean.getPerBean().getField("PER_CHI_NAME").setFormValue(rs.getString("PER_CHI_NAME"));
							
							if(rs.getString("RES_STATUS").equals("Y"))
								resBean.getField("RES_STATUS").setFormValue("訂位中");
							else if(rs.getString("RES_STATUS").equals("N"))
								resBean.getField("RES_STATUS").setFormValue("已取消");
							else 
								resBean.getField("RES_STATUS").setFormValue("已完成");
							
							resBean.getField("RES_START_DATE").setFormValue(rs.getString("RES_START_DATE"));
							resBean.getBedBean().setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
							
							TransBean transBean = new TransBean();
							transBean.getField("TRA_AMOUNT").setFormValue(rs.getString("TRA_AMOUNT"));
							transBean.getField("TRA_RECEIPT_ID").setFormValue(rs.getString("TRA_RECEIPT_ID"));
						
							resBean.getPerBean().addTransBeanList(transBean);
							resGrpBean.addReserveBeanList(resBean);
						}else {
							ResBean resBean = resGrpBean.getResBean(rs.getString("RES_ID"), rs.getString("ORG_ID"));
							
							TransBean transBean = new TransBean();
							transBean.getField("TRA_AMOUNT").setFormValue(rs.getString("TRA_AMOUNT"));
							transBean.getField("TRA_RECEIPT_ID").setFormValue(rs.getString("TRA_RECEIPT_ID"));
							
							resBean.getPerBean().addTransBeanList(transBean);
							
						}
						
						
					}				
				}else if("S".equals(enqType)){
					sql = "SELECT PAT.PAT_ID, PER.ORG_ID, PER.PER_ID, PER.PER_CHI_NAME, TRA_DATE, TRA_NAME, TRA_AMOUNT, TRA_RECEIPT_ID, TRA_METHOD, TRA_NOTE " + 
							"FROM EM_TRA_TRANSACTIONS TRA, EM_PER_PERSONAL_PARTICULAR PER, EM_PAT_PATIENT_INFO PAT " + 
							"WHERE TRA.PER_ID = PER.PER_ID AND TRA.ORG_ID = PER.ORG_ID AND TRA.TRA_STATUS = 'Y' AND TRA.TRA_TYPE = 'S' AND TRA.TRA_RECEIPT_ID IS NOT NULL "
							+ "AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID "
							+ "AND TRA.ORG_ID = ? " ;
						
					if(!"".equals(enqFrom))
						sql = sql + "AND TRA.TRA_DATE > ? "; 
	
					if(!"".equals(enqTo))
						sql = sql + "AND TRA.TRA_DATE < ? "; 
	
					sql = sql + "ORDER BY TRA_ID" ;
					
					pst = conn.prepareStatement(sql);
					
					pst.setString(pos++, userBean.getAccOrgId());
	
					if(!"".equals(enqFrom))
						pst.setDate(pos++, (Date)DataTypeUtil.formDate2BeanDate(enqFrom));
					
					if(!"".equals(enqTo)) 
						pst.setDate(pos++, (Date)DataTypeUtil.formDate2BeanDate(enqTo));
					
					
					rs = pst.executeQuery();
					
					while(rs.next()){
						
						PatBean patBean = new PatBean();
						patBean.setPerId(rs.getString("PER_ID"));
						patBean.setPatId(rs.getString("PAT_ID"));
						patBean.setOrgId(rs.getString("ORG_ID"));
						patBean.getField("PER_CHI_NAME").setFormValue(rs.getString("PER_CHI_NAME"));
						
						TransBean transBean = new TransBean();
						transBean.getField("TRA_NAME").setFormValue(rs.getString("TRA_NAME"));
						transBean.getField("TRA_DATE").setFormValue(rs.getString("TRA_DATE"));
						transBean.getField("TRA_AMOUNT").setFormValue(rs.getString("TRA_AMOUNT"));
						transBean.getField("TRA_RECEIPT_ID").setFormValue(rs.getString("TRA_RECEIPT_ID"));
						transBean.getField("TRA_METHOD").setFormValue(rs.getString("TRA_METHOD"));
						transBean.getField("TRA_NOTE").setFormValue(rs.getString("TRA_NOTE"));
						
						patBean.addTransBeanList(transBean);
						
						patGrpBean.addPatBeanList(patBean);
							
					}				
	
				
				}
			}catch(SQLException se){
				se.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
	        } finally {
	            try {
	                if (conn != null && !conn.isClosed()) {
	                    conn.close();
	                }
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	            try {
	        		rs.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	            try {
	            	pst.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
		}
		
		addActionMessage("");

		if(funcId.length()==6)
			funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
		request.setAttribute("funcId", funcId);
		request.setAttribute("patGrpBean", patGrpBean);
		request.setAttribute("resGrpBean", resGrpBean);
		request.setAttribute("enqType", enqType);
		request.setAttribute("enqFrom", enqFrom);
		request.setAttribute("enqTo", enqTo);

		return SUCCESS;
			
	}
	
	public void validate() {
		userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(patGrpBean==null)
			patGrpBean = new PatGrpBean();

		if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
			userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
		}		
	
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public String getEnqType() {
		return enqType;
	}

	public void setEnqType(String enqType) {
		this.enqType = enqType;
	}

	public String getEnqFrom() {
		return enqFrom;
	}

	public void setEnqFrom(String enqFrom) {
		this.enqFrom = enqFrom;
	}

	public String getEnqTo() {
		return enqTo;
	}

	public void setEnqTo(String enqTo) {
		this.enqTo = enqTo;
	}

	
}
