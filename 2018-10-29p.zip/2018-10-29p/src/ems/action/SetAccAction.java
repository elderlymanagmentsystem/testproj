package ems.action;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.AccGrpBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.QuoBean;
import ems.bean.ResBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.AccModule;
import ems.module.BedModule;
import ems.module.UserModule;


public class SetAccAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private AccGrpBean accGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "030400";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		AccModule accMod = new AccModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			accMod.performEnqCitemList(accGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			accMod.performAddOrUpdateCitem(accGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			accMod.performAddOrUpdateCitem(accGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL)){
			accMod.performInactCitem(accGrpBean, userBean);			
		}

		if(accGrpBean.getMsg()==null||accGrpBean.getMsg().length()==0) {
			accGrpBean.cleanup();
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("accGrpBean", accGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(accGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("accGrpBean", accGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(accGrpBean==null)
			accGrpBean = new AccGrpBean();

		accGrpBean.setMsg("");
		
		for(int i=0;i<accGrpBean.getFields().size();i++){
			accGrpBean.getFields().get(i).setFormValue(request.getParameter(accGrpBean.getFields().get(i).getName()));
		}

		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {
			
			accGrpBean.setOrgId(userBean.getAccOrgId());
			
			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)) {

				if(!accGrpBean.validate())
					validated = false;
			}

			if((funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL)) && accGrpBean.getCitemId().length()==0) {
				accGrpBean.getField("CHI_ID").setMsg("必需輸入");
				accGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(!validated) {
				AccModule accMod = new AccModule();
				accMod.performEnqCitemList(accGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("accGrpBean", accGrpBean);
				addActionError(accGrpBean.getMsg());
			}					

		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public AccGrpBean getAccGrpBean() {
		return accGrpBean;
	}

	public void setAccGrpBean(AccGrpBean accGrpBean) {
		this.accGrpBean = accGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}


}
