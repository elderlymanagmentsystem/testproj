package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import ems.bean.AccGrpBean;
import ems.bean.BedBean;
import ems.bean.CitemBean;
import ems.bean.FuncBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.QuoBean;
import ems.bean.QuoGrpBean;
import ems.bean.RolBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.util.DBUtil;

public class AccDB{

	public AccGrpBean performEnqCitemList(AccGrpBean accGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			accGrpBean.setCitemBeanList(new ArrayList<CitemBean>());
			
			String sql = "SELECT CHI_ID, ORG_ID, CHI.CHC_ID, CHI_NAME, CHI_UNIT, CHI_UNIT_PRICE, CHI_REMARK, CHI_STATUS, CHI_MOD_BY, CHI_MOD_DATE, " + 
					"					CHC_NAME, CHC_STATUS, CHC_MOD_BY, CHC_MOD_DATE " + 
					"					FROM EM_CHI_CHARGE_ITEM CHI, EM_CHC_CHARGE_CAT CHC" + 
					"					WHERE CHI.CHI_STATUS = 'Y' AND CHI.ORG_ID = ? " +
					"					AND CHC.CHC_STATUS = 'Y' AND CHC.ORG_ID = CHI.ORG_ID AND CHC.CHC_ID = CHI.CHC_ID "; 
					
					if(accGrpBean.getEnqCitemCat()!=null && accGrpBean.getEnqCitemCat().length()>0) {
						sql = sql + "AND CHI.CHC_ID = ? ";
					}
					
					if(accGrpBean.getEnqCitemName()!=null && accGrpBean.getEnqCitemName().length()>0) {
						if("I".equals(accGrpBean.getEnqCitemType()))
							sql = sql + "AND CHI.CHI_NAME LIKE ? ";
						else if("P".equals(accGrpBean.getEnqCitemType()))
							sql = sql + "AND CHI.CHI_UNIT_PRICE = ? ";
						else if("U".equals(accGrpBean.getEnqCitemType())) 
							sql = sql + "AND CHI.CHI_UNIT LIKE ? ";
						else if("R".equals(accGrpBean.getEnqCitemType()))  
							sql = sql + "AND CHI.CHI_REMARK LIKE ? ";
					}
					
					sql = sql+ "	  ORDER BY CHI.CHC_ID, CHI.CHI_ID ";
					
					
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));

			
			if(accGrpBean.getEnqCitemCat()!=null && accGrpBean.getEnqCitemCat().length()>0) {
				pst.setInt(pos++, Integer.parseInt(accGrpBean.getEnqCitemCat())); 
			}

			if(accGrpBean.getEnqCitemName()!=null && accGrpBean.getEnqCitemName().length()>0) {
				if("I".equals(accGrpBean.getEnqCitemType()))
					pst.setString(pos++, "%"+accGrpBean.getEnqCitemName()+"%");
				else if("P".equals(accGrpBean.getEnqCitemType()))
					pst.setBigDecimal(pos++, new BigDecimal(accGrpBean.getEnqCitemName()));
				else if("U".equals(accGrpBean.getEnqCitemType())) 
					pst.setString(pos++, "%"+accGrpBean.getEnqCitemName()+"%");
				else if("R".equals(accGrpBean.getEnqCitemType()))  
					pst.setString(pos++, "%"+accGrpBean.getEnqCitemName()+"%");
			}
			
			rs = pst.executeQuery();
			while(rs.next()){
				
				CitemBean citemBean = new CitemBean();
				for(int i=0;i<citemBean.getFields().size();i++) {
					citemBean.getFields().get(i).setFormValue(rs.getString(citemBean.getFields().get(i).getName()));
				}
				accGrpBean.addCitemBeanList(citemBean);
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return accGrpBean;
	}

	
	public String getNextCitemId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String citemId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(CHI_ID)+1 NEW_CHI_ID FROM EM_CHI_CHARGE_ITEM WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_CHI_ID")!=null)
	        		citemId = rs.getString("NEW_CHI_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return citemId;
	}	
	
	public String getNextCitemCatId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String chcId = "1";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(CHC_ID)+1 NEW_CHC_ID FROM EM_CHC_CHARGE_CAT WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_CHC_ID")!=null)
	        		chcId = rs.getString("NEW_CHC_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return chcId;
	}	
	
	public AccGrpBean performAddCitem(AccGrpBean accGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			pos = 1;
			String sql = "INSERT INTO EM_CHI_CHARGE_ITEM CHI ( ";
					for(int i=0;i<EmsDB.EM_CHI_CHARGE_ITEM.length-1;i++) {
						if(i != EmsDB.EM_CHI_CHARGE_ITEM.length-2)
							sql = sql + EmsDB.EM_CHI_CHARGE_ITEM[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_CHI_CHARGE_ITEM[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_CHI_CHARGE_ITEM.length-1;i++) {
						if(i != EmsDB.EM_CHI_CHARGE_ITEM.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_CHI_CHARGE_ITEM.length-1;i++) {
				
				if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else
					pst.setString(pos++, (String)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				accGrpBean.setMsg("不能新增項");
			}

		}catch(SQLException se){
			accGrpBean.setMsg("不能新增項目");
			se.printStackTrace();
		}catch(Exception e){
			accGrpBean.setMsg("不能新增項目");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return accGrpBean;
	}		

	public AccGrpBean performModCitem(AccGrpBean accGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Patient 
			String sql = "UPDATE EM_CHI_CHARGE_ITEM CHI SET ";
					for(int i=2;i<EmsDB.EM_CHI_CHARGE_ITEM.length-1;i++) {
						if(i != EmsDB.EM_CHI_CHARGE_ITEM.length-2)
							sql = sql + EmsDB.EM_CHI_CHARGE_ITEM[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_CHI_CHARGE_ITEM[i][0] + " = ? ";
					}
					sql = sql + "WHERE CHI.CHI_ID = ? AND CHI.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_CHI_CHARGE_ITEM.length-1;i++) {
				
				if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else if(EmsDB.EM_CHI_CHARGE_ITEM[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getValue());
				else
					pst.setString(pos++, (String)accGrpBean.getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(accGrpBean.getCitemId()));
			pst.setInt(pos++, Integer.parseInt(accGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				accGrpBean.setMsg("不能更新項目");
			}
		}catch(SQLException se){
			accGrpBean.setMsg("不能更新項目");
			se.printStackTrace();
		}catch(Exception e){
			accGrpBean.setMsg("不能更新項目");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return accGrpBean;
	}	

	public AccGrpBean performInactCitem(AccGrpBean accGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Pat
			String sql = "UPDATE EM_CHI_CHARGE_ITEM CHI SET CHI_STATUS = 'N', CHI_MOD_BY = ? WHERE CHI.CHI_ID = ? AND CHI.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, userBean.getUserId());
			pst.setInt(pos++, Integer.parseInt(accGrpBean.getCitemId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				accGrpBean.setMsg("不能更新項目");
			}
		}catch(SQLException se){
			accGrpBean.setMsg("不能更新項目");
			se.printStackTrace();
		}catch(Exception e){
			accGrpBean.setMsg("不能更新項目");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return accGrpBean;
	}	
		
	public AccGrpBean performAddCitemCat(AccGrpBean accGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			pos = 1;
			String sql = "INSERT INTO EM_CHC_CHARGE_CAT CHC ( ";
					for(int i=0;i<EmsDB.EM_CHC_CHARGE_CAT.length-1;i++) {
						if(i != EmsDB.EM_CHC_CHARGE_CAT.length-2)
							sql = sql + EmsDB.EM_CHC_CHARGE_CAT[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_CHC_CHARGE_CAT[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_CHC_CHARGE_CAT.length-1;i++) {
						if(i != EmsDB.EM_CHC_CHARGE_CAT.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_CHC_CHARGE_CAT.length-1;i++) {
				
				if(EmsDB.EM_CHC_CHARGE_CAT[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)accGrpBean.getField(EmsDB.EM_CHC_CHARGE_CAT[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_CHC_CHARGE_CAT[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)accGrpBean.getField(EmsDB.EM_CHC_CHARGE_CAT[i][0]).getValue());
				else if(EmsDB.EM_CHC_CHARGE_CAT[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)accGrpBean.getField(EmsDB.EM_CHC_CHARGE_CAT[i][0]).getValue());
				else if(EmsDB.EM_CHC_CHARGE_CAT[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)accGrpBean.getField(EmsDB.EM_CHC_CHARGE_CAT[i][0]).getValue());
				else
					pst.setString(pos++, (String)accGrpBean.getField(EmsDB.EM_CHC_CHARGE_CAT[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				accGrpBean.setMsg("不能新增分類");
			}

		}catch(SQLException se){
			accGrpBean.setMsg("不能新增分類");
			se.printStackTrace();
		}catch(Exception e){
			accGrpBean.setMsg("不能新增分類");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return accGrpBean;
	}		

}
