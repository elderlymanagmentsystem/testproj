package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.FuncBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PerBean;
import ems.bean.RolBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.util.DBUtil;

public class BedDB {

	public ZoneGrpBean performEnqZoneList(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT ORG_ID, ZON_ID, ZON_NAME, ZON_STATUS, ZON_MOD_BY, ZON_MOD_DATE, " + 
					"					BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " + 
					"					LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_AMOUNT, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"					PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"					PER_ID, PER_NAME, PER_GENDER, PER_BIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_STATUS, PER_MOD_BY, PER_MOD_DATE " + 
					"					FROM EM_ZON_ZONE ZON LEFT JOIN " + 
					"					       (SELECT BED.ORG_ID, BED.ZON_ID, BED.BED_ID, BED.BED_NAME, BED.BED_STATUS, BED.BED_MOD_BY, BED.BED_MOD_DATE, " + 
					"					        LIV_ID, LIV_START_DATE, LIV_END_DATE, LIV_AMOUNT, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"						PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"						PER_ID, PER_NAME, PER_GENDER, PER_BIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_STATUS, PER_MOD_BY, PER_MOD_DATE " + 
					"						FROM EM_BED_INFO BED LEFT JOIN " + 
					"							(SELECT LIV_ID, LIV.ORG_ID, LIV.ZON_ID, LIV.BED_ID, LIV_START_DATE, LIV_END_DATE, LIV_AMOUNT, LIV_STATUS, LIV_MOD_BY, LIV_MOD_DATE, " + 
					"							PAT_ID, PAT_STATUS, PAT_MOD_BY, PAT_MOD_DATE, " + 
					"							PER.PER_ID, PER.PER_NAME, PER.PER_GENDER, PER.PER_BIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE " + 
					"							FROM EM_LIV_RECORD LIV, EM_PAT_PATIENT_INFO PAT, EM_PER_PERSONAL_PARTICULAR PER " + 
					"							WHERE LIV.PAT_ID = PAT.PAT_ID AND LIV.ORG_ID = PAT.ORG_ID AND LIV_STATUS = 'Y' AND PAT_STATUS = 'Y' " + 
					"							AND PAT.PER_ID = PER.PER_ID AND PAT.ORG_ID = PER.ORG_ID) LIV " + 
					"							ON BED.ORG_ID = LIV.ORG_ID AND BED.ZON_ID = LIV.ZON_ID AND BED.BED_ID = LIV.BED_ID " + 
					"						WHERE BED.BED_STATUS = 'Y' AND BED.ORG_ID = ?) BED" + 
					"					ON ZON.ORG_ID = BED.ORG_ID AND ZON.ZON_ID = BED.ZON_ID " + 
					"					WHERE ZON.ZON_STATUS = 'Y' AND ZON.ORG_ID = ?" + 
					"					ORDER BY ZON.ZON_ID, BED.BED_ID ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			rs = pst.executeQuery();
			zoneGrpBean.setZoneBeanList(new ArrayList<ZoneBean>());
			while(rs.next()){
				String zoneId = rs.getString("ZON_ID");
				String bedId = rs.getString("BED_ID");
				String livId = rs.getString("LIV_ID");
				String orgId = rs.getString("ORG_ID");
				
				ZoneBean zoneBean = zoneGrpBean.getZoneBean(zoneId, orgId);
				if(zoneBean == null) {
					zoneBean = new ZoneBean();
					for(int i=0;i<zoneBean.getFields().size();i++) {
						zoneBean.getFields().get(i).setFormValue(rs.getString(zoneBean.getFields().get(i).getName()));
					}
					zoneGrpBean.addZoneBeanList(zoneBean);
				}
				
				BedBean bedBean = zoneBean.getBedBean(bedId);
				if(bedBean == null && bedId != null && bedId.length()>0) {
					bedBean = new BedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					zoneBean.addBedBeanList(bedBean);
				
					LivBean livBean = bedBean.getLivBean(livId, orgId);
					if(livBean == null && livId != null && livId.length()>0) {
						livBean = new LivBean();
						for(int i=0;i<livBean.getFields().size();i++) {
							livBean.getFields().get(i).setFormValue(rs.getString(livBean.getFields().get(i).getName()));
						}
						bedBean.addLivBeanList(livBean);
					
						PatBean patBean = livBean.getPatBean();
						for(int i=0;i<patBean.getFields().size();i++) {
							patBean.getFields().get(i).setFormValue(rs.getString(patBean.getFields().get(i).getName()));
						}
					}
				}
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}

	public String getNextZoneId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String zoneId = "1";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(ZON_ID)+1 NEW_ZON_ID FROM EM_ZON_ZONE WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_ZON_ID")!=null)
	        		zoneId = rs.getString("NEW_ZON_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneId;
	}	
	
	public String getNextBedId(String orgId, String zoneId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String bedId = "101";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(BED_ID)+1 NEW_BED_ID FROM EM_BED_INFO WHERE ORG_ID = ? AND ZON_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			pst.setInt(pos++, Integer.parseInt(zoneId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_BED_ID")!=null)
	        		bedId = rs.getString("NEW_BED_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return bedId;
	}		
	
	public ZoneGrpBean performAddZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_ZON_ZONE ZON ( ";
					for(int i=0;i<EmsDB.EM_ZON_ZONE.length-1;i++) {
						if(i != EmsDB.EM_ZON_ZONE.length-2)
							sql = sql + EmsDB.EM_ZON_ZONE[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_ZON_ZONE[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_ZON_ZONE.length-1;i++) {
						if(i != EmsDB.EM_ZON_ZONE.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_ZON_ZONE.length-1;i++) {
				
				if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else
					pst.setString(pos++, (String)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				zoneGrpBean.setMsg("不能新增區域");
			}
			
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能新增區域");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能新增區域");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}		
		
	public ZoneGrpBean performAddBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		if(zoneGrpBean.getBedBeanList()==null || zoneGrpBean.getBedBeanList().size()==0)
			return zoneGrpBean;
			
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_BED_INFO BED ( ";
					for(int i=0;i<EmsDB.EM_BED_INFO.length-1;i++) {
						if(i != EmsDB.EM_BED_INFO.length-2)
							sql = sql + EmsDB.EM_BED_INFO[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_BED_INFO[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_BED_INFO.length-1;i++) {
						if(i != EmsDB.EM_BED_INFO.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

				pst = conn.prepareStatement(sql);
				
				for(int i=0;i<zoneGrpBean.getBedBeanList().size();i++) {
					BedBean bedBean = zoneGrpBean.getBedBeanList().get(i);
					pos = 1;
					for(int j=0;j<EmsDB.EM_BED_INFO.length-1;j++) {
						
						if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Integer")) {
							pst.setObject(pos++, (Integer)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue(), java.sql.Types.INTEGER);
						}else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Date"))
							pst.setDate(pos++, (Date)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
						else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("BigDecimal"))
							pst.setBigDecimal(pos++, (BigDecimal)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
						else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Timestamp"))
							pst.setTimestamp(pos++, (Timestamp)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
						else
							pst.setString(pos++, (String)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getFormValue());
					}
					
					int row = pst.executeUpdate();
					if (row != 1)
					{
						zoneGrpBean.setMsg("不能新增床位");
					}				
				
				}
			
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能新增床位");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能新增床位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}		
		
	
	public ZoneGrpBean performModZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_ZON_ZONE ZON SET ";
					for(int i=2;i<EmsDB.EM_ZON_ZONE.length-1;i++) {
						if(i != EmsDB.EM_ZON_ZONE.length-2)
							sql = sql + EmsDB.EM_ZON_ZONE[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_ZON_ZONE[i][0] + " = ? ";
					}
					sql = sql + "WHERE ZON.ZON_ID = ? AND ZON.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_ZON_ZONE.length-1;i++) {
				
				if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else if(EmsDB.EM_ZON_ZONE[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getValue());
				else
					pst.setString(pos++, (String)zoneGrpBean.getField(EmsDB.EM_ZON_ZONE[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				zoneGrpBean.setMsg("不能更新區域");
			}
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能更新區域");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能更新區域");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}	

	public ZoneGrpBean performModBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		if(zoneGrpBean.getBedBeanList()==null || zoneGrpBean.getBedBeanList().size()==0)
			return zoneGrpBean;

		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_BED_INFO BED SET ";
					for(int i=3;i<EmsDB.EM_BED_INFO.length-1;i++) {
						if(i != EmsDB.EM_BED_INFO.length-2)
							sql = sql + EmsDB.EM_BED_INFO[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_BED_INFO[i][0] + " = ? ";
					}
					sql = sql + "WHERE BED.BED_ID = ? AND BED.ZON_ID = ? AND BED.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			for(int i=0;i<zoneGrpBean.getBedBeanList().size();i++) {
				BedBean bedBean = zoneGrpBean.getBedBeanList().get(i);
				pos = 1;

				for(int j=3;j<EmsDB.EM_BED_INFO.length-1;j++) {
					
					if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
					else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
					else if(EmsDB.EM_BED_INFO[j][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getValue());
					else
						pst.setString(pos++, (String)bedBean.getField(EmsDB.EM_BED_INFO[j][0]).getFormValue());
				}
				
				pst.setInt(pos++, Integer.parseInt(bedBean.getBedId()));
				pst.setInt(pos++, Integer.parseInt(bedBean.getZoneId()));
				pst.setInt(pos++, Integer.parseInt(bedBean.getOrgId()));
				int row = pst.executeUpdate();
				if (row < 0)
				{
					zoneGrpBean.setMsg("不能更新床位");
				}
				
			}
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能更新床位");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能更新床位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}	

	public ZoneGrpBean performDelZone(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		PreparedStatement pst4 = null;
		PreparedStatement pst5 = null;
		int pos = 1;

		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql1 = "DELETE FROM EM_LIV_RECORD WHERE ZON_ID = ? AND ORG_ID = ?";
			String sql2 = "DELETE FROM EM_QUO_RECORD WHERE ZON_ID = ? AND ORG_ID = ?";
			String sql3 = "DELETE FROM EM_RES_RECORD WHERE ZON_ID = ? AND ORG_ID = ?";
			String sql4 = "DELETE FROM EM_BED_INFO WHERE ZON_ID = ? AND ORG_ID = ?";
			String sql5 = "DELETE FROM EM_ZON_ZONE WHERE ZON_ID = ? AND ORG_ID = ?";
			
			pst1 = conn.prepareStatement(sql1);
			pst1.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst1.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));

			pst2 = conn.prepareStatement(sql2);
			pos = 1;
			pst2.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst2.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));

			pst3 = conn.prepareStatement(sql3);
			pos = 1;
			pst3.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst3.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));

			pst4 = conn.prepareStatement(sql4);
			pos = 1;
			pst4.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst4.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));

			pst5 = conn.prepareStatement(sql5);
			pos = 1;
			pst5.setInt(pos++, Integer.parseInt(zoneGrpBean.getZoneId()));
			pst5.setInt(pos++, Integer.parseInt(zoneGrpBean.getOrgId()));

			
			int row = pst1.executeUpdate();
			if (row < 0)
			{
				zoneGrpBean.setMsg("不能刪除區域");
			}else {

				row = pst2.executeUpdate();
				if (row < 0)
				{
					zoneGrpBean.setMsg("不能刪除區域");
				}else {

					row = pst3.executeUpdate();
					if (row < 0)
					{
						zoneGrpBean.setMsg("不能刪除區域");
					}else {
						row = pst4.executeUpdate();
						if (row < 0)
						{
							zoneGrpBean.setMsg("不能刪除區域");
						}else {
							row = pst5.executeUpdate();
							if (row < 0)
							{
								zoneGrpBean.setMsg("不能刪除區域");
							}
						}
					}
				}
			}
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能刪除區域");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能刪除區域");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst1.close();
            	pst2.close();
            	pst3.close();
            	pst4.close();
            	pst5.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}	

	
	public ZoneGrpBean performDelBed(ZoneGrpBean zoneGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		PreparedStatement pst4 = null;
		int pos = 1;

		if(zoneGrpBean.getBedBeanList()==null || zoneGrpBean.getBedBeanList().size()==0)
			return zoneGrpBean;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql1 = "DELETE FROM EM_LIV_RECORD WHERE BED_ID = ? AND ZON_ID = ? AND ORG_ID = ?";
			String sql2 = "DELETE FROM EM_QUO_RECORD WHERE BED_ID = ? AND ZON_ID = ? AND ORG_ID = ?";
			String sql3 = "DELETE FROM EM_RES_RECORD WHERE BED_ID = ? AND ZON_ID = ? AND ORG_ID = ?";
			String sql4 = "DELETE FROM EM_BED_INFO WHERE BED_ID = ? AND ZON_ID = ? AND ORG_ID = ?";
			
			pst1 = conn.prepareStatement(sql1);
			pst2 = conn.prepareStatement(sql2);
			pst3 = conn.prepareStatement(sql3);
			pst4 = conn.prepareStatement(sql4);

			for(int i=0;i<zoneGrpBean.getBedBeanList().size();i++) {
				BedBean bedBean = zoneGrpBean.getBedBeanList().get(i);

				pos = 1;
				pst1.setInt(pos++, Integer.parseInt(bedBean.getBedId()));
				pst1.setInt(pos++, Integer.parseInt(bedBean.getZoneId()));
				pst1.setInt(pos++, Integer.parseInt(bedBean.getOrgId()));
				pos = 1;
				pst2.setInt(pos++, Integer.parseInt(bedBean.getBedId()));
				pst2.setInt(pos++, Integer.parseInt(bedBean.getZoneId()));
				pst2.setInt(pos++, Integer.parseInt(bedBean.getOrgId()));
				pos = 1;
				pst3.setInt(pos++, Integer.parseInt(bedBean.getBedId()));
				pst3.setInt(pos++, Integer.parseInt(bedBean.getZoneId()));
				pst3.setInt(pos++, Integer.parseInt(bedBean.getOrgId()));
				pos = 1;
				pst4.setInt(pos++, Integer.parseInt(bedBean.getBedId()));
				pst4.setInt(pos++, Integer.parseInt(bedBean.getZoneId()));
				pst4.setInt(pos++, Integer.parseInt(bedBean.getOrgId()));
				
				int row = pst1.executeUpdate();
				if (row < 0)
				{
					zoneGrpBean.setMsg("不能刪除床位");
				}else {
	
					row = pst2.executeUpdate();
					if (row < 0)
					{
						zoneGrpBean.setMsg("不能刪除床位");
					}else {
	
						row = pst3.executeUpdate();
						if (row < 0)
						{
							zoneGrpBean.setMsg("不能刪除床位");
						}else {
							row = pst4.executeUpdate();
							if (row < 0)
							{
								zoneGrpBean.setMsg("不能刪除床位");
							}
						}
					}
				}
			}
		}catch(SQLException se){
			zoneGrpBean.setMsg("不能刪除床位");
			se.printStackTrace();
		}catch(Exception e){
			zoneGrpBean.setMsg("不能刪除床位");
			e.printStackTrace();
        } finally {
            try {
           if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst1.close();
            	pst2.close();
            	pst3.close();
            	pst4.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return zoneGrpBean;
	}	

	
	
}
