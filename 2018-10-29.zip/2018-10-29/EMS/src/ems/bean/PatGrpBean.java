package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class PatGrpBean extends PatBean {
	
	String enqPatType = "";
	String enqPatName = "";
	String enqPatId = "";
	
	private ArrayList<ZoneBean> zoneBeanList = new ArrayList<ZoneBean>();
	private ArrayList<PatBean> patBeanList = new ArrayList<PatBean>();
	TransBean transBean = new TransBean();	
	ResGrpBean resGrpBean = new ResGrpBean(); 
	QuoGrpBean quoGrpBean = new QuoGrpBean(); 
		
	public PatGrpBean() {
	}
	

	public String getEnqPatType() {
		return enqPatType;
	}


	public void setEnqPatType(String enqPatType) {
		this.enqPatType = enqPatType;
	}


	public String getEnqPatName() {
		return enqPatName;
	}

	public void setEnqPatName(String enqPatName) {
		this.enqPatName = enqPatName;
	}

	public String getEnqPatId() {
		return enqPatId;
	}

	public void setEnqPatId(String enqPatId) {
		this.enqPatId = enqPatId;
	}

	public ArrayList<PatBean> getPatBeanList(){
		return patBeanList;
	}
	
	public void setPatBeanList(ArrayList<PatBean> patBeanList) {
		this.patBeanList = patBeanList;
	}

	public void addPatBeanList(PatBean patBean) {
		patBeanList.add(patBean);
	}


	
	
	public ArrayList<ZoneBean> getZoneBeanList(){
		return zoneBeanList;
	}
	
	public void setZoneBeanList(ArrayList<ZoneBean> zoneBeanList) {
		this.zoneBeanList = zoneBeanList;
	}

	public void addZoneBeanList(ZoneBean zoneBean) {
		zoneBeanList.add(zoneBean);
	}

	public ZoneBean getZoneBean(String zoneId, String orgId){
		for(int i=0;i<zoneBeanList.size();i++) {
			if(zoneId != null && orgId != null && zoneId.equals(zoneBeanList.get(i).getZoneId()) && orgId.equals(zoneBeanList.get(i).getOrgId())){
				return zoneBeanList.get(i);
			}
		}
		return null;
	}
	
	public PatBean getPatBean(String patId, String orgId){
		for(int i=0;i<patBeanList.size();i++) {
			if(patId != null && orgId != null && patId.equals(patBeanList.get(i).getPatId()) && orgId.equals(patBeanList.get(i).getOrgId())){
				return patBeanList.get(i);
			}
		}
		return null;
	}
	
	public TransBean getTransBean() {
		return transBean;
	}


	public void setTransBean(TransBean transBean) {
		this.transBean = transBean;
	}


	public ResGrpBean getResGrpBean() {
		return resGrpBean;
	}


	public void setResGrpBean(ResGrpBean resGrpBean) {
		this.resGrpBean = resGrpBean;
	}

	
	public QuoGrpBean getQuoGrpBean() {
		return quoGrpBean;
	}


	public void setQuoGrpBean(QuoGrpBean quoGrpBean) {
		this.quoGrpBean = quoGrpBean;
	}


	public void cleanup() {
		setLivBeanList(new ArrayList<LivBean>());
		setPcoBeanList(new ArrayList<PcoBean>());
		setTransBean(new TransBean());
		super.cleanup();
	}
	
	public boolean validate() {
		boolean successFlag = true;
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
