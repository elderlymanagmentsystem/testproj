package ems.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.QuoBean;
import ems.bean.OrgBean;
import ems.bean.QuoGrpBean;
import ems.bean.PcoBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.BedModule;
import ems.module.QuoteModule;
import ems.module.QuoteModule;
import ems.module.UserModule;
import ems.util.EmsCommonUtil;


public class QuoteAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private QuoGrpBean quoGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private static final String IMAGE_STORE_DIR="EMS"+File.separator +"WebContent"+File.separator +"images"+File.separator;
	private static final String RUNTIME_IMAGE_STORE_DIR="images"+File.separator;
	private File fileUpload;
	
	public static final String DEFAULT_FUNC_ID = "020200";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		QuoteModule quoteMod = new QuoteModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			quoteMod.performEnqQuoteList(quoGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(quoteMod.performAddOrUpdatePer(quoGrpBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(quoteMod.performAddOrUpdatePer(quoGrpBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL)){
			quoteMod.performAddOrUpdatePer(quoGrpBean, userBean, false);			
		}

		if(quoGrpBean.getMsg()==null||quoGrpBean.getMsg().length()==0) {
			quoGrpBean.cleanup();
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("quoGrpBean", quoGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(quoGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("quoGrpBean", quoGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(quoGrpBean==null)
			quoGrpBean = new QuoGrpBean();

		quoGrpBean.setMsg("");
		
		for(int i=0;i<quoGrpBean.getFields().size();i++){
			quoGrpBean.getFields().get(i).setFormValue(request.getParameter(quoGrpBean.getFields().get(i).getName()));
		}

		QuoBean quoBean = new QuoBean();
		if(quoGrpBean.getQuoBeanList().size()==0) {
			quoGrpBean.addQuoBeanList(quoBean);
		}else {
			quoBean = quoGrpBean.getQuoBeanList().get(0); 
		}
		
		for(int i=0;i<quoBean.getFields().size();i++){
			quoBean.getFields().get(i).setFormValue(request.getParameter(quoBean.getFields().get(i).getName()));
		}
		
		quoBean.setOrgId(userBean.getAccOrgId());
		
		//change Full Bed Id = Bed Id + Zone Id
		if(request.getParameter("BED_ID") !=null && request.getParameter("BED_ID").indexOf("-")>0) {
			String[] bed_zone = request.getParameter("BED_ID").split("-");
			quoBean.setZoneId(bed_zone[0]);
			quoBean.setBedId(bed_zone[1]);
		}
		
		PcoBean[] pcoBean = new PcoBean[5];
		for(int i=0;i<5;i++){
			if(quoGrpBean.getPcoBeanList().size() > i)
				pcoBean[i] = quoGrpBean.getPcoBeanList().get(i);
			else {
				pcoBean[i] = new PcoBean();
				quoGrpBean.addPcoBeanList(pcoBean[i]);
			}

			pcoBean[i].getField(EmsDB.EM_PCO_PERSONAL_CONTACT[2][0]).setFormValue(request.getParameter("PCO_SEQ"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).setFormValue(request.getParameter("PCO_CHI_NAME"+(i+1)));
			pcoBean[i].getField(EmsDB.EM_PCO_PERSONAL_CONTACT[4][0]).setFormValue(request.getParameter("PCO_REL"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).setFormValue(request.getParameter("PCO_TEL"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[9][0]).setFormValue(request.getParameter("PCO_EMAIL"+(i+1)));
			pcoBean[i].setOrgId(userBean.getAccOrgId());
			pcoBean[i].getPerBean().setOrgId(userBean.getAccOrgId());
		}
		
		
		
		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {
			
			quoGrpBean.setOrgId(userBean.getAccOrgId());
			
			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)) {

				for(int i=0;i<5;i++) {
					if(i==0) {
						if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).getFormValue().length()==0) {
							pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).setMsg("必需輸入");
							quoGrpBean.setMsg("親友輸入錯誤");
							validated = false;
						}
						if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).getFormValue().length()==0) {
							pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).setMsg("必需輸入");
							quoGrpBean.setMsg("親友輸入錯誤");
							validated = false;
						}
					}
						
					if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).getFormValue().length()>0 && pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).getFormValue().length()==0){ 
						pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).setMsg("必需輸入");
						quoGrpBean.setMsg("親友輸入錯誤");
						validated = false;
					}else if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).getFormValue().length()==0 && pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).getFormValue().length()>0){
						pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).setMsg("必需輸入");
						quoGrpBean.setMsg("親友輸入錯誤");
						validated = false;
					}
				}
	
				if(!quoGrpBean.validate())
					validated = false;
				if(!quoBean.validate()) {
					quoGrpBean.setMsg(quoBean.getMsg());
					validated = false;
				}
			}

			if((funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL)) && quoGrpBean.getPerId().length()==0) {
				quoGrpBean.getField("PER_ID").setMsg("必需輸入");
				quoGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(!validated) {
				QuoteModule quoMod = new QuoteModule();
				quoMod.performEnqQuoteList(quoGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("quoGrpBean", quoGrpBean);
				addActionError(quoGrpBean.getMsg());
			}					

		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public QuoGrpBean getQuoGrpBean() {
		return quoGrpBean;
	}

	public void setQuoGrpBean(QuoGrpBean quoGrpBean) {
		this.quoGrpBean = quoGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public boolean uploadImage() {
		boolean uploaded = true;
		try {
			
			UserBean userBean = (UserBean)session.get("userBean");
			String projectPath = EmsCommonUtil.getProjPath();
			String runtimePath = EmsCommonUtil.getRuntimePath();
			if(projectPath!=null)
				(new File(projectPath + File.separator +"file"+ File.separator +"org" + userBean.getAccOrgId() + File.separator + "per"+quoGrpBean.getPerId()+ File.separator +"avatar")).mkdirs();
			if(runtimePath!=null)
				(new File(runtimePath + File.separator +"file"+ File.separator +"org" + userBean.getAccOrgId() + File.separator + "per"+quoGrpBean.getPerId()+ File.separator +"avatar")).mkdirs();

			String fileName = quoGrpBean.getField("PER_IMAGE_LINK").getFormValue();
			
			File runTimeFileToCreate = new File(runtimePath, fileName);
			File fileToCreate = new File(projectPath, fileName);
			
			FileUtils.copyFile(fileUpload, runTimeFileToCreate);			
			FileUtils.copyFile(fileUpload, fileToCreate);						
			
		}catch(Exception e) {
			quoGrpBean.setMsg("上載圖檔失敗");
			uploaded = false;
		}
		
		return uploaded;
	}
	
	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}


}
