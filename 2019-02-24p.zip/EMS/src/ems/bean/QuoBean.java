package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class QuoBean extends BasicBean {
	
	PerBean perBean = new PerBean();
	BedBean bedBean = new BedBean();
	
	public QuoBean() {
		for(int i=0; i<EmsDB.EM_QUO_RECORD.length;i++) {
			if(getField(EmsDB.EM_QUO_RECORD[i][0])==null)
				fields.add(new Field(EmsDB.EM_QUO_RECORD[i]));
		}
	}
	
	public String getQuoId() {
		return getField("QUO_ID").getFormValue();
	}
	public void setQuoId(String quoId) {
		getField("QUO_ID").setFormValue(quoId);
	}

	public String getBedId() {
		return getField("BED_ID").getFormValue();
	}
	public void setBedId(String bedId) {
		getField("BED_ID").setFormValue(bedId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getZoneId() {
		return getField("ZON_ID").getFormValue();
	}
	public void setZoneId(String zoneId) {
		getField("ZON_ID").setFormValue(zoneId);
	}
	
	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}
	
	public PerBean getPerBean() {
		return perBean;
	}
	public void setPerBean(PerBean perBean) {
		this.perBean = perBean;
	}
	
	public BedBean getBedBean() {
		return bedBean;
	}
	public void setBedBean(BedBean bedBean) {
		this.bedBean = bedBean;
	}
	
	
}
