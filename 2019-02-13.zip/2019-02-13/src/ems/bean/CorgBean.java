package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class CorgBean extends CitemBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
	public CorgBean() {
		for(int i=0; i<EmsDB.EM_CHO_CHARGE_ORG.length;i++) {
			if(getField(EmsDB.EM_CHO_CHARGE_ORG[i][0])==null)
				fields.add(new Field(EmsDB.EM_CHO_CHARGE_ORG[i]));
		}
	}
	
	ArrayList perIdList = new ArrayList<String>();
	
	public ArrayList<String> getPerIdList() {
		return perIdList;
	}
	public void setPerIdList(ArrayList perIdList) {
		this.perIdList = perIdList;
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	public String getCorgId() {
		return getField("CHO_ID").getFormValue();
	}
	public void setCorgId(String cperId) {
		getField("CHO_ID").setFormValue(cperId);
	}

	public String getCitemId() {
		return getField("CHI_ID").getFormValue();
	}
	public void setCitemId(String citemId) {
		getField("CHI_ID").setFormValue(citemId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

}
