package ems.util;

import javax.naming.*;
import javax.sql.*;

public class DBUtil {
	private static DataSource dataSource;
	private static final String JNDI_LOOKUP_SERVICE = "java:/comp/env/jdbc/EMS_DB";
	static {
		try {
			Context context = new InitialContext();
			Object lookup = context.lookup(JNDI_LOOKUP_SERVICE);
			if (lookup != null) {
				dataSource = (DataSource) lookup;
			} else {
				new RuntimeException("Datasource not found!!!");
			}
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	public static DataSource getDataSource() {
		return dataSource;
	}
}
