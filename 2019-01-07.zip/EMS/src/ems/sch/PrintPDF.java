package ems.sch;

import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.io.File;
import java.net.URL;

import com.qoppa.pdfWriter.PDFDocument;
import com.qoppa.pdfWriter.PDFGraphics;
import com.qoppa.pdfWriter.PDFPage;

public class PrintPDF {
	public void print() {
		try
        {
			
			URL url = new URL ("https://www.qoppa.com/files/pdfwriter/demo/htmlsamplepage.html");
			PageFormat pf = new PageFormat();
			PDFDocument pdfDoc = PDFDocument.loadHTML (url, pf, true);
			pdfDoc.saveDocument ("c:\\output.pdf");
			
            // Create a document and a page in default Locale format
            //PDFDocument pdfDoc = new PDFDocument();
            /*
            PDFPage newPage1 = pdfDoc.createPage(new PageFormat());
            PDFPage newPage2 = pdfDoc.createPage(new PageFormat());
            
            // Draw to the page
            Graphics2D g2d = newPage1.createGraphics();
            g2d.setFont (PDFGraphics.HELVETICA.deriveFont(24f));
            g2d.drawString("sadasdasdasdasd昨杳杯地少杯竹1", 100, 100);
            
            // Draw to the page
            Graphics2D g2d2 = newPage2.createGraphics();
            g2d2.setFont (PDFGraphics.HELVETICA.deriveFont(24f));
            g2d2.drawString("sadasdasdasdasd昨杳杯地少杯竹2", 100, 100);
            
            
            // Add the page to the document and save it
            //pdfDoc.addPage(newPage1);
            //pdfDoc.addPage(newPage2);
             * 
             */
            
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
    }



	public static void main(String [] args) {
		PrintPDF printPDF = new PrintPDF();
		printPDF.print();
	}
	
}
