package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class AccGrpBean extends CitemBean {
	
	String enqCitemCat = "";
	String enqCitemType = "";
	String enqCitemName = "";
	
	private ArrayList<CitemBean> citemBeanList = new ArrayList<CitemBean>();
	private ArrayList<CitemBean> citemCatBeanList = new ArrayList<CitemBean>();
	private ArrayList<PatBean> patBeanList = new ArrayList<PatBean>();
		
	public AccGrpBean() {
	}
	
	public ArrayList<PatBean> getPatBeanList(){
		return patBeanList;
	}
	
	public void setPatBeanList(ArrayList<PatBean> patBeanList) {
		this.patBeanList = patBeanList;
	}

	public void addPatBeanList(PatBean patBean) {
		patBeanList.add(patBean);
	}

	public PatBean getPatBean(String patId, String orgId){
		for(int i=0;i<patBeanList.size();i++) {
			if(patId != null && orgId != null && patId.equals(patBeanList.get(i).getPatId()) && orgId.equals(patBeanList.get(i).getOrgId())){
				return patBeanList.get(i);
			}
		}
		return null;
	}
	
	
	
	public String getEnqCitemCat() {
		return enqCitemCat;
	}



	public void setEnqCitemCat(String enqCitemCat) {
		this.enqCitemCat = enqCitemCat;
	}



	public String getEnqCitemType() {
		return enqCitemType;
	}



	public void setEnqCitemType(String enqCitemType) {
		this.enqCitemType = enqCitemType;
	}



	public String getEnqCitemName() {
		return enqCitemName;
	}



	public void setEnqCitemName(String enqCitemName) {
		this.enqCitemName = enqCitemName;
	}



	public ArrayList<CitemBean> getCitemBeanList(){
		return citemBeanList;
	}
	
	public void setCitemBeanList(ArrayList<CitemBean> citemBeanList) {
		this.citemBeanList = citemBeanList;
	}

	public void addCitemBeanList(CitemBean citemBean) {
		citemBeanList.add(citemBean);
	}

	public CitemBean getCitemBean(String citemId, String orgId){
		for(int i=0;i<citemBeanList.size();i++) {
			if(citemId != null && orgId != null && citemId.equals(citemBeanList.get(i).getCitemId()) && orgId.equals(citemBeanList.get(i).getOrgId())){
				return citemBeanList.get(i);
			}
		}
		return null;
	}
	
	public ArrayList<CitemBean> getCitemCatBeanList(){
		return citemCatBeanList;
	}
	
	public void setCitemCatBeanList(ArrayList<CitemBean> citemCatBeanList) {
		this.citemCatBeanList = citemCatBeanList;
	}

	public void addCitemCatBeanList(CitemBean citemCatBean) {
		citemCatBeanList.add(citemCatBean);
	}

	public CitemBean getCitemCatBean(String citemCatId, String orgId){
		for(int i=0;i<citemCatBeanList.size();i++) {
			if(citemCatId != null && orgId != null && citemCatId.equals(citemCatBeanList.get(i).getCitemCatId()) && orgId.equals(citemCatBeanList.get(i).getOrgId())){
				return citemCatBeanList.get(i);
			}
		}
		return null;
	}
	
	public void cleanup() {
		super.cleanup();
	}
	
	public boolean validate() {
		boolean successFlag = true;
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
