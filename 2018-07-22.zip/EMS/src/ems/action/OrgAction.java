package ems.action;

import java.io.File;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.db.EmsDB;
import ems.module.OrgModule;


public class OrgAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private OrgBean orgBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private static final String IMAGE_STORE_DIR="EMS"+File.separator +"WebContent"+File.separator +"images"+File.separator;
	private static final String RUNTIME_IMAGE_STORE_DIR="images"+File.separator;
	private File fileUpload;
	
	public static final String DEFAULT_FUNC_ID = "010400";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		OrgModule orgMod = new OrgModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			orgMod.performEnqOrg(orgBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(orgMod.performAddOrg(orgBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(orgMod.performModOrg(orgBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();			
		}

		if(orgBean.getMsg()==null||orgBean.getMsg().length()==0) {
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);

			return SUCCESS;
			
			
		}else {
			addActionError(orgBean.getMsg());

			request.setAttribute("funcId", funcId);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(orgBean==null)
			orgBean = new OrgBean();
		
		for(int i=0;i<EmsDB.EM_ORG_ORGANIZATION.length;i++) {
			orgBean.getField(EmsDB.EM_ORG_ORGANIZATION[i][0]).setFormValue(request.getParameter(EmsDB.EM_ORG_ORGANIZATION[i][0]));
		}
			
		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD))) {
			if(!orgBean.validate()) {
				request.setAttribute("funcId", funcId);
				addActionError(orgBean.getMsg());
			}else if(funcId.substring(4).equals(EmsDB.FUNC_MOD) && (orgBean.getOrgId()==null ||orgBean.getOrgId().length()==0)) {
				orgBean.setMsg("輸入錯誤");
				orgBean.getField("ORG_ID").setMsg("必需輸入");
				request.setAttribute("funcId", funcId);
				addActionError(orgBean.getMsg());
			}
		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
			
	}

	public OrgBean getOrgBean() {
		return orgBean;
	}

	public void setOrgBean(OrgBean orgBean) {
		this.orgBean = orgBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public boolean uploadImage() {
		boolean uploaded = true;
		try {
			
			String fileName = orgBean.getField("ORG_IMAGE_LINK").getFormValue();
			String path = request.getServletContext().getRealPath("/");
			File runTimeFileToCreate = new File(path+RUNTIME_IMAGE_STORE_DIR, fileName);
			File fileToCreate = new File(path.substring(0, path.indexOf("workspace")+10)+IMAGE_STORE_DIR, fileName);
			
			FileUtils.copyFile(fileUpload, runTimeFileToCreate);			
			FileUtils.copyFile(fileUpload, fileToCreate);			
			
		}catch(Exception e) {
			orgBean.setMsg("上載圖檔失敗");
			uploaded = false;
		}
		
		return uploaded;
	}
	
	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}


}
