package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class LivBean extends BasicBean {
	
	PatBean patBean = new PatBean();
	
	public LivBean() {
		for(int i=0; i<EmsDB.EM_LIV_RECORD.length;i++) {
			fields.add(new Field(EmsDB.EM_LIV_RECORD[i]));
		}
	}
	
	public String getLivId() {
		return getField("LIV_ID").getFormValue();
	}
	public void setLivId(String livId) {
		getField("LIV_ID").setFormValue(livId);
	}

	public String getBedId() {
		return getField("BED_ID").getFormValue();
	}
	public void setBedId(String bedId) {
		getField("BED_ID").setFormValue(bedId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getZoneId() {
		return getField("ZON_ID").getFormValue();
	}
	public void setZoneId(String zoneId) {
		getField("ZON_ID").setFormValue(zoneId);
	}
	
	public String getPatId() {
		return getField("PAT_ID").getFormValue();
	}
	public void setPatId(String patId) {
		getField("PAT_ID").setFormValue(patId);
	}
	
	public PatBean getPatBean() {
		return patBean;
	}
	public void setPatBean(PatBean patBean) {
		this.patBean = patBean;
	}
	
}
