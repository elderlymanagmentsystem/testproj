package ems.module;

import ems.bean.UserBean;
import ems.db.UserDB;

public class LoginModule {

	public boolean performLogin(UserBean userBean) {
		UserDB userDB = new UserDB();
		userBean = userDB.getUserBean(userBean);
		if (userBean!=null && userBean.getRolBean()!=null &&userBean.getRolBean().getFunIdList()!=null && userBean.getRolBean().getFunIdList().size()>0) {
			return true;
		}else {
			return false;
		}
	}
	
}
