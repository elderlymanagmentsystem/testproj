package ems.action;

import java.io.File;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;
import ems.module.UserModule;
import ems.util.EmsCommonUtil;

public class LoginAction extends ActionSupport implements SessionAware, ServletRequestAware {
	private UserBean userBean;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	
	public String execute()
	{	
		UserModule userMod = new UserModule();
		if ("logout".equalsIgnoreCase((request.getParameter("actionType")))){
			//logout, clear all session
			session.clear();
			return INPUT;
		} else {
			//login, check login name password valid and assign session
			if (userBean != null && userMod.performLogin(userBean)) {
				session.put("userBean", userBean);
				addActionMessage("成功登入");
				
				//set system path for file upload purpose
				String path = request.getServletContext().getRealPath("/");
				EmsCommonUtil.setRuntimePath(path);
				EmsCommonUtil.setProjPath(path.substring(0, path.indexOf(".metadata")-1) + File.separator + "EMS" + File.separator + "WebContent" + File.separator);
				return SUCCESS;
			} else {
				addActionError("用戶名稱或密碼錯誤");
				return INPUT;
			}
		}
	}
	 
	public void validate() {

/*		
		if(userBean!= null && !userBean.validate())
			addActionError(userBean.getMsg());
*/		
			boolean successFlag = true;
			 
			if(userBean==null)
				userBean = new UserBean();
			
			if((userBean.getField("ORG_ID").getFormValue()==null || userBean.getField("ORG_ID").getFormValue().length()==0)
					&& (userBean.getField("USE_ID").getFormValue()==null || userBean.getField("USE_ID").getFormValue().length()==0)
					&& (userBean.getField("USE_PWD").getFormValue()==null || userBean.getField("USE_PWD").getFormValue().length()==0)) {
				
			}else {
				successFlag = userBean.getField("ORG_ID").validate() ? successFlag : false;
				successFlag = userBean.getField("USE_ID").validate() ? successFlag : false;
				successFlag = userBean.getField("USE_PWD").validate() ? successFlag : false;
				
			}
			
			
			if(successFlag)
				userBean.setMsg("");
			else {
				userBean.setMsg("輸入錯誤");
				addActionError(userBean.getMsg());
			}
		
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}
	
}
