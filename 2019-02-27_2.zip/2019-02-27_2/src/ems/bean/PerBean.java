package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class PerBean extends BasicBean {
	
	private ArrayList<PcoBean> pcoBeanList = new ArrayList<PcoBean>();
	private ArrayList<QuoBean> quoBeanList = new ArrayList<QuoBean>();
	private ArrayList<ResBean> resBeanList = new ArrayList<ResBean>();
	private ArrayList<TransBean> transBeanList = new ArrayList<TransBean>();
	private ArrayList<CperBean> cperBeanList = new ArrayList<CperBean>();
	private ArrayList<CorgBean> corgBeanList = new ArrayList<CorgBean>();
	private ArrayList<StmtBean> stmtBeanList = new ArrayList<StmtBean>();
	private ArrayList<PerFileBean> perFileBeanList = new ArrayList<PerFileBean>();
	
	private AccBalBean accBalBean = new AccBalBean();
	
	public PerBean() {
		for(int i=0; i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
			if(getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0])==null)
				fields.add(new Field(EmsDB.EM_PER_PERSONAL_PARTICULAR[i]));
		}
	}
	
	public AccBalBean getAccBalBean() {
		return accBalBean;
	}

	public void setAccBalBean(AccBalBean accBalBean) {
		this.accBalBean = accBalBean;
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	
	public PcoBean getPcoBean(String pcoPerId, String orgId){
		for(int i=0;i<pcoBeanList.size();i++) {
			if(pcoPerId != null && orgId != null && pcoPerId.equals(pcoBeanList.get(i).getPcoPerId()) && orgId.equals(pcoBeanList.get(i).getOrgId())){
				return pcoBeanList.get(i);
			}
		}
		return null;
	}	
	
	
	
	public ArrayList<PcoBean> getPcoBeanList(){
		return pcoBeanList;
	}
	
	public void setPcoBeanList(ArrayList<PcoBean> pcoBeanList) {
		this.pcoBeanList = pcoBeanList;
	}

	public void addPcoBeanList(PcoBean pcoBean) {
		pcoBeanList.add(pcoBean);
	}

	public QuoBean getQuoBean(String perId, String orgId){
		for(int i=0;i<quoBeanList.size();i++) {
			if(perId != null && orgId != null && perId.equals(quoBeanList.get(i).getPerId()) && orgId.equals(quoBeanList.get(i).getOrgId())){
				return quoBeanList.get(i);
			}
		}
		return null;
	}	
	
	
	
	public ArrayList<QuoBean> getQuoBeanList(){
		return quoBeanList;
	}
	
	public void setQuoBeanList(ArrayList<QuoBean> quoBeanList) {
		this.quoBeanList = quoBeanList;
	}

	public void addQuoBeanList(QuoBean quoBean) {
		quoBeanList.add(quoBean);
	}

	public ResBean getResBean(String perId, String orgId){
		for(int i=0;i<resBeanList.size();i++) {
			if(perId != null && orgId != null && perId.equals(resBeanList.get(i).getPerId()) && orgId.equals(resBeanList.get(i).getOrgId())){
				return resBeanList.get(i);
			}
		}
		return null;
	}	
	
	
	
	public ArrayList<ResBean> getResBeanList(){
		return resBeanList;
	}
	
	public void setResBeanList(ArrayList<ResBean> resBeanList) {
		this.resBeanList = resBeanList;
	}

	public void addResBeanList(ResBean resBean) {
		resBeanList.add(resBean);
	}


	public TransBean getTransBean(String perId, String orgId){
		for(int i=0;i<transBeanList.size();i++) {
			if(perId != null && orgId != null && perId.equals(transBeanList.get(i).getPerId()) && orgId.equals(transBeanList.get(i).getOrgId())){
				return transBeanList.get(i);
			}
		}
		return null;
	}	
	
	public ArrayList<TransBean> getTransBeanList(){
		return transBeanList;
	}
	
	public void setTransBeanList(ArrayList<TransBean> transBeanList) {
		this.transBeanList = transBeanList;
	}

	public void addTransBeanList(TransBean transBean) {
		transBeanList.add(transBean);
	}


	public ArrayList<CperBean> getCperBeanList(){
		return cperBeanList;
	}
	
	public void setCperBeanList(ArrayList<CperBean> cperBeanList) {
		this.cperBeanList = cperBeanList;
	}

	public void addCperBeanList(CperBean cperBean) {
		cperBeanList.add(cperBean);
	}

	public CperBean getCperBean(String cperId, String orgId){
		for(int i=0;i<cperBeanList.size();i++) {
			if(cperId != null && orgId != null && cperId.equals(cperBeanList.get(i).getCperId()) && orgId.equals(cperBeanList.get(i).getOrgId())){
				return cperBeanList.get(i);
			}
		}
		return null;
	}	


	public ArrayList<CorgBean> getCorgBeanList(){
		return corgBeanList;
	}
	
	public void setCorgBeanList(ArrayList<CorgBean> corgBeanList) {
		this.corgBeanList = corgBeanList;
	}

	public void addCorgBeanList(CorgBean corgBean) {
		corgBeanList.add(corgBean);
	}

	public CorgBean getCorgBean(String corgId, String orgId){
		for(int i=0;i<corgBeanList.size();i++) {
			if(corgId != null && orgId != null && corgId.equals(corgBeanList.get(i).getCorgId()) && orgId.equals(corgBeanList.get(i).getOrgId())){
				return corgBeanList.get(i);
			}
		}
		return null;
	}	

	public ArrayList<StmtBean> getStmtBeanList(){
		return stmtBeanList;
	}
	
	public void setStmtBeanList(ArrayList<StmtBean> stmtBeanList) {
		this.stmtBeanList = stmtBeanList;
	}

	public void addStmtBeanList(StmtBean stmtBean) {
		stmtBeanList.add(stmtBean);
	}

	public StmtBean getStmtBean(String stmtId, String orgId){
		for(int i=0;i<stmtBeanList.size();i++) {
			if(stmtId != null && orgId != null && stmtId.equals(stmtBeanList.get(i).getStmtId()) && orgId.equals(stmtBeanList.get(i).getOrgId())){
				return stmtBeanList.get(i);
			}
		}
		return null;
	}	

	public ArrayList<PerFileBean> getPerFileBeanList(){
		return perFileBeanList;
	}
	
	public void setPerFileBeanList(ArrayList<PerFileBean> perFileBeanList) {
		this.perFileBeanList = perFileBeanList;
	}

	public void addPerFileBeanList(PerFileBean perFileBean) {
		perFileBeanList.add(perFileBean);
	}
	


}
