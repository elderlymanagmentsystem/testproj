package ems.module;

import java.util.ArrayList;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.UserDB;

public class UserModule {

	public boolean performLogin(UserBean userBean) {
		UserDB userDB = new UserDB();
		userBean = userDB.getUserBean(userBean);
		if (userBean!=null && userBean.getFunIdList()!=null && userBean.getFunIdList().size()>0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performEnqUserGrp(UserGrpBean userGrpBean, ArrayList<String> accOrgList) {
		userGrpBean.setMsg("");
		UserDB userDB = new UserDB();
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, accOrgList);
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
}
