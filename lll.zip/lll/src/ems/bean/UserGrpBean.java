package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class UserGrpBean extends BasicBean {
	
	String enqOrgId = "";
	String enqRolId = "";
	String enqUserId = "";
	private ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();

//	private ArrayList<OrgBean> accOrgBeanList = new ArrayList<OrgBean>();
	private ArrayList<RolBean> rolBeanList = new ArrayList<RolBean>();
		
	public UserGrpBean() {
	}
	
	public String getEnqOrgId() {
		return enqOrgId;
	}
	public void setEnqOrgId(String enqOrgId) {
		this.enqOrgId = enqOrgId;
	}

	public String getEnqRolId() {
		return enqRolId;
	}
	public void setEnqRolId(String enqRolId) {
		this.enqRolId = enqRolId;
	}

	public String getEnqUserId() {
		return enqUserId;
	}
	public void setEnqUserId(String enqUserId) {
		this.enqUserId = enqUserId;
	}

/*
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
*/	
	public ArrayList<UserBean> getUserBeanList(){
		return userBeanList;
	}
	
	public void setUserBeanList(ArrayList<UserBean> userBeanList) {
		this.userBeanList = userBeanList;
	}

	public void addUserBeanList(UserBean userBean) {
		userBeanList.add(userBean);
	}
/*
	public ArrayList<OrgBean> getAccOrgBeanList(){
		return accOrgBeanList;
	}
	
	public void setAccOrgBeanList(ArrayList<OrgBean> accOrgBeanList) {
		this.accOrgBeanList = accOrgBeanList;
	}

	public void addAccOrgBeanList(OrgBean accOrgBean) {
		accOrgBeanList.add(accOrgBean);
	}
*/
	public ArrayList<RolBean> getRolBeanList(){
		return rolBeanList;
	}
	
	public void setRolBeanList(ArrayList<RolBean> rolBeanList) {
		this.rolBeanList = rolBeanList;
	}

	public void addRolBeanList(RolBean rolBean) {
		rolBeanList.add(rolBean);
	}


}
