var formNum = 0; 
//0=enq
//1=add
//2=mod

function w3_open() {
    document.getElementById("mySidebar1").style.display = "block";
    document.getElementById("mySidebar2").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar1").style.display = "none";
    document.getElementById("mySidebar2").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

function setTitle(myTitle){
	document.getElementById('myHeaderSpan').innerHTML = myTitle;
}

function ddlFunc(dropdownlist) {
    var x = document.getElementById(dropdownlist);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}

// confirm message - start//
function showConfirmMessage(msg,type){
	var theMsg = msg;
	if (arguments.length == 0){
		//no argument, use default message 是否確定？
		theMsg = unescape("%u662F%u5426%u78BA%u5B9A%uFF1F");
		document.getElementById("confirmMessageLogo1").style.display = "inline";
		document.getElementById("confirmMessageLogo2").style.display = "none";
	} else if (arguments.length == 2) {
		//2 argument, use define message and different logo
		document.getElementById("confirmMessageLogo1").style.display = "none";
		document.getElementById("confirmMessageLogo2").style.display = "inline";
	} 
	document.getElementById('confirmMessageContent').innerHTML = theMsg;
	document.getElementById('confirmMessage').style.display = 'block';
}

function confirmMessage(flag){
	if ("Y" == flag){
		submitAction();
		document.getElementById('confirmMessage').style.display = 'none';
	}else{
		document.getElementById('confirmMessage').style.display = 'none';
	}
}
function submitAction(){
	document.forms[formNum].submit();
}

//confirm message - end//

function validateFileType(element,msgElement){
    var fileName = element.value;
    if (fileName != null && fileName!=""){
	    var idxDot = fileName.lastIndexOf(".") + 1;
	    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
	    if (extFile!="jpg"){
	    	document.getElementById(msgElement).innerHTML = "只限 jpg檔";
	    	element.value = "";
	    } else {
	    	document.getElementById(msgElement).innerHTML = "";
	    }
    }
}

function clearErrMsg(){
	var element = document.getElementsByClassName("w3-text-red mc-italic");
	for(var i = 0; i < element.length; i++)
	{
		element[i].innerHTML = "";
	}
}

function showScreen(screenId){
	var element = document.querySelectorAll("[id$='Screen']");
	for (var i=0;i<element.length;i++){
		element[i].style.display = "none";
	}
	document.getElementById(screenId).style.display = "block";

	if(screenId.indexOf("enq")!=-1)
		formNum = 0;
	else if(screenId.indexOf("add")!=-1)
		formNum = 1;
	else if(screenId.indexOf("mod")!=-1)
		formNum = 2;
}

function expBtn(elementId) {
    var element = document.querySelectorAll("[id*='ExpBtn']");
	for (var i=0;i<element.length;i++){
		if (elementId == element[i].id)
			if (element[i].className.indexOf("w3-show") == -1)
				element[i].className += " w3-show";
			else
				element[i].className = element[i].className.replace(" w3-show", "");
		else
			element[i].className = element[i].className.replace(" w3-show", "");
	}
}

function switchTabPage(tabIdPrefix, num) {
	var element = document.querySelectorAll("[id^='"+tabIdPrefix+"TabPage']");
	for (var i=0;i<element.length;i++){
		element[i].style.display = "none";
	}
	var element = document.querySelectorAll("[id^='"+tabIdPrefix+"TabBtn']");
	for (var i=0;i<element.length;i++){
		element[i].className = element[i].className.replace(" w3-teal", " w3-grey");
	}
	document.getElementById(tabIdPrefix+"TabPage"+num).style.display = "block";
	document.getElementById(tabIdPrefix+"TabBtn"+num).className = document.getElementById(tabIdPrefix+"TabBtn"+num).className.replace(" w3-grey", " w3-teal");
}
