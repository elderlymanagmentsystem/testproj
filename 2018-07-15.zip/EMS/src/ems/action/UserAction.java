package ems.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.UserModule;


public class UserAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private UserGrpBean userGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "010300";
	
	
	public String execute()
	{
		UserBean userBean = (UserBean)session.get("userBean");
		
		UserModule userMod = new UserModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			userMod.performEnqUserGrp(userGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			userMod.performAddUser(userGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			userMod.performModUser(userGrpBean, userBean);
		}

		if(userGrpBean.getMsg()==null||userGrpBean.getMsg().length()==0) {
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);

			return SUCCESS;
			
			
		}else {
			addActionError(userGrpBean.getMsg());

			request.setAttribute("funcId", funcId);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(userGrpBean==null)
			userGrpBean = new UserGrpBean();

		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD))) {

			for(int i=0;i<userGrpBean.getFields().size();i++){
				userGrpBean.getFields().get(i).setFormValue(request.getParameter(userGrpBean.getFields().get(i).getName()));
			}
			
			userGrpBean.setAccOrgBeanList(new ArrayList<OrgBean>());
			if(request.getParameter("ACC_ORG_ID")!=null) {
				String[] tempAccOrgId = request.getParameterValues("ACC_ORG_ID");
				for(int i=0;i<tempAccOrgId.length;i++) {
					userGrpBean.addAccOrgBeanList(tempAccOrgId[i]);
				}
			}
			
			if(!userGrpBean.validate()) {
				validated = false;
			}

			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) && userGrpBean.getField("USE_PWD").getFormValue().length()==0) {
				userGrpBean.getField("USE_PWD").setMsg("必需輸入");
				userGrpBean.setMsg("輸入錯誤");
			}

			if(!validated) {
				UserModule userMod = new UserModule();
				userMod.performEnqUserGrp(userGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("userGrpBean", userGrpBean);
				addActionError(userGrpBean.getMsg());
			}

		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public UserGrpBean getUserGrpBean() {
		return userGrpBean;
	}

	public void setUserGrpBean(UserGrpBean userGrpBean) {
		this.userGrpBean = userGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

}
