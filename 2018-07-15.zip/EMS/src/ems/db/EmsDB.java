package ems.db;

public class EmsDB {
/*
	public static final String[] EM_ORG_ORGANIZATION = {"ORG_ID", 
														"ORG_ENG_NAME", 
														"ORG_CHI_NAME",
														"ORG_ENG_ADDR",
														"ORG_CHI_ADDR",
														"ORG_TEL",
														"ORG_FAX",
														"ORG_WEBSITE",
														"ORG_EMAIL",
														"ORG_LICENSE_NO",
														"ORG_LICENSE_EXP_DATE",
														"ORG_BR_NO",
														"ORG_NATURE",
														"ORG_TOTAL_BED",
														"ORG_GOV_BED",
														"ORG_SERVICE_AIM",
														"ORG_IMAGE_LINK",
														"ORG_START_DATE",
														"ORG_END_DATE", 
														"ORG_STATUS",
														"ORG_MOD_BY",
														"ORG_MOD_DATE"};
*/
	public static final String[][] EM_ORG_ORGANIZATION = {
														{"ORG_ID", "院舍編號", "Integer", "4", "", "N"},
														{"ORG_ENG_NAME", "院舍名稱(英文)", "String", "100", "", "N"},
														{"ORG_CHI_NAME", "院舍名稱(中文)", "String", "100", "", "Y"},
														{"ORG_ENG_ADDR", "地址(英文)", "String", "200", "", "N"},
														{"ORG_CHI_ADDR", "地址(中文)", "String", "200", "", "N"},
														{"ORG_TEL", "電話", "String", "20", "", "N"},
														{"ORG_FAX", "傳真", "String", "20", "", "N"},
														{"ORG_WEBSITE", "網址", "String", "50", "", "N"},
														{"ORG_EMAIL", "電郵", "String", "50", "", "N"},
														{"ORG_LICENSE_NO", "牌照號碼", "String", "30", "", "N"},
														{"ORG_LICENSE_EXP_DATE", "牌照到期日", "Date", "10", "", "N"},
														{"ORG_BR_NO", "商業登記號碼", "String", "30", "", "N"},
														{"ORG_NATURE", "院舍性質", "String", "100", "", "N"},
														{"ORG_BED_LIMIT", "床位數限制", "Integer", "4", "", "Y"},
														{"ORG_TOTAL_BED", "總床位數", "Integer", "4", "", "N"},
														{"ORG_GOV_BED", "政府買位床位數", "Integer", "4", "", "N"},
														{"ORG_SERVICE_AIM", "服務宗旨", "String", "1000", "", "N"},
														{"ORG_IMAGE_LINK", "圖檔", "String", "100", "", "N"},
														{"ORG_START_DATE", "開始日期", "Date", "10", "", "Y"},
														{"ORG_END_DATE", "結束日期", "Date", "10", "", "N"},
														{"ORG_STATUS", "狀態", "String", "1", "", "N"},
														{"ORG_MOD_BY", "修改人員", "String", "50", "", "N"},
														{"ORG_MOD_DATE", "修改日期", "String", "10", "", "N"}
														};	
	
	public static final String[][] EM_PER_PERSONAL_PARTICULAR   = {
																{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
																{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
																{"PER_NAME", "姓名", "String", "50", "", "Y"},
																{"PER_TEL", "電話", "String", "20", "", "N"},
																{"PER_EMAIL", "電郵", "String", "50", "", "N"},
																{"PER_DESC", "資訊", "String", "200", "", "N"},
																{"PER_NATURE", "性質", "String", "1", "", "Y"},
																{"PER_STATUS", "狀態", "String", "1", "", "Y"},
																{"PER_MOD_BY", "修改人員", "String", "50", "", "N"},
																{"PER_MOD_DATE", "修改日期", "String", "10", "", "N"}
																};


	public static final String[][] EM_USE_USER_ACCT = {
														{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
														{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
														{"USE_ID", "用戶名稱", "String", "50", "", "Y"},
														{"USE_PWD", "密碼", "String", "50", "", "N"},
														{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
														{"USE_STATUS", "狀態", "String", "1", "", "N"},
														{"USE_MOD_BY", "修改人員", "String", "50", "", "N"},
														{"USE_MOD_DATE", "修改日期", "String", "10", "", "N"}
													 };
		
	public static final String[][] EM_FUN_FUNCTION = {
												{"FUN_ID", "功能編號", "String", "6", "", "Y"},
												{"FUN_PARENT_ID", "繼承功能編號", "Integer", "6", "", "Y"},
												{"FUN_NAME", "功能名稱", "Sring", "50", "", "Y"},
												{"FUN_NAVI", "瀏覽列", "String", "50", "", "Y"},
												{"FUN_URL", "連結", "String", "50", "", "Y"},
												{"FUN_STATUS", "狀態", "String", "1", "", "N"},
												{"FUN_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"FUN_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_ROL_ROLE = {
												{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
												{"ROL_NAME", "權限名稱", "String", "100", "", "Y"},
												{"ROL_STATUS", "狀態", "String", "1", "", "N"},
												{"ROL_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"ROL_MOD_DATE", "修改日期", "String", "10", "", "N"}
											   };

	public static final String[][] EM_RFR_ROL_FUN_REL = {
												{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
												{"FUN_ID", "功能編號", "String", "6", "", "Y"},
												{"RFR_STATUS", "狀態", "String", "1", "", "N"},
												{"RFR_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"RFR_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_URR_USER_ROLE_REL = {
												{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
												{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
												{"ACC_ORG_ID", "管理院舍", "Integer", "4", "", "Y"},
												{"URR_STATUS", "狀態", "String", "1", "", "N"},
												{"URR_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"URR_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};
	
	public static final String FUNC_ENQ = "00";
	public static final String FUNC_ADD = "01";
	public static final String FUNC_MOD = "02";
	
	
	public static final String FUNC_GROUP_SET = "04";
}
