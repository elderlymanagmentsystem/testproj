package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;
import ems.db.OrgDB;
import ems.util.EmsCommonUtil;

public class UserBean extends PerBean {
	

	OrgBean orgBean = new OrgBean();
	OrgBean accOrgBean = new OrgBean();
	RolBean rolBean = new RolBean();
	ArrayList<OrgBean> accOrgBeanList = new ArrayList<OrgBean>();
	
	public UserBean() {
		for(int i=2; i<EmsDB.EM_USE_USER_ACCT.length;i++) {
			fields.add(new Field(EmsDB.EM_USE_USER_ACCT[i]));
		}
	}
	
	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
		orgBean.setOrgId(orgId);
		
		OrgDB orgDB = new OrgDB();
		orgDB.getOrgBean(orgBean);
	}
	public OrgBean getOrgBean() {
		return orgBean;
	}
	
	public void setOrgBean(OrgBean orgBean) {
		this.orgBean = orgBean;
	}

	public String getAccOrgId() {
		return accOrgBean.getOrgId();
	}
	public void setAccOrgId(String accOrgId) {
		accOrgBean.setOrgId(accOrgId);
		
		OrgDB orgDB = new OrgDB();
		orgDB.getOrgBean(accOrgBean);
	}
	public OrgBean getAccOrgBean() {
		return accOrgBean;
	}
	public void setAccOrgBean(OrgBean accOrgBean) {
		this.accOrgBean = accOrgBean;
	}


	public String getUserId() {
		return getField("USE_ID").getFormValue();
	}
	public void setUserId(String userId) {
		getField("USE_ID").setFormValue(userId);
	}
	public String getPwd() {
		return getField("USE_PWD").getFormValue();
	}
	public void setPwd(String pwd) {
		getField("USE_PWD").setFormValue(pwd);
	}
	
	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	public String getRolId() {
		return getField("ROL_ID").getFormValue();
	}
	
	public void setRolId(String rolId) {
		getField("ROL_ID").setFormValue(rolId);
		rolBean = EmsCommonUtil.getRolBean(rolId);
	}

	public RolBean getRolBean() {
		return rolBean;
	}
	
	public void setRolBean(RolBean rolBean) {
		this.rolBean = rolBean;
	}

	public ArrayList<String> getAccOrgIdList(){
		ArrayList<String> accOrgIdList = new ArrayList<String>();
		for(int i=0;i<accOrgBeanList.size();i++) {
			accOrgIdList.add(accOrgBeanList.get(i).getOrgId());
		}
		return accOrgIdList;
	}
	
	public ArrayList<OrgBean> getAccOrgBeanList(){
		return accOrgBeanList;
	}
	
	public OrgBean getAccOrgBean(String accOrgId){
		for(int i=0;i<accOrgBeanList.size();i++) {
			if(accOrgId != null && accOrgId.equals(accOrgBeanList.get(i).getOrgId())){
				return accOrgBeanList.get(i);
			}
		}
		return null;
	}
	
	public void setAccOrgBeanList(ArrayList<OrgBean> accOrgBeanList) {
		this.accOrgBeanList = accOrgBeanList;
	}

	public void addAccOrgBeanList(OrgBean accOrgBean) {
		accOrgBeanList.add(accOrgBean);
	}

	public void addAccOrgBeanList(String accOrgId) {
		OrgBean accOrgBean = new OrgBean();
		accOrgBean.setOrgId(accOrgId);
		
		OrgDB orgDB = new OrgDB();
		accOrgBeanList.add(orgDB.getOrgBean(accOrgBean));
	}
	
	
	public boolean isFunIdExist(String funcId) {
		return rolBean.isFunIdExist(funcId);
	}

}
