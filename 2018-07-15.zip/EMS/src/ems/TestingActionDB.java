package ems;
import java.sql.*;

import ems.util.DBUtil;

public class TestingActionDB  {
	public static void testConn() {
		Connection conn = null;
		Statement stmt = null;
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT username, password from em_user_detail";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
	        while(rs.next()){
	        	String username = rs.getString("username");
	            String password = rs.getString("password");
	            System.out.println(username + " "+ password);
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}
}
