package ems.action;

import com.opensymphony.xwork2.ActionSupport;

import ems.bean.AccBalBean;
import ems.bean.LivBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PerBean;
import ems.bean.ResBean;
import ems.bean.ResGrpBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.db.EmsDB;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;
import ems.util.EmsCommonUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

public class newsAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private UserBean userBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "010100";
	
	public String execute() throws Exception {
		
		
		int pos = 1;
		String sql = "";
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String bedCount = "";
		String livCount = "";
		String resCount = "";
		
		try {
				conn = DBUtil.getDataSource().getConnection();
			
				sql = "SELECT COUNT(1) FROM EM_BED_INFO BED " + 
						"WHERE BED.ORG_ID = ? AND BED.BED_STATUS = 'Y' ";
					
				pst = conn.prepareStatement(sql);
				
				pst.setString(pos, userBean.getAccOrgId());
				
				rs = pst.executeQuery();
				
				while(rs.next()){
					
					bedCount = rs.getString(1);
					
				}
			
				sql = "SELECT COUNT(1) FROM EM_LIV_RECORD LIV " + 
						"WHERE LIV.ORG_ID = ? AND LIV.LIV_STATUS = 'Y' ";
					
				pst = conn.prepareStatement(sql);
				
				pst.setString(pos, userBean.getAccOrgId());
				
				rs = pst.executeQuery();
				
				while(rs.next()){
					
					livCount = rs.getString(1);
					
				}
				
				sql = "SELECT COUNT(1) FROM EM_RES_RECORD RES " + 
						"WHERE RES.ORG_ID = ? AND RES.RES_STATUS = 'Y' ";
					
				pst = conn.prepareStatement(sql);
				
				pst.setString(pos, userBean.getAccOrgId());
				
				rs = pst.executeQuery();
				
				while(rs.next()){
					
					resCount = rs.getString(1);
					
				}				
				
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		addActionMessage("");

		if(funcId.length()==6)
			funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
		request.setAttribute("funcId", funcId);
		request.setAttribute("bedCount", bedCount);
		request.setAttribute("livCount", livCount);
		request.setAttribute("resCount", resCount);

		return SUCCESS;
			
	}
	
	public void validate() {
		userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;

		if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
			userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
		}		
	
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

}
