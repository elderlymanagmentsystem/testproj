package ems.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.codec.Base64;

import ems.bean.AccBalBean;
import ems.bean.AccGrpBean;
import ems.bean.CitemBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.QuoBean;
import ems.bean.QuoGrpBean;
import ems.bean.ResBean;
import ems.bean.ResGrpBean;
import ems.bean.StmtBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PatDB;

public class PDFUtil {
	private static ITextRenderer renderer = new ITextRenderer();
	private static String fontPath = "";
	private static String HTML_TAIL = "</body></html>";
	private static String HTML_HEAD = "<!DOCTYPE html><html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>"
			+ "<style>"
			+ " body { "
			+ "    font-family: MingLiU; "
			+ " } "
			+ "@page { margin: 10mm; "
			+ " @top-right { "
			+ "     font-family: MingLiU; "
			+ "     font-size: 16px; "
			+ "     vertical-align: text-top; "
			+ "     padding-top: 4mm; "
			+ "	    content: '頁 ' counter(page) '/' counter(pages);"
			+ " } "
			+ " @bottom-left { "
			+ " vertical-align: text-top; "
			+ "    font-family: MingLiU; "
			+ "    font-size: 16px; "
			+ "    white-space: pre-wrap;"
			+ "    content: '${orgChiName}$\\A地址: ${orgChiAddr}$'"
			+ " } "
			+ " @bottom-right { "
			+ "    font-family: MingLiU; "
			+ "    vertical-align: text-bottom; "
			+ "    white-space: pre-wrap;"
			+ "    font-size: 16px; "
			+ "    content: '\\A電話: ${orgTel}$ 傳真: ${orgFax}$'"
			+ " } "
			+ "} "
			+ "table {border-collapse: collapse;} "
			+ "table td{border: 1px solid black;} "
			+ "</style>"
			+ "</head><body>";
	
	public static boolean gen(String orgId, String path, String htmlContent) {
		//if (true) return gen("", "", "", "", "a.pdf", htmlContent);
		OrgDB orgDB = new OrgDB();
		OrgBean accOrgBean = new OrgBean();
		accOrgBean.setOrgId(orgId);
		orgDB.getOrgBean(accOrgBean);
		
		String orgChiName = accOrgBean.getField("ORG_CHI_NAME").getFormValue();
		String orgChiAddr = accOrgBean.getField("ORG_CHI_ADDR").getFormValue();
		String orgTel = accOrgBean.getField("ORG_TEL").getFormValue();
		String orgFax = accOrgBean.getField("ORG_FAX").getFormValue();
		String orgImageLink = accOrgBean.getField("ORG_IMAGE_LINK").getFormValue();
		if (orgImageLink != null && orgImageLink.trim().length() > 0) {
			orgImageLink = orgImageLink.replace("/",File.separator);
			htmlContent = htmlContent.replace("${logo}$", getImgTag(orgImageLink,100));
		}
		return gen(orgChiName, orgChiAddr, orgTel, orgFax, path, htmlContent);
	}
	
	public static boolean gen(String orgChiName, String orgChiAddr, String orgTel, String orgFax, String path, String htmlContent) {
		if (orgChiName == null) orgChiName = "";
		if (orgChiAddr == null) orgChiAddr = "";
		if (orgTel == null) orgTel = "";
		if (orgFax == null) orgFax = "";
		if (htmlContent == null) htmlContent = "";
		String htmlHead = HTML_HEAD.replace("${orgChiName}$", orgChiName).replace("${orgChiAddr}$", orgChiAddr).replace("${orgTel}$", orgTel).replace("${orgFax}$", orgFax);
		htmlContent = htmlContent.replace("${orgChiName}$", orgChiName).replace("${orgChiAddr}$", orgChiAddr).replace("${orgTel}$", orgTel).replace("${orgFax}$", orgFax);
		htmlHead = htmlHead.replaceAll("\\$\\{([^<]*)\\}\\$", ""); //replace all remaining {} field to empty string
		htmlContent = htmlContent.replaceAll("\\$\\{([^<]*)\\}\\$", ""); //replace all remaining {} field to empty string
		try
        {
			String projectPath ="";
			String runtimePath ="";
			String filename="";
			if (path != null) {
				path = path.replace("/",File.separator);
				projectPath = EmsCommonUtil.getProjPath()+path.substring(0,path.lastIndexOf(File.separator)+1);
				runtimePath = EmsCommonUtil.getRuntimePath()+path.substring(0,path.lastIndexOf(File.separator)+1);
				filename = path.substring(path.lastIndexOf(File.separator)+1,path.length());
				fontPath = EmsCommonUtil.getRuntimePath() + "font" + File.separator + "mingliu.ttf";
			}
			(new File(projectPath)).mkdirs();
			(new File(runtimePath)).mkdirs();
			
			OutputStream os1 = new FileOutputStream(projectPath+filename);
			OutputStream os2 = new FileOutputStream(runtimePath+filename);
			renderer.getFontResolver().addFont(fontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.setDocumentFromString(htmlHead+htmlContent+HTML_TAIL);
			renderer.layout();
			renderer.createPDF(os1);
			os1.close();
			renderer.createPDF(os2);
			os2.close();
        }
        catch (Throwable t)
        {
            t.printStackTrace();
            return false;
        }
		return true;
    }
	
	public static String getImgTag(String path){
		return getImgTag(path, 0);
	}
	
	public static String getImgTag(String path, int height){
		FileInputStream fileInputStreamReader = null;
		try {
			File file = new File(EmsCommonUtil.getRuntimePath()+File.separator+path);
			fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int)file.length()];
			fileInputStreamReader.read(bytes);
			fileInputStreamReader.close();
			String temp = (height == 0) ? "' style='height: 100%; width: auto'/>" : "' style='height: " + height + "px; width: auto'/>" ;
			return "<img src='data:image/jpg;base64, " + new String(Base64.encodeBytes(bytes)) + temp ;
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
    }
	
	// --------template start------- //
	
	//訂金收據-A5
	public static void genDownPaymentSlip(ResGrpBean resGrpBean, UserBean userBean) {
		TransBean transBean = resGrpBean.getTransBean();
		String perChiName = resGrpBean.getField("PER_CHI_NAME").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traReceiptId = transBean.getField("TRA_TYPE").getFormValue() + transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traType = EmsCommonUtil.getTraTypeWording(transBean.getField("TRA_TYPE").getFormValue());
		String traName = transBean.getField("TRA_NAME").getFormValue();
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		String staffName = userBean.getField("PER_CHI_NAME").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>訂金收據 ${toWhom}$</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>負責同事:</td>" + 
				"	<td>${staffName}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traName}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>已付訂金總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/>";
		String REMARKS_AND_STAMP = "<p>注意: 以上已付訂金將不會退回</p><br/><br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId).replace("${staffName}$", staffName);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traName}$", traName).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		String copy1 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy1 = copy1.replace("${toWhom}$", "(公司正本)");
		String dottedLine = "<br/><table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none;'>${orgChiName}$<br/>地址: ${orgChiAddr}$</td>"
				+ "<td style='border:none; text-align: right'><br/>電話: ${orgTel}$ 傳真: ${orgFax}$</td>"
				+ "</tr>"
				+ "</table><br/>"
				+ "<hr style='border:none; border-top: 2px dashed black;'/><br/>"
				+ "<table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none; text-align: right'>頁 1&#47;1</td>"
				+ "</tr></table><br/>";
		String copy2 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy2 = copy2.replace("${toWhom}$", "(客戶存根)");
		PDFUtil.gen(resGrpBean.getOrgId(), traPdfFile, copy1+dottedLine+copy2);
	}
	
	//按金收據-A5
	public static void genDepositeSlip(PatGrpBean patGrpBean, UserBean userBean) {
		TransBean transBean = patGrpBean.getTransBean();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traName = transBean.getField("TRA_NAME").getFormValue();
		String traReceiptId = transBean.getField("TRA_TYPE").getFormValue() + transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		String staffName = userBean.getField("PER_CHI_NAME").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>按金收據 ${toWhom}$</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>負責同事:</td>" + 
				"	<td>${staffName}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traType}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>按金總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String REMARKS_AND_STAMP = "<br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${patId}$", patId).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId).replace("${staffName}$", staffName);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traName}$", traName).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		String copy1 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy1 = copy1.replace("${toWhom}$", "(公司存根)");
		String dottedLine = "<br/><table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none;'>${orgChiName}$<br/>地址: ${orgChiAddr}$</td>"
				+ "<td style='border:none; text-align: right'><br/>電話: ${orgTel}$ 傳真: ${orgFax}$</td>"
				+ "</tr>"
				+ "</table><br/>"
				+ "<hr style='border:none; border-top: 2px dashed black;'/><br/>"
				+ "<table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none; text-align: right'>頁 1&#47;1</td>"
				+ "</tr></table><br/>";
		String copy2 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy2 = copy2.replace("${toWhom}$", "(客戶存根)");
		
		PDFUtil.gen(patGrpBean.getOrgId(), traPdfFile, copy1 + dottedLine + copy2);
	}
	
	public static void genRtnDepositeSlip(PatGrpBean patGrpBean, UserBean userBean) {
		TransBean transBean = patGrpBean.getTransBean();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traName = transBean.getField("TRA_NAME").getFormValue();
		String traReceiptId = transBean.getField("TRA_TYPE").getFormValue() + transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		String staffName = userBean.getField("PER_CHI_NAME").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>按金收據 ${toWhom}$</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>負責同事:</td>" + 
				"	<td>${staffName}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traType}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>退回按金總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String REMARKS_AND_STAMP = "<br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${patId}$", patId).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId).replace("${staffName}$", staffName);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traName}$", traName).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		String copy1 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy1 = copy1.replace("${toWhom}$", "(公司存根)");
		String dottedLine = "<br/><table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none;'>${orgChiName}$<br/>地址: ${orgChiAddr}$</td>"
				+ "<td style='border:none; text-align: right'><br/>電話: ${orgTel}$ 傳真: ${orgFax}$</td>"
				+ "</tr>"
				+ "</table><br/>"
				+ "<hr style='border:none; border-top: 2px dashed black;'/><br/>"
				+ "<table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none; text-align: right'>頁 1&#47;1</td>"
				+ "</tr></table><br/>";
		String copy2 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP;
		copy2 = copy2.replace("${toWhom}$", "(客戶存根)");
		
		PDFUtil.gen(patGrpBean.getOrgId(), traPdfFile, copy1 + dottedLine + copy2);
	}	
	//付款收據-A5
	public static void genReceiptSlip(PatGrpBean patGrpBean) {
		TransBean transBean = patGrpBean.getTransBean();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traType = EmsCommonUtil.getTraTypeWording(transBean.getField("TRA_TYPE").getFormValue());
		String traReceiptId = transBean.getField("TRA_TYPE").getFormValue() + transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		if(!transBean.getField("TRA_REMARK1").getFormValue().equals("")) {
			if(traNote.equals(""))
				traNote = transBean.getField("TRA_REMARK1").getFormValue();
			else
				traNote = traNote +"<br/>"+transBean.getField("TRA_REMARK1").getFormValue();
		}
		if(!transBean.getField("TRA_REMARK2").getFormValue().equals("")) {
			if(traNote.equals(""))
				traNote = transBean.getField("TRA_REMARK2").getFormValue();
			else
				traNote = traNote +"<br/>"+transBean.getField("TRA_REMARK2").getFormValue();
		}
		if(!transBean.getField("TRA_REMARK3").getFormValue().equals("")) {
			if(traNote.equals(""))
				traNote = transBean.getField("TRA_REMARK3").getFormValue();
			else
				traNote = traNote +"<br/>"+transBean.getField("TRA_REMARK3").getFormValue();
		}
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>付款收據 ${toWhom}$</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traType}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>已付款總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String STAMP = "<br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${patId}$", patId).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traType}$", traType).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		String copy1 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+STAMP;
		copy1 = copy1.replace("${toWhom}$", "(公司存根)");
		String dottedLine = "<br/><table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none;'>${orgChiName}$<br/>地址: ${orgChiAddr}$</td>"
				+ "<td style='border:none; text-align: right'><br/>電話: ${orgTel}$ 傳真: ${orgFax}$</td>"
				+ "</tr>"
				+ "</table><br/>"
				+ "<hr style='border:none; border-top: 2px dashed black;'/><br/>"
				+ "<table style='width:100%'>"
				+ "<tr>"
				+ "<td style='border:none; text-align: right'>頁 1&#47;1</td>"
				+ "</tr></table><br/>";
		String copy2 = headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+STAMP;
		copy2 = copy2.replace("${toWhom}$", "(客戶存根)");
		
		PDFUtil.gen(patGrpBean.getOrgId(), traPdfFile, copy1 + dottedLine + copy2);
	}
	
	//報價確認書
	public static void genQuoConfirmSlip(QuoGrpBean quoGrpBean) {
		QuoBean quoBean = quoGrpBean.getQuoBeanList().get(0);
		String perChiName = quoGrpBean.getField("PER_CHI_NAME").getFormValue();
		String bedFullName = (new BedDB().getBedFullName(quoBean.getBedId(), quoBean.getZoneId(), quoGrpBean.getOrgId()));
		String quoStartDate = quoBean.getField("QUO_START_DATE").getFormValue();
		String quoLivingFee = quoBean.getField("QUO_LIVING_FEE").getFormValue();
		String quoNursingFee = quoBean.getField("QUO_NURSING_FEE").getFormValue();
		String quoAddLivingFee = quoBean.getField("QUO_ADD_LIVING_FEE").getFormValue();
		String quoPdfFile = quoBean.getField("QUO_PDF_FILE").getFormValue();
		String ass2 = quoGrpBean.getField("PER_ASS2").getFormValue();
		
		if(ass2.equals("1"))
			ass2 = "1. 正餐";
		else if(ass2.equals("2"))
			ass2 = "2. 碎餐";
		else if(ass2.equals("3"))
			ass2 = "3. 餬餐";
		else if(ass2.equals("4"))
			ass2 = "4. 管飼";
		else if(ass2.equals("5"))
			ass2 = "5. 特別餐";
		else if(ass2.equals("6"))
			ass2 = "6.不適用";
		if(!quoGrpBean.getField("PER_ASS2_OTH").getFormValue().equals(""))
			ass2 = ass2 + " ("  + quoGrpBean.getField("PER_ASS2_OTH").getFormValue() + ")";

		String ass3 = quoGrpBean.getField("PER_ASS3").getFormValue();
		if(ass3.equals("1"))
			ass3 = "1. 需要用尿片";
		else if(ass3.equals("2"))
			ass3 = "2. 尿喉護理";
		else if(ass3.equals("3"))
			ass3 = "3. 其他造口護理";
		else if(ass3.equals("4"))
			ass3 = "4. 其他";
		else if(ass3.equals("5"))
			ass3 = "5.不適用";
		if(!quoGrpBean.getField("PER_ASS3_OTH").getFormValue().equals(""))
			ass3 = ass3 + " ("  + quoGrpBean.getField("PER_ASS3_OTH").getFormValue() + ")";

		String ass4 = quoGrpBean.getField("PER_ASS4").getFormValue();
		if(ass4.equals("1"))
			ass4 = "1. 自理";
		else if(ass4.equals("2"))
			ass4 = "2. 半護理";
		else if(ass4.equals("3"))
			ass4 = "3. 全護理";
		else if(ass4.equals("4"))
			ass4 = "4. 特別護理";
		else if(ass4.equals("5"))
			ass4 = "5.不適用";
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>報價確認書</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='left'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>床位號碼:</td>" + 
				"	<td>${bedFullName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>報價日期:</td>" + 
				"	<td>${quoStartDate}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String LIV_FEE_AND_DEPOSITE = "<table style='width:100%'>" +  
				"<col width='15%'/> " +
				"<col width='30%'/> " +
				"<col width='20%'/> " +
				"<col width='35%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='4'>院<br/>費</td> " +
			    "<td>收費項目</td> " +
			    "<td colspan='2'>收費</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;院費</td> " +
			    "<td style='border-right-style: none'>$ ${quoLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;護理費</td> " +
			    "<td style='border-right-style: none'>$ ${quoNursingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;床位附加費</td> " +
			    "<td style='border-right-style: none'>$ ${quoAddLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
				"</table> "+
			    "<br/>"+
				"<br/>";
		
		String nursing = "<table style='width:100%'>" +  
				"<col width='15%'/> " +
				"<col width='30%'/> " +
				"<col width='20%'/> " +
				"<col width='35%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='4'>護<br/>理<br/>費</td> " +
			    "<td>護理項目</td> " +
			    "<td colspan='2'>選項</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>飲食種類</td> " +
			    "<td colspan='2'>${ass2}$</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>護理服務</td> " +
			    "<td colspan='2'>${ass3}$</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>護理程度</td> " +
			    "<td colspan='2'>${ass4}$</td> " +
			    "</tr> "+
				"</table> ";
		
		String REMARKS_AND_STAMP = "<br/><br/><br/>"+
		        "<table width='100%'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td style='border: none'>院舍代表姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" +
				"	<td style='border: none'>院友/院友家屬姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"</table>";
		
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${bedFullName}$", bedFullName).replace("${quoStartDate}$", quoStartDate);
		String livFeeAndDeposite = LIV_FEE_AND_DEPOSITE.replace("${quoLivingFee}$", quoLivingFee).replace("${quoNursingFee}$", quoNursingFee).replace("${quoAddLivingFee}$", quoAddLivingFee);
		nursing = nursing.replace("${ass2}$", ass2).replace("${ass3}$", ass3).replace("${ass4}$", ass4);
		PDFUtil.gen(quoGrpBean.getOrgId(), quoPdfFile, headerAndInfo+livFeeAndDeposite+nursing+REMARKS_AND_STAMP);	
	}
	
	//訂位確認書
	public static void genResConfirmSlip(ResGrpBean resGrpBean) {
		ResBean resBean = resGrpBean.getResBeanList().get(0);
		TransBean transBean = resGrpBean.getTransBean();
		String perChiName = resGrpBean.getField("PER_CHI_NAME").getFormValue();
		String bedFullName = (new BedDB().getBedFullName(resBean.getBedId(), resBean.getZoneId(), resGrpBean.getOrgId()));
		String resStartDate = resBean.getField("RES_START_DATE").getFormValue();
		String resLivingFee = resBean.getField("RES_LIVING_FEE").getFormValue();
		String resNursingFee = resBean.getField("RES_NURSING_FEE").getFormValue();
		String resAddLivingFee = resBean.getField("RES_ADD_LIVING_FEE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String resPdfFile = resBean.getField("RES_PDF_FILE").getFormValue();
		String ass2 = resGrpBean.getField("PER_ASS2").getFormValue();
		if(ass2.equals("1"))
			ass2 = "1. 正餐";
		else if(ass2.equals("2"))
			ass2 = "2. 碎餐";
		else if(ass2.equals("3"))
			ass2 = "3. 餬餐";
		else if(ass2.equals("4"))
			ass2 = "4. 管飼";
		else if(ass2.equals("5"))
			ass2 = "5. 特別餐";
		else if(ass2.equals("6"))
			ass2 = "6.不適用";
		if(!resGrpBean.getField("PER_ASS2_OTH").getFormValue().equals(""))
			ass2 = ass2 + " ("  + resGrpBean.getField("PER_ASS2_OTH").getFormValue() + ")";

		String ass3 = resGrpBean.getField("PER_ASS3").getFormValue();
		if(ass3.equals("1"))
			ass3 = "1. 需要用尿片";
		else if(ass3.equals("2"))
			ass3 = "2. 尿喉護理";
		else if(ass3.equals("3"))
			ass3 = "3. 其他造口護理";
		else if(ass3.equals("4"))
			ass3 = "4. 其他";
		else if(ass3.equals("5"))
			ass3 = "5.不適用";
		if(!resGrpBean.getField("PER_ASS3_OTH").getFormValue().equals(""))
			ass3 = ass3 + " ("  + resGrpBean.getField("PER_ASS3_OTH").getFormValue() + ")";

		String ass4 = resGrpBean.getField("PER_ASS4").getFormValue();
		if(ass4.equals("1"))
			ass4 = "1. 自理";
		else if(ass4.equals("2"))
			ass4 = "2. 半護理";
		else if(ass4.equals("3"))
			ass4 = "3. 全護理";
		else if(ass4.equals("4"))
			ass4 = "4. 特別護理";
		else if(ass4.equals("5"))
			ass4 = "5.不適用";
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>訂位確認書</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='left'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>床位號碼:</td>" + 
				"	<td>${bedFullName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>訂位日期:</td>" + 
				"	<td>${resStartDate}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String LIV_FEE_AND_DEPOSITE = "<table style='width:100%'>" +  
				"<col width='15%'/> " +
				"<col width='30%'/> " +
				"<col width='20%'/> " +
				"<col width='35%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='5'>院<br/>費<br/>及<br/>訂<br/>金</td> " +
			    "<td>收費項目</td> " +
			    "<td colspan='2'>收費</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;院費</td> " +
			    "<td style='border-right-style: none'>$ ${resLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;護理費</td> " +
			    "<td style='border-right-style: none'>$ ${resNursingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;床位附加費</td> " +
			    "<td style='border-right-style: none'>$ ${resAddLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;&shy;訂金</td> " +
			    "<td colspan='2'>$ ${traAmount}$</td> " +
			    "</tr> "+
				"</table> "+
			    "<br/>"+
				"<br/>";
		
		String nursing = "<table style='width:100%'>" +  
				"<col width='15%'/> " +
				"<col width='30%'/> " +
				"<col width='20%'/> " +
				"<col width='35%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='4'>護<br/>理<br/>費</td> " +
			    "<td>護理項目</td> " +
			    "<td colspan='2'>選項</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>飲食種類</td> " +
			    "<td colspan='2'>${ass2}$</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>護理服務</td> " +
			    "<td colspan='2'>${ass3}$</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>護理程度</td> " +
			    "<td colspan='2'>${ass4}$</td> " +
			    "</tr> "+
				"</table> ";
		
		String REMARKS_AND_STAMP = "<p>註: 訂金將保留14日, 過後訂金將不會退還 </p><br/><br/><br/>"+
		        "<table width='100%'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td style='border: none'>院舍代表姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" +
				"	<td style='border: none'>院友/院友家屬姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"</table>";
		
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${bedFullName}$", bedFullName).replace("${resStartDate}$", resStartDate);
		String livFeeAndDeposite = LIV_FEE_AND_DEPOSITE.replace("${resLivingFee}$", resLivingFee).replace("${resNursingFee}$", resNursingFee).replace("${resAddLivingFee}$", resAddLivingFee).replace("${traAmount}$", traAmount);
		nursing = nursing.replace("${ass2}$", ass2).replace("${ass3}$", ass3).replace("${ass4}$", ass4);
		PDFUtil.gen(resGrpBean.getOrgId(), resPdfFile, headerAndInfo+livFeeAndDeposite+nursing+REMARKS_AND_STAMP);	
	}
	
	//結帳單-A4
	public static void genStmtSlip(PatGrpBean patGrpBean) {
		TransBean transBean = patGrpBean.getTransBean();
		String stmPdfFile = "";	
		OrgDB orgDB = new OrgDB(); 
		OrgBean accOrgBean = new OrgBean();
		accOrgBean.setOrgId(patGrpBean.getField("ORG_ID").getFormValue());
		orgDB.getOrgBean(accOrgBean);
		
		String orgTel = accOrgBean.getField("ORG_TEL").getFormValue();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String bedFullName = ""; //(new BedDB().getBedFullName(patGrpBean.getLivBeanList().get(0).getBedId()));
		if(patGrpBean.getLivBeanList().size()>0) {
			bedFullName = patGrpBean.getLivBeanList().get(0).getBedBean().getBedFullName();
		}
		String cutOffDate = patGrpBean.getTransBean().getField("TRA_DATE").getFormValue();
		String expDate = "";
		java.util.Date exp = null;
		if(patGrpBean.getTransBean().getField("TRA_DATE").getValue() != null) {
			exp = new java.util.Date(((java.sql.Date)patGrpBean.getTransBean().getField("TRA_DATE").getValue()).getTime());
			Calendar cal = Calendar.getInstance();
			cal.setTime(exp);
			cal.add(Calendar.MONTH, 1);
			cal.add(Calendar.DATE, -1);
			exp = cal.getTime();
			expDate = DataTypeUtil.beanDate2FormDate(new java.sql.Date(exp.getTime()));
		}
		String stmtTotalAmount = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BALANCE").getValue()));
		String traDeposite = patGrpBean.getAccBalBean().getField("ACC_DEPOSIT").getFormValue();
		String current = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((BigDecimal)patGrpBean.getTransBean().getField("TRA_AMOUNT").getValue()));
		String a30to60 = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract(((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BAL_EXC30").getValue()).subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BAL_EXC60").getValue())));
		String a60to90 = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BAL_EXC60").getValue()));
		String shouldPay = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BALANCE").getValue()));
		
		String chequeName = accOrgBean.getField("ORG_CHEQUE_NAME").getFormValue();
		String bankName = EmsCommonUtil.getBankName(accOrgBean.getField("ORG_BAN_ID").getFormValue());
		String bankAC = accOrgBean.getField("ORG_BAN_ACC_NO").getFormValue();
		String FPS = accOrgBean.getField("ORG_FPS").getFormValue();
		
		String HEADER_AND_INFO = "<table style='font-size: 20px; width:100%; height:60px'>" + 
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr style='vertical-align: center;'>" +
				"	<td style='border: none; text-align: left'>${logo}$</td>" + 
				"	<td style='border: none;'>&shy;&shy;&shy;月結單<br/>MONTHLY STATEMENT</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
				"<table width='100%'>" +  
				"<col width='35%'/> " +
				"<col width='15%'/> " +
				"<col width='17%'/> " +
				"<col width='15%'/> " +
				"<col width='18%'/> " +
				"<tr>" + 
				"	<td rowspan='2' style='border: 0px'></td>" +
				"	<td style='border: 0px'>院友編號:<br/>&shy;</td>" + 
				"	<td style='border: 0px'>${patId}$<br/>&shy;</td>" + 
				"	<td style='border: 0px'>床位號碼:<br/>&shy;</td>" +
				"	<td style='border: 0px'>${bedFullName}$<br/>&shy;</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td style='border: 0px'>截數日期:<br/>&shy;</td>" + 
				"	<td style='border: 0px'>${cutOffDate}$<br/>&shy;</td>" + 
				"	<td style='border: 0px'>到期付款日:<br/>&shy;</td>" + 
				"	<td style='border: 0px'>${expDate}$<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td rowspan='2'>院友姓名: ${perChiName}$</td>" +
				"	<td style='border: 0px'>總結欠帳項:<br/>&shy;</td>" + 
				"	<td colspan='3' style='border: 0px'>${stmtTotalAmount}$<br/>&shy;</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td colspan='4' style='border: 0px'>*提醒:必須在 60 天內付款。過期付款，可被加收利息</td>" + 
				"</tr>" +
				"</table>" +
				"<table style='border: none; width:100%;'><tr style='border: none;'><td style='border: none; border-bottom: 0.5pt solid black;'>&shy;</td></tr></table>"+
				"<br/>";
		
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='13%'/> " +
				"<col width='15%'/> " +
				"<col width='20%'/> " +
				"<col width='17%'/> " +
				"<col width='15%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>收費項目</td>" +
				"	<td>備註</td>" + 
				"	<td>該付</td>" + 
				"	<td>己付</td>" + 
				"	<td style='text-align: right'>結餘</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${stmDate}$</td>" + 
				"	<td>${chiId}$</td>" + 
				"	<td>${stmNote}$</td>" + 
				"	<td>${stmShouldPay}$</td>" + 
				"	<td>${stmHasPay}$</td>" + 
				"	<td style='text-align: right'>${stmAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;' colspan='4'>如有查詢，可聯絡本院辨事處。 電話 : ${orgTel}$</td>" +
				"	<td style='background-color:WhiteSmoke; text-align: right'>總結餘</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DEPOSITE = "<tr>" + 
				"	<td style='border:none;' colspan='4'>&nbsp;</td>" +
				"	<td style='border:none; text-align: right' colspan='2'>(己付按金: HK$ ${traDeposite}$)</td>" +
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		
		String REMAINING_AMOUNT ="<table style='width:100%; text-align: center'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td>本月</td>" + 
				"	<td>30 - 60 天</td>" + 
				"	<td>60  天以上</td>" +
				"	<td>應付金額</td>" + 
				"</tr>"+
				"<tr>" + 
				"	<td>HK$ ${current}$</td>" + 
				"	<td>HK$ ${a30to60}$</td>" + 
				"	<td>HK$ ${a60to90}$</td>" +
				"	<td>HK$ ${shouldPay}$</td>" +
				"</tr>"+
				"</table><br/><br/>";
		
		String REMARKS = "<table width='65%'>" +  
					"<tr><td style='border: none; background-color:LightSteelBlue;color:white;'>繳款細則</td></tr>" + 
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>付款方法: 現金 &#47; 轉賬 &#47; 支票 &#47; 現金支票 &#47; FPS</td></tr>" + 
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>支票抬頭 : ${chequeName}$</td></tr>" +
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>${bankName}$: ${bankAC}$</td></tr>" +
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>FPS ID: ${FPS}$</td></tr>" +
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>* 如客人親身入賬或經銀行轉賬，煩請傳真入數記錄至本院舍</td></tr>" +
					"<tr><td style='border: none; border-bottom: 0.5pt solid black;'>(入數記錄請註明院友姓名及付款月份)*</td></tr>" +
				"</table>";
		
		
		String trxDetail = "";
		BigDecimal traTotalAmount = new BigDecimal("0");
		for (int i=0;patGrpBean.getStmtBeanList() != null && i<patGrpBean.getStmtBeanList().size();i++) {
			String stmShouldPay = "";
			String stmHasPay = "";			

			StmtBean stmtBean = patGrpBean.getStmtBeanList().get(i);
			if(stmtBean.getField("CHI_NAME").getFormValue().equals("上月結餘")) {
				traTotalAmount = (BigDecimal)stmtBean.getField("STM_AMOUNT").getValue();
			}else if(stmtBean.getField("CHI_NAME").getFormValue().equals("付款")) {
				stmHasPay = stmtBean.getField("STM_AMOUNT").getFormValue();
				traTotalAmount = traTotalAmount.add((BigDecimal)stmtBean.getField("STM_AMOUNT").getValue());
			}else {
				stmShouldPay = stmtBean.getField("STM_AMOUNT").getFormValue();
				traTotalAmount = traTotalAmount.subtract((BigDecimal)stmtBean.getField("STM_AMOUNT").getValue());
			}

			
			
			
			String stmDate= stmtBean.getField("STM_DATE").getFormValue();
			String chiId= stmtBean.getField("CHI_NAME").getFormValue(); 
			String stmAmount = DataTypeUtil.beanAmt2FormAmt(traTotalAmount);  

			String stmNote = "";
			if(!stmtBean.getField("STM_END_DATE").getFormValue().equals(""))
				stmNote = DataTypeUtil.beanDate2SlipDate((Date)stmtBean.getField("STM_START_DATE").getValue()) + " - " + DataTypeUtil.beanDate2SlipDate((Date)stmtBean.getField("STM_END_DATE").getValue());
			else
				stmDate = stmtBean.getField("STM_START_DATE").getFormValue();
			
			trxDetail = trxDetail + TRX_DETAIL_REC.replace("${stmDate}$", stmDate).replace("${chiId}$", chiId).replace("${stmAmount}$", stmAmount).replace("${stmNote}$", stmNote).replace("${stmHasPay}$", stmHasPay).replace("${stmAmount}$", stmAmount).replace("${stmShouldPay}$", stmShouldPay);
		}		
		
		stmPdfFile= patGrpBean.getTransBean().getField("TRA_PDF_FILE").getFormValue();
		String headerAndInfo= HEADER_AND_INFO.replace("${patId}$", patId).replace("${bedFullName}$", bedFullName).replace("${cutOffDate}$", cutOffDate).replace("${expDate}$", expDate).replace("${perChiName}$", perChiName).replace("${stmtTotalAmount}$", stmtTotalAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traTotalAmount.toString()).replace("${orgTel}$", orgTel.toString());
		String trxDeposite =  TRX_DEPOSITE.replace("${traDeposite}$", traDeposite);
		String remainingAmount = REMAINING_AMOUNT.replace("${current}$", current).replace("${a30to60}$", a30to60).replace("${a60to90}$", a60to90).replace("${shouldPay}$", shouldPay);
		REMARKS = REMARKS.replace("${chequeName}$", chequeName).replace("${bankName}$", bankName).replace("${bankAC}$", bankAC).replace("${FPS}$", FPS);
		PDFUtil.gen(patGrpBean.getOrgId(), stmPdfFile, headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+trxDeposite+TRX_DETAIL_FOOTER+remainingAmount+REMARKS);
	}
	
	//入住合約
	public static void genLivConfirmSlip(PatGrpBean patGrpBean, AccGrpBean accGrpBean) {
		LivBean livBean = patGrpBean.getLivBeanList().get(0);
		TransBean transBean = patGrpBean.getTransBean();
		String livPdfFile = livBean.getField("LIV_PDF_FILE").getFormValue();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String perHKID = patGrpBean.getField("PER_HKID").getFormValue();
		String bedFullName = (new BedDB().getBedFullName(livBean.getBedId(), livBean.getZoneId(), livBean.getOrgId()));
		AccBalBean accBalBean = patGrpBean.getAccBalBean();
		String deposit = accBalBean.getField("ACC_DEPOSIT").getFormValue();
		String livStartDate = livBean.getField("LIV_START_DATE").getFormValue();
		String livLivingFee = livBean.getField("LIV_LIVING_FEE").getFormValue();
		String livNursingFee = livBean.getField("LIV_NURSING_FEE").getFormValue();
		String livAddLivingFee = livBean.getField("LIV_ADD_LIVING_FEE").getFormValue();
		String ass2 = patGrpBean.getField("PER_ASS2").getFormValue();
		if(ass2.equals("1"))
			ass2 = "1. 正餐";
		else if(ass2.equals("2"))
			ass2 = "2. 碎餐";
		else if(ass2.equals("3"))
			ass2 = "3. 餬餐";
		else if(ass2.equals("4"))
			ass2 = "4. 管飼";
		else if(ass2.equals("5"))
			ass2 = "5. 特別餐";
		else if(ass2.equals("6"))
			ass2 = "6.不適用";
		if(!patGrpBean.getField("PER_ASS2_OTH").getFormValue().equals(""))
			ass2 = ass2 + " ("  + patGrpBean.getField("PER_ASS2_OTH").getFormValue() + ")";

		String ass3 = patGrpBean.getField("PER_ASS3").getFormValue();
		if(ass3.equals("1"))
			ass3 = "1. 需要用尿片";
		else if(ass3.equals("2"))
			ass3 = "2. 尿喉護理";
		else if(ass3.equals("3"))
			ass3 = "3. 其他造口護理";
		else if(ass3.equals("4"))
			ass3 = "4. 其他";
		else if(ass3.equals("5"))
			ass3 = "5.不適用";
		if(!patGrpBean.getField("PER_ASS3_OTH").getFormValue().equals(""))
			ass3 = ass3 + " ("  + patGrpBean.getField("PER_ASS3_OTH").getFormValue() + ")";

		String ass4 = patGrpBean.getField("PER_ASS4").getFormValue();
		if(ass4.equals("1"))
			ass4 = "1. 自理";
		else if(ass4.equals("2"))
			ass4 = "2. 半護理";
		else if(ass4.equals("3"))
			ass4 = "3. 全護理";
		else if(ass4.equals("4"))
			ass4 = "4. 特別護理";
		else if(ass4.equals("5"))
			ass4 = "5.不適用";
		ArrayList<CitemBean> citemBeanList = accGrpBean.getCitemBeanList();
		
		String FIXED_FEE_ITEM = "";
		int citemCount = 0;
		for(int i=0;i<citemBeanList.size();i++) {
			
			if(citemBeanList.get(i).getCitemCatId().equals("1")) {
				FIXED_FEE_ITEM = FIXED_FEE_ITEM + "<tr><td>"+citemBeanList.get(i).getField("CHI_NAME").getFormValue()+"</td><td style='border-right-style: none'>$"+citemBeanList.get(i).getField("CHI_UNIT_PRICE").getFormValue()+"</td><td style='border-left-style: none'>&#47;"+citemBeanList.get(i).getField("CHI_UNIT").getFormValue()+"</td><td></td></tr> ";
				citemCount = citemCount + 1;
			}
		}
		
		String HEADER_AND_INFO = "<table style='font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>入住收費協議</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
		        "<table width='100%'>" +
				"<col width='8%'/> " +
				"<col width='70%'/> " +
				"<col width='22%'/> " +
		        "<tr><td style='border: 0px'></td><td style='border: 0px'>" +
				"<table style='width:100%;'>" +  
				"<col width='23%'/> " +
				"<col width='27%'/> " +
				"<col width='23%'/> " +
				"<col width='27%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"	<td>床位號碼:</td>" + 
				"	<td>${bedFullName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>身份證號碼:</td>" + 
				"	<td>${perHKID}$</td>" + 
				"	<td>入住日期:</td>" + 
				"	<td>${livStartDate}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td><td style='border: 0px'></td></tr></table>" +
				"<br/>";
		String LIV_FEE = "<table style='width:100%'>" +  
				"<col width='8%'/> " +
				"<col width='10%'/> " +
				"<col width='25%'/> " +
				"<col width='12%'/> " +
				"<col width='8%'/> " +
				"<col width='37%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='5'>A</td> " +
			  	"<td rowspan='5'>院<br/>費<br/>及<br/>按<br/>金</td> " +
			    "<td>收費項目</td> " +
			    "<td colspan='2'>收費</td> " +
			    "<td>內容說明</td> " +
			    "</tr><tr> " +
			    "<td>&shy;1. 院費</td> " +
			    "<td style='border-right-style: none'>$ ${livLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "<td>住不足一個月，仍按整月收取院費。若長者入住醫院而未有辦理退住本院手續，則仍需依時繳交本院全數院費。</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;2. 護理費</td> " +
			    "<td style='border-right-style: none'>$ ${livNursingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "<td></td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>&shy;3. 床位附加費</td> " +
			    "<td style='border-right-style: none'>$ ${livAddLivingFee}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "<td></td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>&shy;按金</td> " +
			    "<td style='border-right-style: none'>$ ${deposit}$</td> " +
			    "<td style='border-left-style: none'>&#47;月</td> " +
			    "<td></td> " +
			    "</tr> "+
				"</table> "+
			    "<br/>";
	
		
		
	String NURSING_FEE = "<table style='width:100%'>" +  
				"<col width='8%'/> " +
				"<col width='10%'/> " +
				"<col width='25%'/> " +
				"<col width='12%'/> " +
				"<col width='45%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='4'>B</td> " +
			  	"<td rowspan='4'>護<br/>理<br/>費</td> " +
			    "<td>護理項目</td> " +
			    "<td colspan='2'>選項</td> " +
			    "</tr><tr> " +
			    "<td>飲食種類</td> " +
			    "<td colspan='2'>${ass2}$</td> " +
			    "</tr> " +
			    "<tr> " +
			    "<td>護理服務</td> " +
			    "<td colspan='2'>${ass3}$</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>護理程度</td> " +
			    "<td colspan='2'>${ass4}$</td> " +
			    "</tr> "+
				"</table> "+
			    "<br/>";
	
		String FIXED_FEE = "<table style='width:100%'>" +  
				"<col width='8%'/> " +
				"<col width='10%'/> " +
				"<col width='25%'/> " +
				"<col width='12%'/> " +
				"<col width='8%'/> " +
				"<col width='37%'/> " +
				"<tr style='text-align: center'> " +
			  	"<td rowspan='"+(citemCount+1)+"'>C</td> " +
			  	"<td rowspan='"+(citemCount+1)+"'>恆<br/>常<br/>收<br/>費</td> " +
			    "<td>收費項目</td> " +
			    "<td colspan='2'>收費標準</td> " +
			    "<td>內容說明</td> " +
			    "</tr>" +
			    FIXED_FEE_ITEM +
				"</table> "+
			    "<br/>";
		
		String NON_FIXED_FEE = "<table style='width:100%'>" +  
				"<col width='8%'/> " +
				"<col width='10%'/> " +
				"<col width='25%'/> " +
				"<col width='12%'/> " +
				"<col width='8%'/> " +
				"<col width='37%'/> " +
			    "<tr> " +
			    "<td rowspan='2' style='text-align: center'>D</td> " +
			  	"<td rowspan='2' style='text-align: center'>非<br/>恆<br/>常<br/>收<br/>費</td> " +
			    "<td>活動費用</td> " +
			    "<td colspan='2'></td> " +
			    "<td>其他如外出旅遊、特別生日會、茶樓飲茶及一些特殊的醫護項目等收費活動，本院會提前以口頭或書面通知院友及家屬，由其自由選擇是否參予。</td> " +
			    "</tr> "+
			    "<tr> " +
			    "<td>什項費用</td> " +
			    "<td colspan='2'></td> " +
			    "<td>其他一般雜費可參考【主要雜費價目表】，費用以實報實銷形式計算。</td> " +
			    "</tr> "+
				"</table> ";
		
		String REMARKS_AND_STAMP = "<br/>&shy;&shy;&shy;註: 項目A, B, C將構成每月收費一部份 <br/><br/><br/>"+
		        "<table width='100%'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td style='border: none'>院舍代表姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" +
				"	<td style='border: none'>院友/院友家屬姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"	<td style='border: none'>簽署:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>&shy;<br/>&shy;</td>" + 
				"	<td style='border: none'>日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________<br/>&shy;</td>" + 
				"</tr>" +
				"</table>";
		
		String headerAndInfo= HEADER_AND_INFO.replace("${perChiName}$", perChiName).replace("${perHKID}$", perHKID).replace("${bedFullName}$", bedFullName).replace("${livStartDate}$", livStartDate);
		String livFee = LIV_FEE.replace("${livLivingFee}$", livLivingFee).replace("${livNursingFee}$", livNursingFee).replace("${livAddLivingFee}$", livAddLivingFee).replace("${deposit}$", deposit);
		NURSING_FEE = NURSING_FEE.replace("${ass2}$", ass2).replace("${ass3}$", ass3).replace("${ass4}$", ass4);
		PDFUtil.gen(patGrpBean.getOrgId(), livPdfFile, headerAndInfo+livFee+NURSING_FEE+FIXED_FEE+NON_FIXED_FEE+REMARKS_AND_STAMP);
	}
	
	//退院確認書
	public static void genQuitConfirmSlip(PatGrpBean patGrpBean) {
		LivBean livBean = patGrpBean.getLivBeanList().get(0);
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue(); 
		String perHKID = patGrpBean.getField("PER_HKID").getFormValue(); 
		String livEndDate = livBean.getField("LIV_END_DATE").getFormValue();
		String lastLivDate = livBean.getField("LIV_END_DATE").getFormValue();
		String livPdfFile2 = livBean.getField("LIV_PDF_FILE2").getFormValue();
		
		OrgDB orgDB = new OrgDB();
		OrgBean accOrgBean = new OrgBean();
		accOrgBean.setOrgId(patGrpBean.getField("ORG_ID").getFormValue());
		orgDB.getOrgBean(accOrgBean);
		
		String orgTel = accOrgBean.getField("ORG_TEL").getFormValue();
		String bedFullName = ""; //(new BedDB().getBedFullName(patGrpBean.getLivBeanList().get(0).getBedId()));
		if(patGrpBean.getLivBeanList().size()>0) {
			bedFullName = patGrpBean.getLivBeanList().get(0).getBedBean().getBedFullName();
		}
		String cutOffDate = patGrpBean.getTransBean().getField("TRA_DATE").getFormValue();
		String expDate = "";
		java.util.Date exp = null;
		if(patGrpBean.getTransBean().getField("TRA_DATE").getValue() != null) {
			exp = new java.util.Date(((java.sql.Date)patGrpBean.getTransBean().getField("TRA_DATE").getValue()).getTime());
			Calendar cal = Calendar.getInstance();
			cal.setTime(exp);
			cal.add(Calendar.MONTH, 1);
			cal.add(Calendar.DATE, -1);
			exp = cal.getTime();
			expDate = DataTypeUtil.beanDate2FormDate(new java.sql.Date(exp.getTime()));
		}
		String stmtTotalAmount = DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BALANCE").getValue()));
		String traDeposite = patGrpBean.getAccBalBean().getField("ACC_DEPOSIT").getFormValue();
		String current = patGrpBean.getTransBean().getField("TRA_AMOUNT").getFormValue();
		String a30to60 = DataTypeUtil.beanAmt2FormAmt(((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BAL_EXC30").getValue()).subtract((BigDecimal)patGrpBean.getAccBalBean().getField("ACC_BAL_EXC60").getValue()));
		String a60to90 = patGrpBean.getAccBalBean().getField("ACC_BAL_EXC60").getFormValue();
		String shouldPay = patGrpBean.getAccBalBean().getField("ACC_BALANCE").getFormValue();
		
		String chequeName = accOrgBean.getField("ORG_CHEQUE_NAME").getFormValue();
		String bankName = EmsCommonUtil.getBankName(accOrgBean.getField("ORG_BAN_ID").getFormValue());
		String bankAC = accOrgBean.getField("ORG_BAN_ACC_NO").getFormValue();
		String FPS = accOrgBean.getField("ORG_FPS").getFormValue();		
		
		String HEADER_AND_INFO = "<table style='font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>退院確認書</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='600px'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"	<td colspan='2' style='border: none'></td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" +
				"	<td colspan='2' style='border: none'></td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>身份證號碼:</td>" + 
				"	<td>${perHKID}$</td>" +
				"	<td colspan='2' style='border: none'></td>" + 
				"</tr>" +
				"</table><br/>"+
				"<table width='600px'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td>通知退院日期:</td>" + 
				"	<td>${livEndDate}$</td>" +
				"	<td>最後1天入住日期:</td>" + 
				"	<td>${lastLivDate}$</td>" +
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/>";
		
		String REMARKS = "有關院友的退院結算如下:<br/><br/>未繳款項:";
		
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='15%'/> " +
				"<col width='15%'/> " +
				"<col width='25%'/> " +
				"<col width='15%'/> " +
				"<col width='10%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>收費項目</td>" + 
				"	<td>備註</td>" + 
				"	<td>該付</td>" + 
				"	<td>己付</td>" + 
				"	<td style='text-align: right'>結餘</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${stmDate}$</td>" + 
				"	<td>${chiId}$</td>" + 
				"	<td>${stmNote}$</td>" + 
				"	<td>${stmShouldPay}$</td>" + 
				"	<td>${stmHasPay}$</td>" + 
				"	<td style='text-align: right'>${stmAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;' colspan='4'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>總結欠</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr></table><br/><br/>";
		
		String STAMP = "<table width='100%'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td style='border: none'>支票金額:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" +
				"	<td style='border: none'>支票日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" +
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>抬頭:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"	<td style='border: none'>支票銀行:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" +
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>支票號碼:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"	<td style='border: none' colspan='2'><br/>&shy;</td>" +
				"</tr>" +
				"</table><br/><br/>"+
				"<table width='100%'>" +  
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<col width='25%'/> " +
				"<tr>" + 
				"	<td style='border: none'>主管/院長簽名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" +
				"	<td style='border: none'>簽收人簽署或指模:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none' colspan='2'><br/>&shy;</td>" +
				"	<td style='border: none'>簽收人姓名:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td style='border: none'>日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"	<td style='border: none'>日期:<br/>&shy;</td>" + 
				"	<td style='border: none'>_______________ <br/>&shy;</td>" + 
				"</tr>" +
				"</table>";
		
		String trxDetail = "";
		BigDecimal traTotalAmount = new BigDecimal("0");

		for (int i=0;patGrpBean.getStmtBeanList() != null && i<patGrpBean.getStmtBeanList().size();i++) {
			String stmShouldPay = "";
			String stmHasPay = "";			

			StmtBean stmtBean = patGrpBean.getStmtBeanList().get(i);
			if(stmtBean.getField("CHI_NAME").getFormValue().equals("上月結餘")) {
				traTotalAmount = (BigDecimal)stmtBean.getField("STM_AMOUNT").getValue();
			}else if(stmtBean.getField("CHI_NAME").getFormValue().equals("付款")) {
				stmHasPay = stmtBean.getField("STM_AMOUNT").getFormValue();
				traTotalAmount = traTotalAmount.add((BigDecimal)stmtBean.getField("STM_AMOUNT").getValue());
			}else {
				stmShouldPay = stmtBean.getField("STM_AMOUNT").getFormValue();
				traTotalAmount = traTotalAmount.subtract((BigDecimal)stmtBean.getField("STM_AMOUNT").getValue());
			}

			
			
			
			String stmDate= stmtBean.getField("STM_DATE").getFormValue();
			String chiId= stmtBean.getField("CHI_NAME").getFormValue(); 
			String stmAmount = DataTypeUtil.beanAmt2FormAmt(traTotalAmount);  

			String stmNote = "";
			if(!stmtBean.getField("STM_END_DATE").getFormValue().equals(""))
				stmNote = DataTypeUtil.beanDate2SlipDate((Date)stmtBean.getField("STM_START_DATE").getValue()) + " - " + DataTypeUtil.beanDate2SlipDate((Date)stmtBean.getField("STM_END_DATE").getValue());
			else
				stmDate = stmtBean.getField("STM_START_DATE").getFormValue();
			
			trxDetail = trxDetail + TRX_DETAIL_REC.replace("${stmDate}$", stmDate).replace("${chiId}$", chiId).replace("${stmAmount}$", stmAmount).replace("${stmNote}$", stmNote).replace("${stmHasPay}$", stmHasPay).replace("${stmAmount}$", stmAmount).replace("${stmShouldPay}$", stmShouldPay);
		}		

		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traTotalAmount.toString());
		String headerAndInfo= HEADER_AND_INFO.replace("${patId}$", patId).replace("${perChiName}$", perChiName).replace("${perHKID}$", perHKID).replace("${livEndDate}$", livEndDate).replace("${lastLivDate}$", lastLivDate);
		
		PDFUtil.gen(patGrpBean.getOrgId(), livPdfFile2, headerAndInfo+REMARKS+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+STAMP);
	}
	// --------template end------- //
	

	public static void doMerge(List<InputStream> list, OutputStream outputStream) throws DocumentException, IOException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
        document.open();
        PdfContentByte cb = writer.getDirectContent();
        
        for (InputStream in : list) {
            PdfReader reader = new PdfReader(in);
            for (int i = 1; i <= reader.getNumberOfPages(); i++) {
                document.newPage();
                //import the page from source pdf
                PdfImportedPage page = writer.getImportedPage(reader, i);
                //add the page to the destination pdf
                cb.addTemplate(page, 0, 0);
            }
        }
        
        outputStream.flush();
        document.close();
        outputStream.close();
    }
	
    public static void massPrintStmt(String orgId,int year, int month, String pdfPath) {
    	List<InputStream> list = new ArrayList<InputStream>();
    	try {
    		String outputPath = EmsCommonUtil.getRuntimePath() + pdfPath;
    		String outputPath2 = EmsCommonUtil.getProjPath() + pdfPath;
    		OutputStream out = new FileOutputStream(new File(outputPath));
    		String runtimePath = "";
    		PatDB patDB = new PatDB(); 
    		String[] stmPdfFileList = patDB.getAllStmt(orgId,year,month);
	    	for (int i=0; i < stmPdfFileList.length; i++) {
	    		try {
	    			String path = stmPdfFileList[i];
	    			path = path.replace("/",File.separator);
					runtimePath = EmsCommonUtil.getRuntimePath()+path;
		    		list.add(new FileInputStream(new File(runtimePath)));
		    		System.out.println("Mass Print Stmt: [success] the document exists at " + runtimePath);
				} catch (FileNotFoundException e) {
					System.out.println("Mass Print Stmt: [error] the document is missing at " + runtimePath);
					//e.printStackTrace();
				}
	    	}
	    	
	    	if (list.size() > 0) {
	    		doMerge(list, out);
	    		System.out.println("Mass Print Stmt: [success] The final mass print stmt is located at " + outputPath);
	    		File a = new File(outputPath);
	    		File b = new File(outputPath2);
	    		FileUtils.copyFile(a, b);
	    		System.out.println("Mass Print Stmt: [success] The final mass print stmt is located at " + outputPath2);
	    	} else
	    		System.out.println("Mass Print Stmt: [error] no printable document");
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (DocumentException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
    }
	
	
	public static void main(String [] args) {
		PatGrpBean patGrpBean = new PatGrpBean();
		patGrpBean.setOrgId("1001");
		ResGrpBean resGrpBean = new ResGrpBean();
		resGrpBean.setOrgId("1001");
		QuoGrpBean quoGrpBean = new QuoGrpBean();
		quoGrpBean.setOrgId("1001");
		//PDFUtil.gen("香港仔安老院", "GRANYET (ABERDEEN) ELDERLY CARE CENTRE", "香港仔田灣漁歌街5號xxxxxxxx","12345678", "11112222", "testing1234");
		//genDownPaymentSlip(resGrpBean, userBean);
		//genDepositeSlip(null);
		//genStmtSlip(patGrpBean);
		//genReceiptSlip(patGrpBean);
		//genResConfirmSlip(null);
		//genLivConfirmSlip(patGrpBean);
		//genQuitConfirmSlip(patGrpBean);
		//genQuoConfirmSlip(quoGrpBean);
		
		try {
			byte[] encoded = Files.readAllBytes(Paths.get("C:\\Users\\patri\\Desktop\\a.txt"));
			FileOutputStream fos = new FileOutputStream("C:\\Users\\patri\\Desktop\\a.zip");
			String a = new String(encoded);
			System.out.println(a);
			fos.write(Base64.decode(a));
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
