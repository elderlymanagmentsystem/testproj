package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class CperBean extends CitemBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
	public CperBean() {
		for(int i=0; i<EmsDB.EM_CHP_CHARGE_PERSON.length;i++) {
			if(getField(EmsDB.EM_CHP_CHARGE_PERSON[i][0])==null)
				fields.add(new Field(EmsDB.EM_CHP_CHARGE_PERSON[i]));
		}
	}

	
	
	public String getCperId() {
		return getField("CHP_ID").getFormValue();
	}
	public void setCperId(String cperId) {
		getField("CHP_ID").setFormValue(cperId);
	}

	public String getCitemId() {
		return getField("CHI_ID").getFormValue();
	}
	public void setCitemId(String citemId) {
		getField("CHI_ID").setFormValue(citemId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}
}
