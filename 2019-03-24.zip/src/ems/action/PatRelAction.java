package ems.action;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.QuoBean;
import ems.bean.ResBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.BedModule;
import ems.module.PatModule;
import ems.module.UserModule;
import ems.util.EmsCommonUtil;


public class PatRelAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private PatGrpBean patGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private static final String IMAGE_STORE_DIR="EMS"+File.separator +"WebContent"+File.separator +"images"+File.separator;
	private static final String RUNTIME_IMAGE_STORE_DIR="images"+File.separator;
	private File fileUpload;
	private File fileUpload2;
	private String fileUpload2FileName; 
	
	public static final String DEFAULT_FUNC_ID = "060000";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(patGrpBean == null)
			patGrpBean = new PatGrpBean();
		
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			patMod.performEnqRelPat(patGrpBean, userBean);
		}

		if(patGrpBean.getMsg()==null||patGrpBean.getMsg().length()==0) {
			patGrpBean.cleanup();
			addActionMessage("");

			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(patGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		if(funcId == null || funcId.trim().length()==0)
			funcId = DEFAULT_FUNC_ID;
	}

	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

}
