package ems.action;

import com.opensymphony.xwork2.ActionSupport;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;

public class CsvAction extends ActionSupport {
	private InputStream fileInputStream;
	private String funcId;
	private String flag;
	
	public String execute() throws Exception { 
		if ("Y".equals(flag)) {
			
			//write data to file
			FileWriter fstream = new FileWriter("downloadfile.txt", false);
			BufferedWriter out = null;
		    out = new BufferedWriter(fstream);
		    out.write("field 1,field 2,field 3");
		    out.newLine();
		    out.write("123,456,789");
		    out.newLine();
		    out.close();
			
		    //assign file for struts to download
		    fileInputStream = new FileInputStream(new File("downloadfile.txt"));
			return SUCCESS;
		} else {
			return INPUT;
		}
	}
	
	public void validate() {
	}

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}
	
}
