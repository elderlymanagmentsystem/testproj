package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class UserGrpBean extends UserBean {
	
	String enqOrgId = "";
	String enqRolId = "";
	String enqUserId = "";
	String pwdConfirm = "";
	
	private ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
	public UserGrpBean() {
	}
	
	public String getPwdConfirm() {
		return pwdConfirm;
	}
	public void setPwdConfirm(String pwdConfirm) {
		this.pwdConfirm = pwdConfirm;
	}

	public String getEnqOrgId() {
		return enqOrgId;
	}
	public void setEnqOrgId(String enqOrgId) {
		this.enqOrgId = enqOrgId;
	}

	public String getEnqRolId() {
		return enqRolId;
	}
	public void setEnqRolId(String enqRolId) {
		this.enqRolId = enqRolId;
	}

	public String getEnqUserId() {
		return enqUserId;
	}
	public void setEnqUserId(String enqUserId) {
		this.enqUserId = enqUserId;
	}

/*
	public boolean isOrgIdExist(String orgId){
		for(int i=0;i<orgIdList.size();i++) {
			if(orgId != null && orgId.equals(orgIdList.get(i))){
				return true;
			}
		}
		return false;
	}
*/	
	public ArrayList<UserBean> getUserBeanList(){
		return userBeanList;
	}
	
	public void setUserBeanList(ArrayList<UserBean> userBeanList) {
		this.userBeanList = userBeanList;
	}

	public void addUserBeanList(UserBean userBean) {
		userBeanList.add(userBean);
	}
/*
	public OrgBean getAccOrgBean(String orgId){
		OrgBean orgBean = new OrgBean();
		for(int i=0;i<accOrgBeanList.size();i++) {
			if(accOrgBeanList.get(i).getOrgId().equals(orgId)) {
				orgBean = accOrgBeanList.get(i);
				break;
			}
		}
		return orgBean;
	}
	
	public ArrayList<OrgBean> getAccOrgBeanList(){
		return accOrgBeanList;
	}
	
	public void setAccOrgBeanList(ArrayList<OrgBean> accOrgBeanList) {
		this.accOrgBeanList = accOrgBeanList;
	}

	public void addAccOrgBeanList(OrgBean accOrgBean) {
		accOrgBeanList.add(accOrgBean);
	}

	public RolBean getRolBean(String rolId){
		RolBean rolBean = new RolBean();
		for(int i=0;i<rolBeanList.size();i++) {
			if(rolBeanList.get(i).getRolId().equals(rolId)) {
				rolBean = rolBeanList.get(i);
				break;
			}
		}
		return rolBean;
	}
	
	public ArrayList<RolBean> getRolBeanList(){
		return rolBeanList;
	}
	
	public void setRolBeanList(ArrayList<RolBean> rolBeanList) {
		this.rolBeanList = rolBeanList;
	}

	public void addRolBeanList(RolBean rolBean) {
		rolBeanList.add(rolBean);
	}
*/
	public boolean validate() {
		boolean successFlag = true;
		msg = "";
		getField("PER_STATUS").setFormValue(getField("USE_STATUS").getFormValue());
		
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
			if(field.getName().equals("USE_PWD"))
				if(!field.getFormValue().equals(getPwdConfirm())) {
					successFlag = false;
					field.setMsg("密碼與確認密碼不乎");
				}
					
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
