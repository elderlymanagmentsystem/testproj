package ems.module;

import java.sql.Date;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.db.OrgDB;
import ems.db.UserDB;

public class OrgModule {

	public boolean performEnqOrg(OrgBean orgBean, UserBean userBean) {
		orgBean.setMsg("");
		if(orgBean.getOrgId()==null || orgBean.getOrgId().length()==0)
			orgBean.setOrgId(userBean.getOrgId());
		OrgDB orgDB = new OrgDB();
		orgBean = orgDB.getOrgBean(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performAddOrg(OrgBean orgBean, UserBean userBean, boolean hasImageUpload) {
		System.out.println("AddModule");
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		
		orgBean.setOrgId(orgDB.getNextOrgId());
		
		if(isOrgActive(orgBean))
			orgBean.getField("ORG_STATUS").setFormValue("Y");
		else
			orgBean.getField("ORG_STATUS").setFormValue("N");
		orgBean.getField("ORG_MOD_BY").setValue(userBean.getUserId());

		if(hasImageUpload) {
			orgBean.getField("ORG_IMAGE_LINK").setFormValue("img"+orgBean.getOrgId()+".jpg");
		}
		
		orgBean = orgDB.addOrg(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			orgDB.addOrgRole(orgBean, userBean);
			if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
				UserDB userDB = new UserDB();
				userBean = userDB.getUserBean(userBean);
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
	}
	
	public boolean performModOrg(OrgBean orgBean, UserBean userBean, boolean hasImageUpload) {
		orgBean.setMsg("");
		OrgDB orgDB = new OrgDB();
		if(isOrgActive(orgBean))
			orgBean.getField("ORG_STATUS").setFormValue("Y");
		else
			orgBean.getField("ORG_STATUS").setFormValue("N");

		orgBean.getField("ORG_MOD_BY").setValue(userBean.getUserId());

		if(hasImageUpload) {
			orgBean.getField("ORG_IMAGE_LINK").setFormValue("img"+orgBean.getOrgId()+".jpg");
		}
		
		orgBean = orgDB.updOrg(orgBean);
		if (orgBean!=null && (orgBean.getMsg()==null || orgBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean isOrgActive(OrgBean orgBean) {
		
		boolean isActive = false;
		
		Date startDate = (Date)orgBean.getField("ORG_START_DATE").getValue();
		Date endDate = (Date)orgBean.getField("ORG_END_DATE").getValue();
		Date sysDate = new Date(new java.util.Date().getTime());

		if(startDate == null && endDate == null) {
			isActive = true;
		}else if(startDate != null && endDate != null) {
			if(sysDate.compareTo(startDate)>=0 && sysDate.compareTo(endDate)<=0)
				isActive = true;
		}else if(startDate != null && sysDate.compareTo(startDate)>=0){
			isActive = true;
		}else if(endDate != null && sysDate.compareTo(endDate)<=0){
			isActive = true;
		}
		
		return isActive;
	}
	
}
