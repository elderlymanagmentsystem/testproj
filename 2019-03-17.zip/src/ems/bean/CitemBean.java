package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class CitemBean extends BasicBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
	public CitemBean() {
		for(int i=0; i<EmsDB.EM_CHI_CHARGE_ITEM.length;i++) {
			if(getField(EmsDB.EM_CHI_CHARGE_ITEM[i][0])==null)
				fields.add(new Field(EmsDB.EM_CHI_CHARGE_ITEM[i]));
		}
		for(int i=0; i<EmsDB.EM_CHC_CHARGE_CAT.length;i++) {
			if(getField(EmsDB.EM_CHC_CHARGE_CAT[i][0])==null)
				fields.add(new Field(EmsDB.EM_CHC_CHARGE_CAT[i]));
		}
	}
	
	public String getCitemId() {
		return getField("CHI_ID").getFormValue();
	}
	public void setCitemId(String citemId) {
		getField("CHI_ID").setFormValue(citemId);
	}

	public String getCitemCatId() {
		return getField("CHC_ID").getFormValue();
	}
	public void setCitemCatId(String citemCatId) {
		getField("CHC_ID").setFormValue(citemCatId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

}
