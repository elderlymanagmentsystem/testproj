package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class QuoGrpBean extends PerBean {
	
	String enqPerType = "";
	String enqPerName = "";
	String enqPerId = "";
	String enqStartDate = "";
	String enqEndDate = "";
	
	private ArrayList<BedBean> bedBeanList = new ArrayList<BedBean>();
	private ArrayList<QuoBean> quoBeanList = new ArrayList<QuoBean>();
		
	public QuoGrpBean() {
	}
	

	public String getEnqPerType() {
		return enqPerType;
	}


	public void setEnqPerType(String enqPerType) {
		this.enqPerType = enqPerType;
	}


	public String getEnqPerName() {
		return enqPerName;
	}

	public void setEnqPerName(String enqPerName) {
		this.enqPerName = enqPerName;
	}

	public String getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(String enqPerId) {
		this.enqPerId = enqPerId;
	}

	public ArrayList<QuoBean> getQuoBeanList(){
		return quoBeanList;
	}
	
	public void setQuoBeanList(ArrayList<QuoBean> quoBeanList) {
		this.quoBeanList = quoBeanList;
	}

	public void addQuoBeanList(QuoBean quoBean) {
		quoBeanList.add(quoBean);
	}


	
	
	public ArrayList<BedBean> getBedBeanList(){
		return bedBeanList;
	}
	
	public void setBedBeanList(ArrayList<BedBean> bedBeanList) {
		this.bedBeanList = bedBeanList;
	}

	public void addBedBeanList(BedBean bedBean) {
		bedBeanList.add(bedBean);
	}

	public BedBean getBedBean(String bedId, String orgId){
		for(int i=0;i<bedBeanList.size();i++) {
			if(bedId != null && orgId != null && bedId.equals(bedBeanList.get(i).getBedId()) && orgId.equals(bedBeanList.get(i).getOrgId())){
				return bedBeanList.get(i);
			}
		}
		return null;
	}
	
	public QuoBean getQuoBean(String quoId, String orgId){
		for(int i=0;i<quoBeanList.size();i++) {
			if(quoId != null && orgId != null && quoId.equals(quoBeanList.get(i).getQuoId()) && orgId.equals(quoBeanList.get(i).getOrgId())){
				return quoBeanList.get(i);
			}
		}
		return null;
	}
	
	public void cleanup() {
		setQuoBeanList(new ArrayList<QuoBean>());
		setPcoBeanList(new ArrayList<PcoBean>());
		super.cleanup();
	}
	
	public String getEnqStartDate() {
		return enqStartDate;
	}


	public void setEnqStartDate(String enqStartDate) {
		this.enqStartDate = enqStartDate;
	}


	public String getEnqEndDate() {
		return enqEndDate;
	}


	public void setEnqEndDate(String enqEndDate) {
		this.enqEndDate = enqEndDate;
	}


	public boolean validate() {
		boolean successFlag = true;
		msg = "";
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
