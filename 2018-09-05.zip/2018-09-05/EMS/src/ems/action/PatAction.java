package ems.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.BedModule;
import ems.module.PatModule;
import ems.module.UserModule;


public class PatAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private PatGrpBean patGrpBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	private static final String IMAGE_STORE_DIR="EMS"+File.separator +"WebContent"+File.separator +"images"+File.separator;
	private static final String RUNTIME_IMAGE_STORE_DIR="images"+File.separator;
	private File fileUpload;
	
	public static final String DEFAULT_FUNC_ID = "020100";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			patMod.performEnqPatList(patGrpBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ADD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(patMod.performAddOrUpdatePat(patGrpBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			boolean hasImageUpload = (getFileUpload()==null?false:true);
			if(patMod.performAddOrUpdatePat(patGrpBean, userBean, hasImageUpload)&&hasImageUpload)
				uploadImage();
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_DEL)){
			patMod.performAddOrUpdatePat(patGrpBean, userBean, false);			
		}

		if(patGrpBean.getMsg()==null||patGrpBean.getMsg().length()==0) {
			patGrpBean.cleanup();
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return SUCCESS;
			
			
		}else {
			addActionError(patGrpBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("patGrpBean", patGrpBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(patGrpBean==null)
			patGrpBean = new PatGrpBean();

		for(int i=0;i<patGrpBean.getFields().size();i++){
			patGrpBean.getFields().get(i).setFormValue(request.getParameter(patGrpBean.getFields().get(i).getName()));
		}

		LivBean livBean = new LivBean();
		if(patGrpBean.getLivBeanList().size()==0) {
			patGrpBean.addLivBeanList(livBean);
		}else {
			livBean = patGrpBean.getLivBeanList().get(0); 
		}
		
		for(int i=0;i<livBean.getFields().size();i++){
			livBean.getFields().get(i).setFormValue(request.getParameter(livBean.getFields().get(i).getName()));
		}
		
		livBean.setOrgId(userBean.getAccOrgId());
		
		//change Full Bed Id = Bed Id + Zone Id
		if(request.getParameter("BED_ID") !=null && request.getParameter("BED_ID").indexOf("-")>0) {
			String[] bed_zone = request.getParameter("BED_ID").split("-");
			livBean.setZoneId(bed_zone[0]);
			livBean.setBedId(bed_zone[1]);
		}
		
		PcoBean[] pcoBean = new PcoBean[5];
		for(int i=0;i<5;i++){
			if(patGrpBean.getPcoBeanList().size() > i)
				pcoBean[i] = patGrpBean.getPcoBeanList().get(i);
			else {
				pcoBean[i] = new PcoBean();
				patGrpBean.addPcoBeanList(pcoBean[i]);
			}

			pcoBean[i].getField(EmsDB.EM_PCO_PERSONAL_CONTACT[2][0]).setFormValue(request.getParameter("PCO_SEQ"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).setFormValue(request.getParameter("PCO_CHI_NAME"+(i+1)));
			pcoBean[i].getField(EmsDB.EM_PCO_PERSONAL_CONTACT[4][0]).setFormValue(request.getParameter("PCO_REL"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).setFormValue(request.getParameter("PCO_TEL"+(i+1)));
			pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[9][0]).setFormValue(request.getParameter("PCO_EMAIL"+(i+1)));
			pcoBean[i].setOrgId(userBean.getAccOrgId());
			pcoBean[i].getPerBean().setOrgId(userBean.getAccOrgId());
		}
		
		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {
			
			patGrpBean.setOrgId(userBean.getAccOrgId());
			
			if(funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD)) {

				for(int i=0;i<5;i++) {
					if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).getFormValue().length()>0 && pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).getFormValue().length()==0){ 
						pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).setMsg("必需輸入");
						patGrpBean.setMsg("親友輸入錯誤");
						validated = false;
					}else if(pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).getFormValue().length()==0 && pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[8][0]).getFormValue().length()>0){
						pcoBean[i].getPerBean().getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[2][0]).setMsg("必需輸入");
						patGrpBean.setMsg("親友輸入錯誤");
						validated = false;
					}
				}
	
				if(!patGrpBean.validate())
					validated = false;
				if(livBean.getBedId()!=null && livBean.getZoneId()!=null && livBean.getBedId().length()>0 && livBean.getZoneId().length()>0) {
					if(!livBean.validate())
						validated = false;
				}
			}

			if((funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL)) && patGrpBean.getPatId().length()==0) {
				patGrpBean.getField("PAT_ID").setMsg("必需輸入");
				patGrpBean.setMsg("輸入錯誤");
				validated = false;
			}

			if(!validated) {
				PatModule patMod = new PatModule();
				patMod.performEnqPatList(patGrpBean, userBean);

				request.setAttribute("funcId", funcId);
				request.setAttribute("patGrpBean", patGrpBean);
				addActionError(patGrpBean.getMsg());
			}					

		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	public boolean uploadImage() {
		boolean uploaded = true;
		try {
			
			String fileName = patGrpBean.getField("PER_IMAGE_LINK").getFormValue();
			String path = request.getServletContext().getRealPath("/");
			File runTimeFileToCreate = new File(path+RUNTIME_IMAGE_STORE_DIR, fileName);
			File fileToCreate = new File(path.substring(0, path.indexOf("workspace")+10)+IMAGE_STORE_DIR, fileName);
			
			FileUtils.copyFile(fileUpload, runTimeFileToCreate);			
			FileUtils.copyFile(fileUpload, fileToCreate);			
			
		}catch(Exception e) {
			patGrpBean.setMsg("上載圖檔失敗");
			uploaded = false;
		}
		
		return uploaded;
	}
	
	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}


}
