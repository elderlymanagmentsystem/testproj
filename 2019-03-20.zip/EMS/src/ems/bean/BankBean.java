package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class BankBean extends BasicBean {
	
//	private ArrayList<String> orgIdList = new ArrayList<String>();
	public BankBean() {
		for(int i=0; i<EmsDB.EM_BAN_BANK_CODE.length;i++) {
			if(getField(EmsDB.EM_BAN_BANK_CODE[i][0])==null)
				fields.add(new Field(EmsDB.EM_BAN_BANK_CODE[i]));
		}
	}
	
	public String getBankId() {
		return getField("BAN_ID").getFormValue();
	}
	public void setBankId(String bankId) {
		getField("BAN_ID").setFormValue(bankId);
	}

	public String getBankName() {
		return getField("BAN_NAME").getFormValue();
	}
	public void setBankName(String bankName) {
		getField("BAN_NAME").setFormValue(bankName);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

}
