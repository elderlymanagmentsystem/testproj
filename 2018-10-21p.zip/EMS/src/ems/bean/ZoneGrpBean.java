package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class ZoneGrpBean extends ZoneBean {

	private ArrayList<ZoneBean> zoneBeanList = new ArrayList<ZoneBean>();
		
	public ZoneGrpBean() {
	}
	
	public ArrayList<ZoneBean> getZoneBeanList(){
		return zoneBeanList;
	}
	
	public void setZoneBeanList(ArrayList<ZoneBean> zoneBeanList) {
		this.zoneBeanList = zoneBeanList;
	}

	public void addZoneBeanList(ZoneBean zoneBean) {
		zoneBeanList.add(zoneBean);
	}

	public ZoneBean getZoneBean(String zoneId, String orgId){
		for(int i=0;i<zoneBeanList.size();i++) {
			if(zoneId != null && orgId != null && zoneId.equals(zoneBeanList.get(i).getZoneId()) && orgId.equals(zoneBeanList.get(i).getOrgId())){
				return zoneBeanList.get(i);
			}
		}
		return null;
	}
	
	
	public boolean validate() {
		boolean successFlag = true;
		msg = "";
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
