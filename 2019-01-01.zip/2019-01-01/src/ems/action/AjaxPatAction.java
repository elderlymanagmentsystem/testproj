package ems.action;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

import ems.bean.CorgBean;
import ems.bean.CperBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.module.PatModule;
import ems.util.DataTypeUtil;

public class AjaxPatAction extends ActionSupport implements SessionAware {
	private PatGrpBean patGrpBean;
	private int enqPerId;
	private Map<String, Object> session;
	private String patId = "";
	private String perId = "";
	private String[] pcoChiName;
	private String[] pcoRel;
	private String[] pcoTel;
	private String[] pcoEmail;
	private String[] pcoSeq;
	private String livId = "";
	private String livType = "";
	private String livExitReason = "";
	private String livExitRemark = "";
	private String livStartDate = "";
	private String livEndDate = "";
	private String livLivingFee = "";
	private String livNursingFee = "";
	private String livStatus = "";
	private String livZoneId = "";
	private String livBedId = "";
	private String bedFullName = "";
	private String perChiName = "";
	private String perEngName = "";
	private String perHKID = "";
	private String perGender = "";
	private String perNBirth = "";
	private String perLBirth = "";
	private String perTel = "";
	private String perEmail = "";
	private String perDesc = "";
	private String perImageLink = "";
	private String perLDSRef = "";
	private String perLDSResult = "";
	private String perLDSDate = "";
	private String perAss1 = "";
	private String perAss2 = "";
	private String perAss2Oth = "";
	private String perAss3 = "";
	private String perAss3Oth = "";
	private String perAss4 = "";
	private String perReferal = "";
	private String perReferalOth = "";
	private String perBankId = "";
	private String perBankAccNo = "";
	private String perBankAccName = "";
	private String[] traDate;
	private String[] traName;
	private String[] traMethod;
	private String[] traId;
	private String[] traAmount;
	private String[] traNote;
	private String[] traRecId;
	private String[] traRemark1;
	private String[] traRemark2;
	private String[] traRemark3;
	private String[] traStatus;
	private String accDeposit = "0";
	private String accBal = "0";
	private BigDecimal accLastBal;
	private String stmtBal = "0";
	private String[] cperId;
	private String[] cperItemId;
	private String[] cperItemName;
	private String[] cperItemCatId;
	private String[] cperItemCatName;
	private String[] cperNature;
	private String[] cperQuantity;
	private String[] cperUnitPrice;
	private String[] cperAmount;
	private String[] cperStartDate;
	private String[] cperEndDate;
	private String[] cperPayStartDate;
	private String[] cperPayEndDate;
	private String[] cperPayAmount;
	private String[] cperCurrPayDate;
	private String[] cperRemark;
	private String[] corgId;
	private String[] corgItemId;
	private String[] corgItemName;
	private String[] corgItemCatId;
	private String[] corgItemCatName;
	private String[] corgNature;
	private String[] corgQuantity;
	private String[] corgUnitPrice;
	private String[] corgAmount;
	private String[] corgStartDate;
	private String[] corgEndDate;
	private String[] corgPayStartDate;
	private String[] corgPayEndDate;
	private String[] corgPayAmount;
	private String[] corgCurrPayDate;
	private String[] corgRemark;
	
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(patGrpBean.getEnqPatId() != null && patGrpBean.getEnqPatId().length()>0)
			patMod.performEnqPatDetail(patGrpBean, userBean);
		
		if(patGrpBean.getPcoBeanList().size()>0) {
			ArrayList<String> pcoChiNameList = new ArrayList<String>();
			ArrayList<String> pcoTelList = new ArrayList<String>();
			ArrayList<String> pcoEmailList = new ArrayList<String>();
			ArrayList<String> pcoRelList = new ArrayList<String>();
			ArrayList<String> pcoSeqList = new ArrayList<String>();
			for(int i=0;i<patGrpBean.getPcoBeanList().size();i++) {
				PcoBean pcoBean = patGrpBean.getPcoBeanList().get(i);
				pcoChiNameList.add(pcoBean.getPerBean().getField("PER_CHI_NAME").getFormValue());
				pcoTelList.add(pcoBean.getPerBean().getField("PER_TEL").getFormValue());
				pcoEmailList.add(pcoBean.getPerBean().getField("PER_EMAIL").getFormValue());
				pcoRelList.add(pcoBean.getField("PCO_RELATION").getFormValue());
				pcoSeqList.add(pcoBean.getField("PCO_SEQ").getFormValue());
			}
			setPcoChiName(pcoChiNameList.toArray(new String[0]));
			setPcoTel(pcoTelList.toArray(new String[0]));
			setPcoEmail(pcoEmailList.toArray(new String[0]));
			setPcoRel(pcoRelList.toArray(new String[0]));
			setPcoSeq(pcoSeqList.toArray(new String[0]));

		}else {
			setPcoChiName(new String[] {""});
			setPcoTel(new String[] {""});
			setPcoEmail(new String[] {""});
			setPcoRel(new String[] {""});
			setPcoSeq(new String[] {""});
		}

		if(patGrpBean.getTransBeanList().size()>0) {
			ArrayList<String> traDateList = new ArrayList<String>();
			ArrayList<String> traNameList = new ArrayList<String>();
			ArrayList<String> traMethodList = new ArrayList<String>();
			ArrayList<String> traIdList = new ArrayList<String>();
			ArrayList<String> traAmountList = new ArrayList<String>();
			ArrayList<String> traNoteList = new ArrayList<String>();
			ArrayList<String> traRecIdList = new ArrayList<String>();
			ArrayList<String> traRemark1List = new ArrayList<String>();
			ArrayList<String> traRemark2List = new ArrayList<String>();
			ArrayList<String> traRemark3List = new ArrayList<String>();
			ArrayList<String> traStatusList = new ArrayList<String>();
			
			for(int i=0;i<patGrpBean.getTransBeanList().size();i++) {
				TransBean transBean = patGrpBean.getTransBeanList().get(i);
				traDateList.add(transBean.getField("TRA_DATE").getFormValue());
				traNameList.add(transBean.getField("TRA_NAME").getFormValue());
				traMethodList.add(transBean.getField("TRA_METHOD").getFormValue());
				traIdList.add(transBean.getField("TRA_ID").getFormValue());
				traAmountList.add(transBean.getField("TRA_AMOUNT").getFormValue());
				traNoteList.add(transBean.getField("TRA_NOTE").getFormValue());
				traRecIdList.add(transBean.getField("TRA_RECEIPT_ID").getFormValue());
				traRemark1List.add(transBean.getField("TRA_REMARK1").getFormValue());
				traRemark2List.add(transBean.getField("TRA_REMARK2").getFormValue());
				traRemark3List.add(transBean.getField("TRA_REMARK3").getFormValue());
				traStatusList.add(transBean.getField("TRA_STATUS").getFormValue());
/*				
				if(transBean.getField("TRA_AMOUNT").getFormValue().length()>0) {
					accBal = DataTypeUtil.beanAmt2FormAmt((new BigDecimal(accBal)).add((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()), false);
				}
*/	
			}
			
			setTraDate(traDateList.toArray(new String[0]));
			setTraName(traNameList.toArray(new String[0]));
			setTraMethod(traMethodList.toArray(new String[0]));
			setTraId(traIdList.toArray(new String[0]));
			setTraAmount(traAmountList.toArray(new String[0]));
			setTraNote(traNoteList.toArray(new String[0]));
			setTraRecId(traRecIdList.toArray(new String[0]));
			setTraRemark1(traRemark1List.toArray(new String[0]));
			setTraRemark2(traRemark2List.toArray(new String[0]));
			setTraRemark3(traRemark3List.toArray(new String[0]));
			setTraStatus(traStatusList.toArray(new String[0]));
			
			
			ArrayList<String> cperIdList = new ArrayList<String>();
			ArrayList<String> cperItemIdList = new ArrayList<String>();
			ArrayList<String> cperItemNameList = new ArrayList<String>();
			ArrayList<String> cperItemCatIdList = new ArrayList<String>();
			ArrayList<String> cperItemCatNameList = new ArrayList<String>();
			ArrayList<String> cperNatureList = new ArrayList<String>();
			ArrayList<String> cperQuantityList = new ArrayList<String>();
			ArrayList<String> cperUnitPriceList = new ArrayList<String>();
			ArrayList<String> cperAmountList = new ArrayList<String>();
			ArrayList<String> cperStartDateList = new ArrayList<String>();
			ArrayList<String> cperEndDateList = new ArrayList<String>();
			ArrayList<String> cperPayStartDateList = new ArrayList<String>();
			ArrayList<String> cperPayEndDateList = new ArrayList<String>();
			ArrayList<String> cperPayAmountList = new ArrayList<String>();
			ArrayList<String> cperCurrPayDateList = new ArrayList<String>();
			ArrayList<String> cperRemarkList = new ArrayList<String>();

			ArrayList<String> corgIdList = new ArrayList<String>();
			ArrayList<String> corgItemIdList = new ArrayList<String>();
			ArrayList<String> corgItemNameList = new ArrayList<String>();
			ArrayList<String> corgItemCatIdList = new ArrayList<String>();
			ArrayList<String> corgItemCatNameList = new ArrayList<String>();
			ArrayList<String> corgNatureList = new ArrayList<String>();
			ArrayList<String> corgQuantityList = new ArrayList<String>();
			ArrayList<String> corgUnitPriceList = new ArrayList<String>();
			ArrayList<String> corgAmountList = new ArrayList<String>();
			ArrayList<String> corgStartDateList = new ArrayList<String>();
			ArrayList<String> corgEndDateList = new ArrayList<String>();
			ArrayList<String> corgPayStartDateList = new ArrayList<String>();
			ArrayList<String> corgPayEndDateList = new ArrayList<String>();
			ArrayList<String> corgPayAmountList = new ArrayList<String>();
			ArrayList<String> corgCurrPayDateList = new ArrayList<String>();
			ArrayList<String> corgRemarkList = new ArrayList<String>();
			
			
			
			accBal = patGrpBean.getAccBalBean().getField("ACC_BALANCE").getFormValue();
//			accLastBal = (BigDecimal)patGrpBean.getAccBalBean().getField("ACC_LAST_BALANCE").getValue();
			accDeposit = patGrpBean.getAccBalBean().getField("ACC_DEPOSIT").getFormValue();
			
			stmtBal = "0";
/*
			if(accLastBal.intValue()<0) {
				OrgBean orgBean = userBean.getOrgBean();
				BigDecimal charge = (BigDecimal)orgBean.getField("ORG_CHARGE").getValue();
				BigDecimal intRate = (BigDecimal)orgBean.getField("ORG_INT_RATE").getValue();
				
			}
*/			

			boolean payNextMonth = false;
			Calendar calendar = Calendar.getInstance();
			java.util.Date currDate = new java.util.Date(calendar.getTime().getTime());
			DateFormat dayFormat = new SimpleDateFormat("dd");
			String cutoffDay = dayFormat.format(currDate);
			if(cutoffDay.compareTo("20")>=0) {
				payNextMonth = true;
			}
			
			
			for(int i=0;i<patGrpBean.getCperBeanList().size();i++) {
				CperBean cperBean = patGrpBean.getCperBeanList().get(i);
				
				java.util.Date itemStartDate = null;
				if(cperBean.getField("CHP_START_DATE").getValue() != null)
					itemStartDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_START_DATE").getValue()).getTime());
				java.util.Date itemEndDate = null;
				if(cperBean.getField("CHP_END_DATE").getValue() != null)
					itemEndDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_END_DATE").getValue()).getTime());
				java.util.Date currPayDate = null;
				if(cperBean.getField("CHP_CURRENT_PAY_DATE").getValue() != null)
					currPayDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_CURRENT_PAY_DATE").getValue()).getTime());
				
				java.util.Date startDate = null;
				java.util.Date endDate = null;
				
				Calendar c = Calendar.getInstance();
				Calendar c1 = Calendar.getInstance();
				if(cperBean.getField("CHP_NATURE").getFormValue().equals("M")) {
					if(currPayDate !=null) {
						
						c.setTime(currPayDate);
						c.add(Calendar.DATE, 1);
						startDate = c.getTime();
					}else {
						startDate = itemStartDate;
					}
					
					if(itemEndDate!= null && currDate.getTime() > itemEndDate.getTime())
						c.setTime(itemEndDate);
					else if(payNextMonth) {
						c.setTime(currDate);
						c.add(Calendar.MONTH, 1);
					}else
						c.setTime(currDate);
					
					c1.setTime(startDate);

					
					while(c.get(Calendar.YEAR) > c1.get(Calendar.YEAR) || (c.get(Calendar.YEAR) == c1.get(Calendar.YEAR) && c.get(Calendar.MONTH) >= c1.get(Calendar.MONTH))) {
						startDate = c1.getTime();
						c1.set(Calendar.DATE, c1.getActualMaximum(Calendar.DATE));
						endDate = c1.getTime();
						if(itemEndDate!= null && endDate.getTime() > itemEndDate.getTime())
							endDate = itemEndDate;
						
						cperIdList.add(cperBean.getField("CHP_ID").getFormValue());
						cperItemIdList.add(cperBean.getField("CHI_ID").getFormValue());
						cperItemNameList.add(cperBean.getField("CHI_NAME").getFormValue());
						cperItemCatIdList.add(cperBean.getField("CHC_ID").getFormValue());
						cperItemCatNameList.add(cperBean.getField("CHC_NAME").getFormValue());
						cperNatureList.add(cperBean.getField("CHP_NATURE").getFormValue());
						cperQuantityList.add(cperBean.getField("CHP_QUANTITY").getFormValue());
						cperUnitPriceList.add(cperBean.getField("CHP_UNIT_PRICE").getFormValue());
						cperCurrPayDateList.add(cperBean.getField("CHP_CURRENT_PAY_DATE").getFormValue());
						cperAmountList.add(cperBean.getField("CHP_AMOUNT").getFormValue());
						cperStartDateList.add(cperBean.getField("CHP_START_DATE").getFormValue());
						cperEndDateList.add(cperBean.getField("CHP_END_DATE").getFormValue());
						cperCurrPayDateList.add(cperBean.getField("CHP_CURRENT_PAY_DATE").getFormValue());
						cperRemarkList.add(cperBean.getField("CHP_REMARK").getFormValue());
						
						cperPayStartDateList.add(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						cperPayEndDateList.add(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						
						long daysOfTheMonth = c1.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						cperPayAmountList.add(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)cperBean.getField("CHP_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));

						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(cperPayAmountList.get(cperPayAmountList.size()-1))));
						
						c1.add(Calendar.DATE, 1);
						
						
					}
					
				}else {

					cperIdList.add(cperBean.getField("CHP_ID").getFormValue());
					cperItemIdList.add(cperBean.getField("CHI_ID").getFormValue());
					cperItemNameList.add(cperBean.getField("CHI_NAME").getFormValue());
					cperItemCatIdList.add(cperBean.getField("CHC_ID").getFormValue());
					cperItemCatNameList.add(cperBean.getField("CHC_NAME").getFormValue());
					cperNatureList.add(cperBean.getField("CHP_NATURE").getFormValue());
					cperQuantityList.add(cperBean.getField("CHP_QUANTITY").getFormValue());
					cperUnitPriceList.add(cperBean.getField("CHP_UNIT_PRICE").getFormValue());
					cperAmountList.add(cperBean.getField("CHP_AMOUNT").getFormValue());
					cperStartDateList.add(cperBean.getField("CHP_START_DATE").getFormValue());
					cperEndDateList.add(cperBean.getField("CHP_END_DATE").getFormValue());
					cperCurrPayDateList.add(cperBean.getField("CHP_CURRENT_PAY_DATE").getFormValue());
					cperRemarkList.add(cperBean.getField("CHP_REMARK").getFormValue());
					
					cperPayStartDateList.add("");
					cperPayEndDateList.add("");
					cperPayAmountList.add(cperBean.getField("CHP_AMOUNT").getFormValue());
					stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(cperPayAmountList.get(cperPayAmountList.size()-1))));
					
				}
				
				
				
			}
			
			setCperId(cperIdList.toArray(new String[0]));
			setCperItemId(cperItemIdList.toArray(new String[0]));
			setCperItemName(cperItemNameList.toArray(new String[0]));
			setCperItemCatId(cperItemCatIdList.toArray(new String[0]));
			setCperItemCatName(cperItemCatNameList.toArray(new String[0]));
			setCperNature(cperNatureList.toArray(new String[0]));
			setCperQuantity(cperQuantityList.toArray(new String[0]));
			setCperUnitPrice(cperUnitPriceList.toArray(new String[0]));
			setCperAmount(cperAmountList.toArray(new String[0]));
			setCperStartDate(cperStartDateList.toArray(new String[0]));
			setCperEndDate(cperEndDateList.toArray(new String[0]));
			setCperPayStartDate(cperPayStartDateList.toArray(new String[0]));
			setCperPayEndDate(cperPayEndDateList.toArray(new String[0]));
			setCperPayAmount(cperPayAmountList.toArray(new String[0]));
			setCperCurrPayDate(cperCurrPayDateList.toArray(new String[0]));
			setCperRemark(cperRemarkList.toArray(new String[0]));

			
// Finish Cper			
			
			for(int i=0;i<patGrpBean.getCorgBeanList().size();i++) {
				CorgBean corgBean = patGrpBean.getCorgBeanList().get(i);
				
				java.util.Date itemStartDate = null;
				if(corgBean.getField("CHO_START_DATE").getValue() != null)
					itemStartDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_START_DATE").getValue()).getTime());
				java.util.Date itemEndDate = null;
				if(corgBean.getField("CHO_END_DATE").getValue() != null)
					itemEndDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_END_DATE").getValue()).getTime());
				java.util.Date currPayDate = null;
				if(corgBean.getField("CHO_CURRENT_PAY_DATE").getValue() != null)
					currPayDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_CURRENT_PAY_DATE").getValue()).getTime());
				
				java.util.Date startDate = null;
				java.util.Date endDate = null;
				
				Calendar c = Calendar.getInstance();
				Calendar c1 = Calendar.getInstance();
				if(corgBean.getField("CHO_NATURE").getFormValue().equals("M")) {
					if(currPayDate !=null) {
						
						c.setTime(currPayDate);
						c.add(Calendar.DATE, 1);
						startDate = c.getTime();
					}else {
						startDate = itemStartDate;
					}
					
					if(itemEndDate!= null && currDate.getTime() > itemEndDate.getTime())
						c.setTime(itemEndDate);
					else if(payNextMonth) {
						c.setTime(currDate);
						c.add(Calendar.MONTH, 1);
					}else
						c.setTime(currDate);
					
					c1.setTime(startDate);

					
					while(c.get(Calendar.YEAR) > c1.get(Calendar.YEAR) || (c.get(Calendar.YEAR) == c1.get(Calendar.YEAR) && c.get(Calendar.MONTH) >= c1.get(Calendar.MONTH))) {
						startDate = c1.getTime();
						c1.set(Calendar.DATE, c1.getActualMaximum(Calendar.DATE));
						endDate = c1.getTime();
						if(itemEndDate!= null && endDate.getTime() > itemEndDate.getTime())
							endDate = itemEndDate;
						
						corgIdList.add(corgBean.getField("CHO_ID").getFormValue());
						corgItemIdList.add(corgBean.getField("CHI_ID").getFormValue());
						corgItemNameList.add(corgBean.getField("CHI_NAME").getFormValue());
						corgItemCatIdList.add(corgBean.getField("CHC_ID").getFormValue());
						corgItemCatNameList.add(corgBean.getField("CHC_NAME").getFormValue());
						corgNatureList.add(corgBean.getField("CHO_NATURE").getFormValue());
						corgQuantityList.add(corgBean.getField("CHO_QUANTITY").getFormValue());
						corgUnitPriceList.add(corgBean.getField("CHO_UNIT_PRICE").getFormValue());
						corgAmountList.add(corgBean.getField("CHO_AMOUNT").getFormValue());
						corgStartDateList.add(corgBean.getField("CHO_START_DATE").getFormValue());
						corgEndDateList.add(corgBean.getField("CHO_END_DATE").getFormValue());
						corgCurrPayDateList.add(corgBean.getField("CHO_CURRENT_PAY_DATE").getFormValue());
						corgRemarkList.add(corgBean.getField("CHO_REMARK").getFormValue());
						
						corgPayStartDateList.add(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						corgPayEndDateList.add(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						
						long daysOfTheMonth = c1.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						corgPayAmountList.add(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)corgBean.getField("CHO_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));

						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(corgPayAmountList.get(corgPayAmountList.size()-1))));
						
						c1.add(Calendar.DATE, 1);
						
						
					}
					
				}else {


					corgIdList.add(corgBean.getField("CHO_ID").getFormValue());
					corgItemIdList.add(corgBean.getField("CHI_ID").getFormValue());
					corgItemNameList.add(corgBean.getField("CHI_NAME").getFormValue());
					corgItemCatIdList.add(corgBean.getField("CHC_ID").getFormValue());
					corgItemCatNameList.add(corgBean.getField("CHC_NAME").getFormValue());
					corgNatureList.add(corgBean.getField("CHO_NATURE").getFormValue());
					corgQuantityList.add(corgBean.getField("CHO_QUANTITY").getFormValue());
					corgUnitPriceList.add(corgBean.getField("CHO_UNIT_PRICE").getFormValue());
					corgCurrPayDateList.add(corgBean.getField("CHO_CURRENT_PAY_DATE").getFormValue());
					corgAmountList.add(corgBean.getField("CHO_AMOUNT").getFormValue());
					corgStartDateList.add(corgBean.getField("CHO_START_DATE").getFormValue());
					corgEndDateList.add(corgBean.getField("CHO_END_DATE").getFormValue());
					corgCurrPayDateList.add(corgBean.getField("CHO_CURRENT_PAY_DATE").getFormValue());
					corgRemarkList.add(corgBean.getField("CHO_REMARK").getFormValue());
					
					corgPayStartDateList.add("");
					corgPayEndDateList.add("");
					corgPayAmountList.add(corgBean.getField("CHO_AMOUNT").getFormValue());
					stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(corgPayAmountList.get(corgPayAmountList.size()-1))));
					
				}
				
				
				
			}				
				
			
		setCorgId(corgIdList.toArray(new String[0]));
		setCorgItemId(corgItemIdList.toArray(new String[0]));
		setCorgItemName(corgItemNameList.toArray(new String[0]));
		setCorgItemCatId(corgItemCatIdList.toArray(new String[0]));
		setCorgItemCatName(corgItemCatNameList.toArray(new String[0]));
		setCorgNature(corgNatureList.toArray(new String[0]));
		setCorgQuantity(corgQuantityList.toArray(new String[0]));
		setCorgUnitPrice(corgUnitPriceList.toArray(new String[0]));
		setCorgAmount(corgAmountList.toArray(new String[0]));
		setCorgStartDate(corgStartDateList.toArray(new String[0]));
		setCorgEndDate(corgEndDateList.toArray(new String[0]));
		setCorgPayStartDate(corgPayStartDateList.toArray(new String[0]));
		setCorgPayEndDate(corgPayEndDateList.toArray(new String[0]));
		setCorgPayAmount(corgPayAmountList.toArray(new String[0]));
		setCorgCurrPayDate(corgCurrPayDateList.toArray(new String[0]));
		setCorgRemark(corgRemarkList.toArray(new String[0]));
		
		

			
			
		}else {
			setTraDate(new String[] {""});
			setTraName(new String[] {""});
			setTraMethod(new String[] {""});
			setTraId(new String[] {""});
			setTraAmount(new String[] {""});
			setTraNote(new String[] {""});
			setTraRecId(new String[] {""});
			setTraRemark1(new String[] {""});
			setTraRemark2(new String[] {""});
			setTraRemark3(new String[] {""});
			setTraStatus(new String[] {""});
			
			setCperId(new String[0]);
			setCperItemId(new String[0]);
			setCperItemName(new String[0]);
			setCperItemCatId(new String[0]);
			setCperItemCatName(new String[0]);
			setCperNature(new String[0]);
			setCperQuantity(new String[0]);
			setCperUnitPrice(new String[0]);
			setCperAmount(new String[0]);
			setCperPayStartDate(new String[0]);
			setCperPayEndDate(new String[0]);
			setCperStartDate(new String[0]);
			setCperEndDate(new String[0]);
			setCperPayAmount(new String[0]);
			setCperCurrPayDate(new String[0]);
			setCperRemark(new String[0]);			

			setCorgId(new String[0]);
			setCorgItemId(new String[0]);
			setCorgItemName(new String[0]);
			setCorgItemCatId(new String[0]);
			setCorgItemCatName(new String[0]);
			setCorgNature(new String[0]);
			setCorgQuantity(new String[0]);
			setCorgUnitPrice(new String[0]);
			setCorgAmount(new String[0]);
			setCorgPayStartDate(new String[0]);
			setCorgPayEndDate(new String[0]);
			setCorgPayAmount(new String[0]);
			setCorgStartDate(new String[0]);
			setCorgEndDate(new String[0]);
			setCorgCurrPayDate(new String[0]);
			setCorgRemark(new String[0]);			
			
		}

		
		if(patGrpBean.getLivBeanList().size()>0) {
			setLivId(patGrpBean.getLivBeanList().get(0).getLivId());
			setLivType(patGrpBean.getLivBeanList().get(0).getField("LIV_TYPE").getFormValue());
			setLivExitReason(patGrpBean.getLivBeanList().get(0).getField("LIV_EXIT_REASON").getFormValue());
			setLivExitRemark(patGrpBean.getLivBeanList().get(0).getField("LIV_EXIT_REMARK").getFormValue());
			setLivStartDate(patGrpBean.getLivBeanList().get(0).getField("LIV_START_DATE").getFormValue());
			setLivEndDate(patGrpBean.getLivBeanList().get(0).getField("LIV_END_DATE").getFormValue());
			setLivLivingFee(patGrpBean.getLivBeanList().get(0).getField("LIV_LIVING_FEE").getFormValue());
			setLivNursingFee(patGrpBean.getLivBeanList().get(0).getField("LIV_NURSING_FEE").getFormValue());
			setLivStatus(patGrpBean.getLivBeanList().get(0).getField("LIV_STATUS").getFormValue());
			setLivZoneId(patGrpBean.getLivBeanList().get(0).getBedBean().getZoneId());
			setLivBedId(patGrpBean.getLivBeanList().get(0).getBedBean().getBedId());
			setBedFullName(patGrpBean.getLivBeanList().get(0).getBedBean().getBedFullName());
		}
		
		setPatId(patGrpBean.getPatId());
		setPerId(patGrpBean.getPerId());
		setPerChiName(patGrpBean.getField("PER_CHI_NAME").getFormValue());
		setPerEngName(patGrpBean.getField("PER_ENG_NAME").getFormValue());
		setPerHKID(patGrpBean.getField("PER_HKID").getFormValue());
		setPerGender(patGrpBean.getField("PER_GENDER").getFormValue());
		setPerImageLink(patGrpBean.getField("PER_IMAGE_LINK").getFormValue());
		setPerNBirth(patGrpBean.getField("PER_NBIRTH").getFormValue());
		setPerLBirth(patGrpBean.getField("PER_LBIRTH").getFormValue());
		setPerTel(patGrpBean.getField("PER_TEL").getFormValue());
		setPerEmail(patGrpBean.getField("PER_EMAIL").getFormValue());
		setPerDesc(patGrpBean.getField("PER_DESC").getFormValue());
		setPerLDSRef(patGrpBean.getField("PER_LDS_REF").getFormValue());
		setPerLDSResult(patGrpBean.getField("PER_LDS_RESULT").getFormValue());
		setPerLDSDate(patGrpBean.getField("PER_LDS_DATE").getFormValue());
		setPerAss1(patGrpBean.getField("PER_ASS1").getFormValue());
		setPerAss2(patGrpBean.getField("PER_ASS2").getFormValue());
		setPerAss2Oth(patGrpBean.getField("PER_ASS2_OTH").getFormValue());
		setPerAss3(patGrpBean.getField("PER_ASS3").getFormValue());
		setPerAss3Oth(patGrpBean.getField("PER_ASS3_OTH").getFormValue());
		setPerAss4(patGrpBean.getField("PER_ASS4").getFormValue());
		setPerReferal(patGrpBean.getField("PER_REFERAL").getFormValue());
		setPerReferalOth(patGrpBean.getField("PER_REFERAL_OTH").getFormValue());
		setPerBankId(patGrpBean.getField("BAN_ID").getFormValue());
		setPerBankAccNo(patGrpBean.getField("PER_BANK_ACC_NO").getFormValue());
		setPerBankAccName(patGrpBean.getField("PER_BANK_ACC_NAME").getFormValue());
		
		return SUCCESS;
	}
	
	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public String[] getPcoChiName() {
		return pcoChiName;
	}

	public void setPcoChiName(String[] pcoChiName) {
		this.pcoChiName = pcoChiName;
	}

	public String[] getPcoRel() {
		return pcoRel;
	}

	public void setPcoRel(String[] pcoRel) {
		this.pcoRel = pcoRel;
	}

	public String[] getPcoTel() {
		return pcoTel;
	}

	public void setPcoTel(String[] pcoTel) {
		this.pcoTel = pcoTel;
	}

	public String[] getPcoSeq() {
		return pcoSeq;
	}

	public void setPcoSeq(String[] pcoSeq) {
		this.pcoSeq = pcoSeq;
	}

	
	public String getLivId() {
		return livId;
	}

	public void setLivId(String livId) {
		this.livId = livId;
	}

	public String getPerChiName() {
		return perChiName;
	}

	public void setPerChiName(String perChiName) {
		this.perChiName = perChiName;
	}

	public String getPerEngName() {
		return perEngName;
	}

	public void setPerEngName(String perEngName) {
		this.perEngName = perEngName;
	}

	public String getPerHKID() {
		return perHKID;
	}

	public void setPerHKID(String perHKID) {
		this.perHKID = perHKID;
	}

	public String getPerGender() {
		return perGender;
	}

	public void setPerGender(String perGender) {
		this.perGender = perGender;
	}

	public String getPerNBirth() {
		return perNBirth;
	}

	public void setPerNBirth(String perNBirth) {
		this.perNBirth = perNBirth;
	}

	public String getPerLBirth() {
		return perLBirth;
	}

	public void setPerLBirth(String perLBirth) {
		this.perLBirth = perLBirth;
	}

	public String getPerTel() {
		return perTel;
	}

	public void setPerTel(String perTel) {
		this.perTel = perTel;
	}

	public String getPerEmail() {
		return perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerDesc() {
		return perDesc;
	}

	public void setPerDesc(String perDesc) {
		this.perDesc = perDesc;
	}

	public String getLivZoneId() {
		return livZoneId;
	}

	public void setLivZoneId(String livZoneId) {
		this.livZoneId = livZoneId;
	}

	public String getLivBedId() {
		return livBedId;
	}

	public void setLivBedId(String livBedId) {
		this.livBedId = livBedId;
	}

	public String getBedFullName() {
		return bedFullName;
	}

	public void setBedFullName(String bedFullName) {
		this.bedFullName = bedFullName;
	}

	public String getLivType() {
		return livType;
	}

	public void setLivType(String livType) {
		this.livType = livType;
	}

	public String getLivExitReason() {
		return livExitReason;
	}

	public void setLivExitReason(String livExitReason) {
		this.livExitReason = livExitReason;
	}

	public String getLivExitRemark() {
		return livExitRemark;
	}

	public void setLivExitRemark(String livExitRemark) {
		this.livExitRemark = livExitRemark;
	}

	public String getLivStartDate() {
		return livStartDate;
	}

	public void setLivStartDate(String livStartDate) {
		this.livStartDate = livStartDate;
	}

	public String getLivEndDate() {
		return livEndDate;
	}

	public void setLivEndDate(String livEndDate) {
		this.livEndDate = livEndDate;
	}

	public String getLivLivingFee() {
		return livLivingFee;
	}

	public void setLivLivingFee(String livLivingFee) {
		this.livLivingFee = livLivingFee;
	}

	public String getLivNursingFee() {
		return livNursingFee;
	}

	public void setLivNursingFee(String livNursingFee) {
		this.livNursingFee = livNursingFee;
	}

	public String getPerLDSRef() {
		return perLDSRef;
	}

	public void setPerLDSRef(String perLDSRef) {
		this.perLDSRef = perLDSRef;
	}

	public String getPerLDSResult() {
		return perLDSResult;
	}

	public void setPerLDSResult(String perLDSResult) {
		this.perLDSResult = perLDSResult;
	}

	public String getPerLDSDate() {
		return perLDSDate;
	}

	public void setPerLDSDate(String perLDSDate) {
		this.perLDSDate = perLDSDate;
	}

	public String getPerAss1() {
		return perAss1;
	}

	public void setPerAss1(String perAss1) {
		this.perAss1 = perAss1;
	}

	public String getPerAss2() {
		return perAss2;
	}

	public void setPerAss2(String perAss2) {
		this.perAss2 = perAss2;
	}

	public String getPerAss2Oth() {
		return perAss2Oth;
	}

	public void setPerAss2Oth(String perAss2Oth) {
		this.perAss2Oth = perAss2Oth;
	}

	public String getPerAss3() {
		return perAss3;
	}

	public void setPerAss3(String perAss3) {
		this.perAss3 = perAss3;
	}

	public String getPerAss3Oth() {
		return perAss3Oth;
	}

	public void setPerAss3Oth(String perAss3Oth) {
		this.perAss3Oth = perAss3Oth;
	}

	public String getPerAss4() {
		return perAss4;
	}

	public void setPerAss4(String perAss4) {
		this.perAss4 = perAss4;
	}

	public String getPerReferal() {
		return perReferal;
	}

	public void setPerReferal(String perReferal) {
		this.perReferal = perReferal;
	}

	public String getPerReferalOth() {
		return perReferalOth;
	}

	public void setPerReferalOth(String perReferalOth) {
		this.perReferalOth = perReferalOth;
	}

	public String getPerBankId() {
		return perBankId;
	}

	public void setPerBankId(String perBankId) {
		this.perBankId = perBankId;
	}

	public String getPerBankAccNo() {
		return perBankAccNo;
	}

	public void setPerBankAccNo(String perBankAccNo) {
		this.perBankAccNo = perBankAccNo;
	}

	public String getPerBankAccName() {
		return perBankAccName;
	}

	public void setPerBankAccName(String perBankAccName) {
		this.perBankAccName = perBankAccName;
	}

	public String getPerImageLink() {
		return perImageLink;
	}

	public void setPerImageLink(String perImageLink) {
		this.perImageLink = perImageLink;
	}

	public String getPatId() {
		return patId;
	}

	public void setPatId(String patId) {
		this.patId = patId;
	}

	public String getPerId() {
		return perId;
	}

	public void setPerId(String perId) {
		this.perId = perId;
	}

	public String getLivStatus() {
		return livStatus;
	}

	public void setLivStatus(String livStatus) {
		this.livStatus = livStatus;
	}

	public String[] getPcoEmail() {
		return pcoEmail;
	}

	public void setPcoEmail(String[] pcoEmail) {
		this.pcoEmail = pcoEmail;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	public String[] getTraDate() {
		return traDate;
	}

	public void setTraDate(String[] traDate) {
		this.traDate = traDate;
	}

	public String[] getTraName() {
		return traName;
	}

	public void setTraName(String[] traName) {
		this.traName = traName;
	}

	public String[] getTraMethod() {
		return traMethod;
	}

	public void setTraMethod(String[] traMethod) {
		this.traMethod = traMethod;
	}

	public String[] getTraId() {
		return traId;
	}

	public void setTraId(String[] traId) {
		this.traId = traId;
	}

	public String[] getTraAmount() {
		return traAmount;
	}

	public void setTraAmount(String[] traAmount) {
		this.traAmount = traAmount;
	}

	public String[] getTraNote() {
		return traNote;
	}

	public void setTraNote(String[] traNote) {
		this.traNote = traNote;
	}

	public String[] getTraRecId() {
		return traRecId;
	}

	public void setTraRecId(String[] traRecId) {
		this.traRecId = traRecId;
	}

	public String[] getTraRemark1() {
		return traRemark1;
	}

	public void setTraRemark1(String[] traRemark1) {
		this.traRemark1 = traRemark1;
	}

	public String[] getTraRemark2() {
		return traRemark2;
	}

	public void setTraRemark2(String[] traRemark2) {
		this.traRemark2 = traRemark2;
	}

	public String[] getTraRemark3() {
		return traRemark3;
	}

	public void setTraRemark3(String[] traRemark3) {
		this.traRemark3 = traRemark3;
	}

	public BigDecimal getAccLastBal() {
		return accLastBal;
	}

	public void setAccLastBal(BigDecimal accLastBal) {
		this.accLastBal = accLastBal;
	}

	public String[] getTraStatus() {
		return traStatus;
	}

	public void setTraStatus(String[] traStatus) {
		this.traStatus = traStatus;
	}

	public String getAccBal() {
		return accBal;
	}

	public void setAccBal(String accBal) {
		this.accBal = accBal;
	}

	public String[] getCperId() {
		return cperId;
	}

	public void setCperId(String[] cperId) {
		this.cperId = cperId;
	}

	public String[] getCperItemId() {
		return cperItemId;
	}

	public void setCperItemId(String[] cperItemId) {
		this.cperItemId = cperItemId;
	}

	public String[] getCperItemName() {
		return cperItemName;
	}

	public void setCperItemName(String[] cperItemName) {
		this.cperItemName = cperItemName;
	}

	public String[] getCperItemCatId() {
		return cperItemCatId;
	}

	public void setCperItemCatId(String[] cperItemCatId) {
		this.cperItemCatId = cperItemCatId;
	}

	public String[] getCperItemCatName() {
		return cperItemCatName;
	}

	public void setCperItemCatName(String[] cperItemCatName) {
		this.cperItemCatName = cperItemCatName;
	}

	public String[] getCperNature() {
		return cperNature;
	}

	public void setCperNature(String[] cperNature) {
		this.cperNature = cperNature;
	}

	public String[] getCperQuantity() {
		return cperQuantity;
	}

	public void setCperQuantity(String[] cperQuantity) {
		this.cperQuantity = cperQuantity;
	}

	public String[] getCperUnitPrice() {
		return cperUnitPrice;
	}

	public void setCperUnitPrice(String[] cperUnitPrice) {
		this.cperUnitPrice = cperUnitPrice;
	}

	public String[] getCperAmount() {
		return cperAmount;
	}

	public void setCperAmount(String[] cperAmount) {
		this.cperAmount = cperAmount;
	}

	public String[] getCperStartDate() {
		return cperStartDate;
	}

	public void setCperStartDate(String[] cperStartDate) {
		this.cperStartDate = cperStartDate;
	}

	public String[] getCperEndDate() {
		return cperEndDate;
	}

	public void setCperEndDate(String[] cperEndDate) {
		this.cperEndDate = cperEndDate;
	}

	public String[] getCperCurrPayDate() {
		return cperCurrPayDate;
	}

	public String[] getCperPayStartDate() {
		return cperPayStartDate;
	}

	public void setCperPayStartDate(String[] cperPayStartDate) {
		this.cperPayStartDate = cperPayStartDate;
	}

	public String[] getCperPayEndDate() {
		return cperPayEndDate;
	}

	public void setCperPayEndDate(String[] cperPayEndDate) {
		this.cperPayEndDate = cperPayEndDate;
	}

	public void setCperCurrPayDate(String[] cperCurrPayDate) {
		this.cperCurrPayDate = cperCurrPayDate;
	}

	public String[] getCperPayAmount() {
		return cperPayAmount;
	}

	public void setCperPayAmount(String[] cperPayAmount) {
		this.cperPayAmount = cperPayAmount;
	}

	public String[] getCperRemark() {
		return cperRemark;
	}

	public void setCperRemark(String[] cperRemark) {
		this.cperRemark = cperRemark;
	}

	public String[] getCorgId() {
		return corgId;
	}

	public void setCorgId(String[] corgId) {
		this.corgId = corgId;
	}

	public String[] getCorgItemId() {
		return corgItemId;
	}

	public void setCorgItemId(String[] corgItemId) {
		this.corgItemId = corgItemId;
	}

	public String[] getCorgItemName() {
		return corgItemName;
	}

	public void setCorgItemName(String[] corgItemName) {
		this.corgItemName = corgItemName;
	}

	public String[] getCorgItemCatId() {
		return corgItemCatId;
	}

	public void setCorgItemCatId(String[] corgItemCatId) {
		this.corgItemCatId = corgItemCatId;
	}

	public String[] getCorgItemCatName() {
		return corgItemCatName;
	}

	public void setCorgItemCatName(String[] corgItemCatName) {
		this.corgItemCatName = corgItemCatName;
	}

	public String[] getCorgNature() {
		return corgNature;
	}

	public void setCorgNature(String[] corgNature) {
		this.corgNature = corgNature;
	}

	public String[] getCorgQuantity() {
		return corgQuantity;
	}

	public void setCorgQuantity(String[] corgQuantity) {
		this.corgQuantity = corgQuantity;
	}

	public String[] getCorgUnitPrice() {
		return corgUnitPrice;
	}

	public void setCorgUnitPrice(String[] corgUnitPrice) {
		this.corgUnitPrice = corgUnitPrice;
	}

	public String[] getCorgAmount() {
		return corgAmount;
	}

	public void setCorgAmount(String[] corgAmount) {
		this.corgAmount = corgAmount;
	}

	public String[] getCorgStartDate() {
		return corgStartDate;
	}

	public void setCorgStartDate(String[] corgStartDate) {
		this.corgStartDate = corgStartDate;
	}

	public String[] getCorgEndDate() {
		return corgEndDate;
	}

	public void setCorgEndDate(String[] corgEndDate) {
		this.corgEndDate = corgEndDate;
	}

	public String[] getCorgCurrPayDate() {
		return corgCurrPayDate;
	}

	public void setCorgCurrPayDate(String[] corgCurrPayDate) {
		this.corgCurrPayDate = corgCurrPayDate;
	}

	public String[] getCorgPayStartDate() {
		return corgPayStartDate;
	}

	public void setCorgPayStartDate(String[] corgPayStartDate) {
		this.corgPayStartDate = corgPayStartDate;
	}

	public String[] getCorgPayEndDate() {
		return corgPayEndDate;
	}

	public void setCorgPayEndDate(String[] corgPayEndDate) {
		this.corgPayEndDate = corgPayEndDate;
	}

	public String[] getCorgPayAmount() {
		return corgPayAmount;
	}

	public void setCorgPayAmount(String[] corgPayAmount) {
		this.corgPayAmount = corgPayAmount;
	}


	
	public String[] getCorgRemark() {
		return corgRemark;
	}

	public void setCorgRemark(String[] corgRemark) {
		this.corgRemark = corgRemark;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public String getAccDeposit() {
		return accDeposit;
	}

	public void setAccDeposit(String accDeposit) {
		this.accDeposit = accDeposit;
	}

	public String getStmtBal() {
		return stmtBal;
	}

	public void setStmtBal(String stmtBal) {
		this.stmtBal = stmtBal;
	}

	
	
}
