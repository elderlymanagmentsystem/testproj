package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class PerBean extends BasicBean {
	
	private ArrayList<PcoBean> pcoBeanList = new ArrayList<PcoBean>();
	private ArrayList<QuoBean> quoBeanList = new ArrayList<QuoBean>();
	
	public PerBean() {
		for(int i=0; i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length;i++) {
			if(getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0])==null)
				fields.add(new Field(EmsDB.EM_PER_PERSONAL_PARTICULAR[i]));
		}
	}
	
	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	
	public PcoBean getPcoBean(String pcoPerId, String orgId){
		for(int i=0;i<pcoBeanList.size();i++) {
			if(pcoPerId != null && orgId != null && pcoPerId.equals(pcoBeanList.get(i).getPcoPerId()) && orgId.equals(pcoBeanList.get(i).getOrgId())){
				return pcoBeanList.get(i);
			}
		}
		return null;
	}	
	
	
	
	public ArrayList<PcoBean> getPcoBeanList(){
		return pcoBeanList;
	}
	
	public void setPcoBeanList(ArrayList<PcoBean> pcoBeanList) {
		this.pcoBeanList = pcoBeanList;
	}

	public void addPcoBeanList(PcoBean pcoBean) {
		pcoBeanList.add(pcoBean);
	}

	public QuoBean getQuoBean(String perId, String orgId){
		for(int i=0;i<quoBeanList.size();i++) {
			if(perId != null && orgId != null && perId.equals(quoBeanList.get(i).getPerId()) && orgId.equals(quoBeanList.get(i).getOrgId())){
				return quoBeanList.get(i);
			}
		}
		return null;
	}	
	
	
	
	public ArrayList<QuoBean> getQuoBeanList(){
		return quoBeanList;
	}
	
	public void setQuoBeanList(ArrayList<QuoBean> quoBeanList) {
		this.quoBeanList = quoBeanList;
	}

	public void addQuoBeanList(QuoBean quoBean) {
		quoBeanList.add(quoBean);
	}


}
