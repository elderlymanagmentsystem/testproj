package ems.action;

import java.util.ArrayList;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.PerBean;
import ems.bean.QuoGrpBean;
import ems.bean.PcoBean;
import ems.bean.UserBean;
import ems.module.QuoteModule;

public class AjaxPerAction extends ActionSupport implements SessionAware {
	private QuoGrpBean quoGrpBean;
	private int enqPerId;
	private Map<String, Object> session;
	private String perId = "";
	private String[] pcoChiName;
	private String[] pcoRel;
	private String[] pcoTel;
	private String[] pcoEmail;
	private String[] pcoSeq;
	private String quoId = "";
	private String quoType = "";
	private String quoStartDate = "";
	private String quoAmount = "";
	private String quoStatus = "";
	private String quoZoneId = "";
	private String quoBedId = "";
	private String bedFullName = "";
	private String perChiName = "";
	private String perEngName = "";
	private String perHKID = "";
	private String perGender = "";
	private String perNBirth = "";
	private String perLBirth = "";
	private String perTel = "";
	private String perEmail = "";
	private String perDesc = "";
	private String perImageLink = "";
	private String perLDSRef = "";
	private String perLDSResult = "";
	private String perLDSDate = "";
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		
		QuoteModule quoMod = new QuoteModule();
		if(quoGrpBean.getEnqPerId() != null && quoGrpBean.getEnqPerId().length()>0)
			quoMod.performEnqPerDetail(quoGrpBean, userBean);
		
		if(quoGrpBean.getPcoBeanList().size()>0) {
			ArrayList<String> pcoChiNameList = new ArrayList<String>();
			ArrayList<String> pcoTelList = new ArrayList<String>();
			ArrayList<String> pcoEmailList = new ArrayList<String>();
			ArrayList<String> pcoRelList = new ArrayList<String>();
			ArrayList<String> pcoSeqList = new ArrayList<String>();
			for(int i=0;i<quoGrpBean.getPcoBeanList().size();i++) {
				PcoBean pcoBean = quoGrpBean.getPcoBeanList().get(i);
				pcoChiNameList.add(pcoBean.getPerBean().getField("PER_CHI_NAME").getFormValue());
				pcoTelList.add(pcoBean.getPerBean().getField("PER_TEL").getFormValue());
				pcoEmailList.add(pcoBean.getPerBean().getField("PER_EMAIL").getFormValue());
				pcoRelList.add(pcoBean.getField("PCO_RELATION").getFormValue());
				pcoSeqList.add(pcoBean.getField("PCO_SEQ").getFormValue());
				setPcoChiName(pcoChiNameList.toArray(new String[0]));
				setPcoTel(pcoTelList.toArray(new String[0]));
				setPcoEmail(pcoEmailList.toArray(new String[0]));
				setPcoRel(pcoRelList.toArray(new String[0]));
				setPcoSeq(pcoSeqList.toArray(new String[0]));
				
			}
		}else {
			setPcoChiName(new String[] {""});
			setPcoTel(new String[] {""});
			setPcoEmail(new String[] {""});
			setPcoRel(new String[] {""});
			setPcoSeq(new String[] {""});
		}
		
		if(quoGrpBean.getQuoBeanList().size()>0) {
			setQuoId(quoGrpBean.getQuoBeanList().get(0).getQuoId());
			setQuoType(quoGrpBean.getQuoBeanList().get(0).getField("QUO_TYPE").getFormValue());
			setQuoStartDate(quoGrpBean.getQuoBeanList().get(0).getField("QUO_START_DATE").getFormValue());
			setQuoAmount(quoGrpBean.getQuoBeanList().get(0).getField("QUO_AMOUNT").getFormValue());
			setQuoStatus(quoGrpBean.getQuoBeanList().get(0).getField("QUO_STATUS").getFormValue());
			setQuoZoneId(quoGrpBean.getQuoBeanList().get(0).getBedBean().getZoneId());
			setQuoBedId(quoGrpBean.getQuoBeanList().get(0).getBedBean().getBedId());
			setBedFullName(quoGrpBean.getQuoBeanList().get(0).getBedBean().getBedFullName());
		}
		
		setPerId(quoGrpBean.getPerId());
		setPerChiName(quoGrpBean.getField("PER_CHI_NAME").getFormValue());
		setPerEngName(quoGrpBean.getField("PER_ENG_NAME").getFormValue());
		setPerHKID(quoGrpBean.getField("PER_HKID").getFormValue());
		setPerGender(quoGrpBean.getField("PER_GENDER").getFormValue());
		setPerImageLink(quoGrpBean.getField("PER_IMAGE_LINK").getFormValue());
		setPerNBirth(quoGrpBean.getField("PER_NBIRTH").getFormValue());
		setPerLBirth(quoGrpBean.getField("PER_LBIRTH").getFormValue());
		setPerTel(quoGrpBean.getField("PER_TEL").getFormValue());
		setPerEmail(quoGrpBean.getField("PER_EMAIL").getFormValue());
		setPerDesc(quoGrpBean.getField("PER_DESC").getFormValue());
		setPerLDSRef(quoGrpBean.getField("PER_LDS_REF").getFormValue());
		setPerLDSResult(quoGrpBean.getField("PER_LDS_RESULT").getFormValue());
		setPerLDSDate(quoGrpBean.getField("PER_LDS_DATE").getFormValue());
		
		return SUCCESS;
	}
	
	public QuoGrpBean getQuoGrpBean() {
		return quoGrpBean;
	}

	public void setQuoGrpBean(QuoGrpBean quoGrpBean) {
		this.quoGrpBean = quoGrpBean;
	}
    
	public String[] getPcoChiName() {
		return pcoChiName;
	}

	public void setPcoChiName(String[] pcoChiName) {
		this.pcoChiName = pcoChiName;
	}

	public String[] getPcoRel() {
		return pcoRel;
	}

	public void setPcoRel(String[] pcoRel) {
		this.pcoRel = pcoRel;
	}

	public String[] getPcoTel() {
		return pcoTel;
	}

	public void setPcoTel(String[] pcoTel) {
		this.pcoTel = pcoTel;
	}

	public String[] getPcoSeq() {
		return pcoSeq;
	}

	public void setPcoSeq(String[] pcoSeq) {
		this.pcoSeq = pcoSeq;
	}

	
	public String getQuoId() {
		return quoId;
	}

	public void setQuoId(String quoId) {
		this.quoId = quoId;
	}

	public String getPerChiName() {
		return perChiName;
	}

	public void setPerChiName(String perChiName) {
		this.perChiName = perChiName;
	}

	public String getPerEngName() {
		return perEngName;
	}

	public void setPerEngName(String perEngName) {
		this.perEngName = perEngName;
	}

	public String getPerHKID() {
		return perHKID;
	}

	public void setPerHKID(String perHKID) {
		this.perHKID = perHKID;
	}

	public String getPerGender() {
		return perGender;
	}

	public void setPerGender(String perGender) {
		this.perGender = perGender;
	}

	public String getPerNBirth() {
		return perNBirth;
	}

	public void setPerNBirth(String perNBirth) {
		this.perNBirth = perNBirth;
	}

	public String getPerLBirth() {
		return perLBirth;
	}

	public void setPerLBirth(String perLBirth) {
		this.perLBirth = perLBirth;
	}

	public String getPerTel() {
		return perTel;
	}

	public void setPerTel(String perTel) {
		this.perTel = perTel;
	}

	public String getPerEmail() {
		return perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerDesc() {
		return perDesc;
	}

	public void setPerDesc(String perDesc) {
		this.perDesc = perDesc;
	}

	public String getQuoZoneId() {
		return quoZoneId;
	}

	public void setQuoZoneId(String quoZoneId) {
		this.quoZoneId = quoZoneId;
	}

	public String getQuoBedId() {
		return quoBedId;
	}

	public void setQuoBedId(String quoBedId) {
		this.quoBedId = quoBedId;
	}

	public String getBedFullName() {
		return bedFullName;
	}

	public void setBedFullName(String bedFullName) {
		this.bedFullName = bedFullName;
	}

	public String getQuoType() {
		return quoType;
	}

	public void setQuoType(String quoType) {
		this.quoType = quoType;
	}

	public String getQuoStartDate() {
		return quoStartDate;
	}

	public void setQuoStartDate(String quoStartDate) {
		this.quoStartDate = quoStartDate;
	}

	public String getQuoAmount() {
		return quoAmount;
	}

	public void setQuoAmount(String quoAmount) {
		this.quoAmount = quoAmount;
	}

	public String getPerLDSRef() {
		return perLDSRef;
	}

	public void setPerLDSRef(String perLDSRef) {
		this.perLDSRef = perLDSRef;
	}

	public String getPerLDSResult() {
		return perLDSResult;
	}

	public void setPerLDSResult(String perLDSResult) {
		this.perLDSResult = perLDSResult;
	}

	public String getPerLDSDate() {
		return perLDSDate;
	}

	public void setPerLDSDate(String perLDSDate) {
		this.perLDSDate = perLDSDate;
	}

	public String getPerImageLink() {
		return perImageLink;
	}

	public void setPerImageLink(String perImageLink) {
		this.perImageLink = perImageLink;
	}

	public String getPerId() {
		return perId;
	}

	public void setPerId(String perId) {
		this.perId = perId;
	}

	public String getQuoStatus() {
		return quoStatus;
	}

	public void setQuoStatus(String quoStatus) {
		this.quoStatus = quoStatus;
	}

	public String[] getPcoEmail() {
		return pcoEmail;
	}

	public void setPcoEmail(String[] pcoEmail) {
		this.pcoEmail = pcoEmail;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	
	
}
