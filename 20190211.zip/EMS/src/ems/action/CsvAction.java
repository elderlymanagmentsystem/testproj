package ems.action;

import com.opensymphony.xwork2.ActionSupport;

import ems.util.DBUtil;
import ems.util.EmsCommonUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

public class CsvAction extends ActionSupport {
	private InputStream fileInputStream;
	private String funcId;
	private String flag;
	private String month;
	
	public String execute() throws Exception {
		if (month == null) {
			Calendar now = Calendar.getInstance();
			month = Integer.toString(now.get(Calendar.MONTH) + 1);
		}
		
		if ("Y".equals(flag)) {
			String sql = "select per.per_chi_name, pat.pat_id, stm.stm_id, stm.stm_date, stm.stm_amount, per.ban_id, per.per_bank_acc_name, per.per_bank_acc_no " + 
					"from EM_STM_STATEMENT stm, EM_PER_PERSONAL_PARTICULAR per, EM_PAT_PATIENT_INFO pat " + 
					"where stm.per_id = per.per_id " + 
					"and stm.org_id = per.org_id " + 
					"and stm.per_id = pat.per_id " +
					"and stm.org_id = pat.org_id " +
					"and month(stm.stm_date) = " + month +
					"order by stm.per_id, stm.stm_date ";
			
			byte[] UTF8_BOM = new byte[]{-17, -69, -65};
			String header = "院友姓名, 院友編號, 結單編號, 結單日期, 結單金額, 銀行代碼, 戶口名稱, 戶口號碼";
			Connection conn = DBUtil.getDataSource().getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			
			File file =new File(EmsCommonUtil.getRuntimePath() + "downloadfile.txt");
		    String encoding = "UTF-8";
			
			BufferedOutputStream bo = new BufferedOutputStream(new FileOutputStream(file));
			bo.write(UTF8_BOM);
			bo.write(header.getBytes(encoding));
			bo.write(System.getProperty("line.separator").getBytes(encoding));

			while(rs.next()){
				String perChiName = rs.getString("per_chi_name");
			    String patId = rs.getString("pat_id");
			    String stmId = rs.getString("stm_id");
			    String stmDate = rs.getString("stm_date");
			    String stmAmount = rs.getString("stm_amount");
			    String banId = rs.getString("ban_id");
			    String perBankAccName = rs.getString("per_bank_acc_name");
			    String perBankAccNo = rs.getString("per_bank_acc_no");
			    String line = perChiName + "," + patId + "," + stmId + "," +stmDate + "," +stmAmount + "," +banId + "," +perBankAccName +"," +perBankAccNo;
			    bo.write(line.getBytes(encoding));
			    bo.write(System.getProperty("line.separator").getBytes(encoding));
			}
			bo.close();
			
		    //assign file for struts to download
		    fileInputStream = new FileInputStream(new File(EmsCommonUtil.getRuntimePath() + "downloadfile.txt"));
			return SUCCESS;
		} else {
			return INPUT;
		}
	}
	
	public void validate() {
	}

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
}
