package ems.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.codec.Base64;

import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.ResGrpBean;
import ems.bean.StmtBean;
import ems.bean.TransBean;
import ems.db.OrgDB;

public class PDFUtil {
	private static ITextRenderer renderer = new ITextRenderer();
	private static String fontPath = EmsCommonUtil.getRuntimePath() + "font" + File.separator + "mingliu.ttf";
	private static String HTML_TAIL = "</body></html>";
	private static String HTML_HEAD = "<!DOCTYPE html><html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>"
			+ "<style>"
			+ " body { "
			+ "    font-family: MingLiU; "
			+ " } "
			+ "@page { margin: 12mm; "
			+ " @top-right { "
			+ "     font-family: MingLiU; "
			+ "     font-size: 12px; "
			+ "     vertical-align: text-top; "
			+ "     padding-top: 6mm; "
			+ "	    content: '頁 ' counter(page) '/' counter(pages);"
			+ " } "
			+ " @bottom-left { "
			+ " vertical-align: text-top; "
			+ "    font-family: MingLiU; "
			+ "    font-size: 12px; "
			+ "    white-space: pre-wrap;"
			+ "    content: '${orgChiName}$ ${orgEngName}$\\A地址: ${orgChiAddr}$'"
			+ " } "
			+ " @bottom-right { "
			+ "    font-family: MingLiU; "
			+ "    vertical-align: text-bottom; "
			+ "    white-space: pre-wrap;"
			+ "    font-size: 12px; "
			+ "    content: '\\A電話: ${orgTel}$ 傳真: ${orgFax}$'"
			+ " } "
			+ "} "
			+ "table {border-collapse: collapse;} "
			+ "table td{border: 1px solid black;} "
			+ "</style>"
			+ "</head><body>";
	
	public static boolean gen(String orgId, String path, String htmlContent) {
		OrgDB orgDB = new OrgDB();
		OrgBean accOrgBean = new OrgBean();
		accOrgBean.setOrgId(orgId);
		orgDB.getOrgBean(accOrgBean);
		
		String orgEngName = accOrgBean.getField("ORG_ENG_NAME").getFormValue();
		String orgChiName = accOrgBean.getField("ORG_CHI_NAME").getFormValue();
		String orgChiAddr = accOrgBean.getField("ORG_CHI_ADDR").getFormValue();
		String orgTel = accOrgBean.getField("ORG_TEL").getFormValue();
		String orgFax = accOrgBean.getField("ORG_FAX").getFormValue();
		return gen(orgChiName, orgEngName, orgChiAddr, orgTel, orgFax, path, htmlContent);
	}
	
	public static boolean gen(String orgChiName, String orgEngName, String orgChiAddr, String orgTel, String orgFax, String path, String htmlContent) {
		if (orgChiName == null) orgChiName = "";
		if (orgEngName == null) orgEngName = "";
		if (orgChiAddr == null) orgChiAddr = "";
		if (orgTel == null) orgTel = "";
		if (orgFax == null) orgFax = "";
		if (htmlContent == null) htmlContent = "";
		String htmlHead = HTML_HEAD.replace("${orgChiName}$", orgChiName).replace("${orgEngName}$", orgEngName).replace("${orgChiAddr}$", orgChiAddr).replace("${orgTel}$", orgTel).replace("${orgFax}$", orgFax);
		htmlHead = htmlHead.replaceAll("\\$\\{([^<]*)\\}\\$", ""); //replace all remaining {} field to empty string
		htmlContent = htmlContent.replaceAll("\\$\\{([^<]*)\\}\\$", ""); //replace all remaining {} field to empty string
		try
        {
			String projectPath ="";
			String runtimePath ="";
			String filename="";
			if (path != null) {
				path = path.replace("/",File.separator);
				projectPath = EmsCommonUtil.getProjPath()+path.substring(0,path.lastIndexOf(File.separator)+1);
				runtimePath = EmsCommonUtil.getRuntimePath()+path.substring(0,path.lastIndexOf(File.separator)+1);
				filename = path.substring(path.lastIndexOf(File.separator)+1,path.length());
			}
			(new File(projectPath)).mkdirs();
			(new File(runtimePath)).mkdirs();
			
			OutputStream os1 = new FileOutputStream(projectPath+filename);
			OutputStream os2 = new FileOutputStream(runtimePath+filename);
			renderer.getFontResolver().addFont(fontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.setDocumentFromString(htmlHead+htmlContent+HTML_TAIL);
			renderer.layout();
			renderer.createPDF(os1);
			os1.close();
			renderer.createPDF(os2);
			os2.close();
        }
        catch (Throwable t)
        {
            t.printStackTrace();
            return false;
        }
		return true;
    }
	
	public static String getImgTag(String path){
		return getImgTag(path, 0);
	}
	
	public static String getImgTag(String path, int height){
		FileInputStream fileInputStreamReader = null;
		try {
			File file = new File(EmsCommonUtil.getRuntimePath()+File.separator+path);
			fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int)file.length()];
			fileInputStreamReader.read(bytes);
			fileInputStreamReader.close();
			String temp = (height == 0) ? "' style='height: 100%; width: auto'/>" : "' style='height: " + height + "px; width: auto'/>" ;
			return "<img src='data:image/jpg;base64, " + new String(Base64.encodeBytes(bytes)) + temp ;
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
    }
	
	// --------template start------- //
	public static void genDownPaymentSlip(ResGrpBean resGrpBean) {
		TransBean transBean = resGrpBean.getTransBean();
		String perChiName = resGrpBean.getField("PER_CHI_NAME").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traReceiptId = transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traType = EmsCommonUtil.getTraTypeWording(transBean.getField("TRA_TYPE").getFormValue());
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>訂金收據</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traType}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>已付訂金總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String REMARKS_AND_STAMP = "<p>注意: 以上已付訂金將不會退回</p><br/><br/><br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${logo}$", getImgTag("file\\org" + resGrpBean.getOrgId() + "\\logo\\img1001.jpg",100)).replace("${perChiName}$", perChiName).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traType}$", traType).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		PDFUtil.gen(resGrpBean.getOrgId(), traPdfFile, headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP);
	}
	
	public static void genDepositeSlip(PatGrpBean patGrpBean) {
		TransBean transBean = patGrpBean.getTransBean();
		String perChiName = patGrpBean.getField("PER_CHI_NAME").getFormValue();
		String patId = patGrpBean.getField("PAT_ID").getFormValue();
		String traDate = transBean.getField("TRA_DATE").getFormValue();
		String traReceiptId = transBean.getField("TRA_RECEIPT_ID").getFormValue();
		String traType = EmsCommonUtil.getTraTypeWording(transBean.getField("TRA_TYPE").getFormValue());
		String traMethod = EmsCommonUtil.getTraMethodWording(transBean.getField("TRA_METHOD").getFormValue());
		String traNote = transBean.getField("TRA_NOTE").getFormValue();
		String traAmount = transBean.getField("TRA_AMOUNT").getFormValue();
		String traPdfFile = transBean.getField("TRA_PDF_FILE").getFormValue();
		
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>按金收據</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${traDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${traReceiptId}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${traDate}$</td>" + 
				"	<td>${traType}$</td>" + 
				"	<td>${traMethod}$</td>" + 
				"	<td>${traNote}$</td>" + 
				"	<td style='text-align: right'>${traAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>已付按金總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${traTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String REMARKS_AND_STAMP = "<br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${logo}$", getImgTag("file\\org" + patGrpBean.getOrgId() + "\\logo\\img1001.jpg",100)).replace("${perChiName}$", perChiName).replace("${patId}$", patId).replace("${traDate}$", traDate).replace("${traReceiptId}$", traReceiptId);
		String trxDetail = TRX_DETAIL_REC.replace("${traDate}$", traDate).replace("${traType}$", traType).replace("${traMethod}$", traMethod).replace("${traNote}$", traNote).replace("${traAmount}$", traAmount);
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${traTotalAmount}$", traAmount);
		PDFUtil.gen(patGrpBean.getOrgId(), traPdfFile, headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP);
	}
	
	public static void genReceiptSlip(ArrayList<StmtBean> stmtBeanList) {
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>付款收據</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${stmDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${stmID}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
		String TRX_DETAIL_HEADER ="<table style='width:100%'>" +  
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<col width='20%'/> " +
				"<tr style='background-color:LightSteelBlue'>" + 
				"	<td>日期</td>" + 
				"	<td>帳項</td>" + 
				"	<td>繳費方法</td>" + 
				"	<td>備註</td>" + 
				"	<td style='text-align: right'>金額(港幣)</td>" + 
				"</tr>"; 
		String TRX_DETAIL_REC = 
				"<tr>" + 
				"	<td>${trxDate}$</td>" + 
				"	<td>${trxItem}$</td>" + 
				"	<td>${trxPayMethod}$</td>" + 
				"	<td>${trxRmarks}$</td>" + 
				"	<td style='text-align: right'>${trxAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_TOTAL = "<tr>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='border:none;'></td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>已付總數</td>" + 
				"	<td style='background-color:WhiteSmoke; text-align: right'>HK$ ${trxTotalAmount}$</td>" + 
				"</tr>";
		String TRX_DETAIL_FOOTER = "</table><br/><br/>";
		String REMARKS_AND_STAMP = "<br/>"+
		        "<table width='300px'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td style='border: none'>公司蓋印:</td>" + 
				"	<td style='border: none; border-bottom: 1pt solid black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>" + 
				"</tr>" + 
				"</table>";
		String headerAndInfo= HEADER_AND_INFO.replace("${logo}$", getImgTag("file\\org1001\\logo\\img1001.jpg",100)).replace("${perChiName}$", "陳大文").replace("${stmDate}$", "2019-01-01").replace("${stmID}$", "STM100001");
		String trxDetail = TRX_DETAIL_REC.replace("${trxDate}$", "2019-01-01").replace("${trxItem}$", "2019-01-01").replace("${trxPayMethod}$", "2019-01-01").replace("${trxRmarks}$", "2019-01-01").replace("${trxAmount}$", "2019-01-01");
		String trxDetailTotal = TRX_DETAIL_TOTAL.replace("${trxTotalAmount}$", "123.00");
		//PDFUtil.gen("香港仔安老院", "GRANYET (ABERDEEN) ELDERLY CARE CENTRE", "香港仔田灣漁歌街5號xxxxxxxx","12345678", "11112222", headerAndInfo+TRX_DETAIL_HEADER+trxDetail+trxDetailTotal+TRX_DETAIL_FOOTER+REMARKS_AND_STAMP);
	}
	
	public static void genStatement(ArrayList<StmtBean> stmtBeanList) {
		String HEADER_AND_INFO = "<table style='border-bottom: 1pt solid black; font-size: 36px; width:100%; height:60px'>" + 
				"<tr style='vertical-align: middle;'>" +
				"	<td style='border: none'>付款收據</td>" + 
				"	<td style='border: none; text-align: right'>${logo}$</td>" + 
				"</tr>" + 
				"</table>" + 
				"<br/>" +
		        "<table width='100%'><tr><td style='border: 0px'>" +
				"<table width='300px' align='right'>" +  
				"<col width='50%'/> " +
				"<col width='50%'/> " +
				"<tr>" + 
				"	<td>院友姓名:</td>" + 
				"	<td>${perChiName}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>院友編號:</td>" + 
				"	<td>${patId}$</td>" + 
				"</tr>" +
				"<tr>" + 
				"	<td>收據日期:</td>" + 
				"	<td>${stmDate}$</td>" + 
				"</tr>" + 
				"<tr>" + 
				"	<td>收據號碼:</td>" + 
				"	<td>${stmID}$</td>" + 
				"</tr>" +
				"</table>" +
				"</td></tr></table>" +
				"<br/><br/>";
	}
	
	// --------template end------- //
	
	public static void main(String [] args) {
		//PDFUtil.gen("香港仔安老院", "GRANYET (ABERDEEN) ELDERLY CARE CENTRE", "香港仔田灣漁歌街5號xxxxxxxx","12345678", "11112222", "testing1234");
		//genDownPaymentSlip(null);
		//genDepositeSlip(null);
		//genReceiptSlip(null);
		String a = "file/org1001/per100005/10000042.pdf";
		System.out.println(a.substring(0,a.lastIndexOf("/")+1));
		System.out.println(a.substring(a.lastIndexOf("/")+1,a.length()));
		System.out.println(a.replace("/","\\"));
	}
}
