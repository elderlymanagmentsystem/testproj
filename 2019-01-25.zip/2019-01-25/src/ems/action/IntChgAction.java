package ems.action;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

import ems.bean.PatGrpBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PcoBean;
import ems.bean.QuoBean;
import ems.bean.ResBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.db.EmsDB;
import ems.module.PatModule;
import ems.module.BedModule;
import ems.module.OrgModule;
import ems.module.UserModule;


public class IntChgAction extends ActionSupport implements SessionAware, ServletRequestAware, ServletResponseAware {
	private OrgBean orgBean;
	private String funcId;
	private Map<String, Object> session;
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	public static final String DEFAULT_FUNC_ID = "030500";
	
	
	public String execute()
	{
		response.setContentType("text/html;charset=UTF-8");
		UserBean userBean = (UserBean)session.get("userBean");
		
		OrgModule orgMod = new OrgModule();
		if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_ENQ)) {
			orgMod.performEnqOrg(orgBean, userBean);
		}else if(funcId.length()==6 && funcId.substring(4).equals(EmsDB.FUNC_MOD)){
			orgMod.performUpdateIntChg(orgBean, userBean);
		}

		if(orgBean.getMsg()==null||orgBean.getMsg().length()==0) {
			addActionMessage("");

 			if(funcId.length()==6)
				funcId = funcId.substring(0, 4) + EmsDB.FUNC_ENQ; 
			request.setAttribute("funcId", funcId);
			request.setAttribute("orgBean", orgBean);

			return SUCCESS;
			
			
		}else {
			addActionError(orgBean.getMsg());

			request.setAttribute("funcId", funcId);
			request.setAttribute("orgBean", orgBean);

			return INPUT;
		}
		
	}
	 
	public void validate() {
		
		boolean validated = true;
		UserBean userBean = (UserBean)session.get("userBean");
		
		funcId = request.getParameter("funcId");
		if(funcId==null || funcId.length()==0)
			funcId = DEFAULT_FUNC_ID;
		if(orgBean==null)
			orgBean = new OrgBean();

		orgBean.setMsg("");
		
		orgBean.getField("ORG_INT_RATE").setFormValue(request.getParameter("ORG_INT_RATE"));
		orgBean.getField("ORG_CHARGE").setFormValue(request.getParameter("ORG_CHARGE"));

		if(funcId.length()==6 && (funcId.substring(4).equals(EmsDB.FUNC_ADD) || funcId.substring(4).equals(EmsDB.FUNC_MOD) || funcId.substring(4).equals(EmsDB.FUNC_DEL))) {
			
			orgBean.setOrgId(userBean.getAccOrgId());
			
		}else {
			if(request.getParameter("ACC_ORG_ID")!=null && request.getParameter("ACC_ORG_ID").length()>0) {
				userBean.setAccOrgId(request.getParameter("ACC_ORG_ID"));	
			}
		}
		
	}

	public OrgBean getOrgBean() {
		return orgBean;
	}

	public void setOrgBean(OrgBean orgBean) {
		this.orgBean = orgBean;
	}
    
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}


}
