package ems.sch;

import java.util.Map;

public class GenSLPCFM extends PDFAbstract{
	public boolean exportPDF() {
		return exportPDF("default.pdf");
    }
	
	public boolean exportPDF(String filename) {
		//C:\development\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\EMS\
		//C:\development\EMS
		this.setHtmlBody("<p>asdfasdf</p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><p>end</p>");
		return createPDF(filename);
    }

	public static void main(String [] args) {
		GenSLPCFM genSLPCFM = new GenSLPCFM();
		genSLPCFM.exportPDF();
	}
	
}
