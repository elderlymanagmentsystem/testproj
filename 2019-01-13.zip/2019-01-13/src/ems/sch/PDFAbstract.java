package ems.sch;

import java.io.File;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.sun.javafx.collections.MappingChange.Map;

import io.woo.htmltopdf.HtmlToPdf;
import io.woo.htmltopdf.HtmlToPdfObject;


public abstract class PDFAbstract {
	private static String HTML_HEAD = "<!DOCTYPE html><html><head><meta http-equiv='Contenjt-Type' content='text/html; charset=UTF-8'></head><body>";
	private static String htmlBody = "";
	private static String HTML_TAIL = "</body></html>";
	private static String PDF_PATH=System.getProperty("user.dir") + File.separator+ "WebContent" + File.separator + "pdf" + File.separator;
	private HtmlToPdfObject htmlToPdfObject;
	
	
	public static final String SLPCFM = "SLPCFM";
	public static final String SLPREC = "SLPREC";
	
	public PDFAbstract(){
		if (System.getProperty( "catalina.base" ) != null) {
			File catalinaBase = new File( System.getProperty( "catalina.base" ) );
			PDF_PATH = catalinaBase.getAbsoluteFile() + File.separator + "wtpwebapps" + File.separator + "EMS" + File.separator + "pdf" + File.separator;
		}
		
	}
	
	public boolean createPDF(String filename) {
		htmlToPdfObject = HtmlToPdfObject.forHtml(HTML_HEAD+htmlBody+HTML_TAIL);
		htmlToPdfObject.headerLine(true).pageCount(true).headerRight("頁 [page]/[toPage]");
		boolean re = HtmlToPdf.create().object(htmlToPdfObject).convert(PDF_PATH + filename);
		if (re) System.out.println(PDF_PATH + filename + " is created.");
		return re;
	}

	public String getHtmlBody() {
		return htmlBody;
	}

	public void setHtmlBody(String htmlBody) {
		this.htmlBody = htmlBody;
	} 
	
}
