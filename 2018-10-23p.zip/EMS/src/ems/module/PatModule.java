package ems.module;

import java.math.BigDecimal;
import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PatDB;
import ems.db.PerDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class PatModule {

	public boolean performEnqPatDetail(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		patDB.performEnqPatDetail(patGrpBean, userBean);

		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performEnqPatList(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		PerDB perDB = new PerDB();
		patGrpBean.setZoneBeanList(new ArrayList<ZoneBean>());
		patGrpBean.setPatBeanList(new ArrayList<PatBean>());

		if(patGrpBean.getEnqPatName()!=null && patGrpBean.getEnqPatName().length()>0) {
			patDB.performEnqPatList(patGrpBean, userBean);
		}
		
		patDB.performEnqZoneList(patGrpBean, userBean);
		patGrpBean.getResGrpBean().setEnqStatus("Y");
		perDB.performEnqResList(patGrpBean.getResGrpBean(), userBean);
		patGrpBean.getQuoGrpBean().setEnqStatus("Y");
		perDB.performEnqQuoteList(patGrpBean.getQuoGrpBean(), userBean);
		
			
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdatePat(PatGrpBean patGrpBean, UserBean userBean, boolean hasImageUpload) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		PerDB perDB = new PerDB();
		
		patGrpBean.setOrgId(userBean.getAccOrgId());
		patGrpBean.getField("PER_STATUS").setValue("Y");
		patGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
		if(hasImageUpload) {
			patGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+patGrpBean.getOrgId()+"-"+patGrpBean.getPerId()+".jpg");
		}
		patGrpBean.getField("PAT_STATUS").setValue("Y");
		patGrpBean.getField("PAT_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getPerId()==null || patGrpBean.getPerId().length()==0) {
			patGrpBean.setPerId(patDB.getNextPerId(userBean.getOrgId()));
			patDB.performAddPer(patGrpBean, userBean);
		}else {
			patDB.performModPer(patGrpBean, userBean);
		}
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getPatId()==null || patGrpBean.getPatId().length()==0) {
				patGrpBean.setPatId(patDB.getNextPatId(userBean.getOrgId()));
				patDB.performAddPat(patGrpBean, userBean);
			}else {
				patDB.performModPat(patGrpBean, userBean);
			}
		}
		
		if(patGrpBean.getLivBeanList().size()>0) {
			LivBean livBean = patGrpBean.getLivBeanList().get(0);
			livBean.setOrgId(userBean.getAccOrgId());
			livBean.setPatId(patGrpBean.getPatId());
			livBean.getField("LIV_STATUS").setValue("Y");
			livBean.getField("LIV_MOD_BY").setValue(userBean.getUserId());
			
			TransBean transBean = patGrpBean.getTransBean();
			transBean.setOrgId(userBean.getAccOrgId());
			transBean.setPerId(patGrpBean.getPerId());
			transBean.getField("TRA_STATUS").setValue("Y");
			transBean.getField("TRA_MOD_BY").setValue(userBean.getUserId());
			
			if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
				if(livBean.getBedId()!=null && livBean.getZoneId()!=null && livBean.getBedId().length()>0 && livBean.getZoneId().length()>0) {
					if(livBean.getLivId()==null || livBean.getLivId().length()==0) {
						livBean.setLivId(patDB.getNextLivId(userBean.getOrgId()));
						transBean.getField("LIV_ID").setFormValue(livBean.getLivId());
						patDB.performAddToBed(patGrpBean, userBean);
						
						if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
							if(patGrpBean.getQuoGrpBean()!=null && patGrpBean.getQuoBeanList().size()>0 && (patGrpBean.getQuoBeanList().get(0)).getQuoId()!=null && (patGrpBean.getQuoBeanList().get(0)).getQuoId().length() > 0) {
								perDB.performQuoToLiv(patGrpBean, userBean);
							}
						}
						if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
							if(patGrpBean.getResGrpBean()!=null && patGrpBean.getResBeanList().size()>0 && (patGrpBean.getResBeanList().get(0)).getResId()!=null && (patGrpBean.getResBeanList().get(0)).getResId().length() > 0) {
								perDB.performResToLiv(patGrpBean, userBean);
							}
						}
						if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
							if(transBean.getField("TRA_AMOUNT").getFormValue().length()>0 && ((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).intValue()>0)
								 patDB.performDeposit(patGrpBean, userBean);
						}
						
					}else {
						transBean.getField("LIV_ID").setFormValue(livBean.getLivId());
						patDB.performChangeBed(patGrpBean, userBean);
					}
				}
			}
		}
		
		patDB.performCleanPco(patGrpBean, userBean);
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getPcoBeanList().size()>0) {
				for(int i=0;i<patGrpBean.getPcoBeanList().size();i++) {
					PerBean pcoPerBean = patGrpBean.getPcoBeanList().get(i).getPerBean();
	
					if(pcoPerBean.getField("PER_CHI_NAME").getFormValue().length()>0 && pcoPerBean.getField("PER_TEL").getFormValue().length()>0) {
						patDB.getPerBeanByNameTel(pcoPerBean);
						pcoPerBean.getField("PER_NATURE").setValue("C");
						pcoPerBean.getField("PER_STATUS").setValue("Y");
						pcoPerBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
	
						if(pcoPerBean.getPerId()==null || pcoPerBean.getPerId().length()==0) {
							pcoPerBean.setPerId(patDB.getNextPerId(pcoPerBean.getOrgId()));
							patDB.performAddPcoPer(pcoPerBean, userBean);
						}else {
							patDB.performModPcoPer(pcoPerBean, userBean);
						}
						
						if(pcoPerBean.getMsg().length()>0) {
							patGrpBean.setMsg(pcoPerBean.getMsg());
						}else {
							PcoBean pcoBean = patGrpBean.getPcoBeanList().get(i);
							pcoBean.getField("PER_ID").setFormValue(patGrpBean.getPerId());
							pcoBean.getField("PCO_PER_ID").setFormValue(pcoPerBean.getField("PER_ID").getFormValue());
							pcoBean.getField("PCO_STATUS").setValue("Y");
							pcoBean.getField("PCO_MOD_BY").setValue(userBean.getUserId());
	
							patDB.performAddPco(pcoBean, userBean);
							if(pcoBean.getMsg().length()>0) {
								patGrpBean.setMsg(pcoBean.getMsg());
							}
						}
					}
				}
			}
		}
		
//Retrieve new Pat List
		patDB.performEnqZoneList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		

}
