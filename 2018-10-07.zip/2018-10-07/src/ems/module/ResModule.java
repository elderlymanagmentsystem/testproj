package ems.module;

import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.ResBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.ResGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PerDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class ResModule {

	public boolean performEnqPerDetail(ResGrpBean resGrpBean, UserBean userBean) {
		PerDB perDB = new PerDB();
		perDB.performEnqPerDetail(resGrpBean, userBean);

		if (resGrpBean!=null && (resGrpBean.getMsg()==null || resGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performEnqResList(ResGrpBean resGrpBean, UserBean userBean) {
		PerDB perDB = new PerDB();

		perDB.performEnqResList(resGrpBean, userBean);
		perDB.performEnqEmptyBed(resGrpBean, userBean);
		
		if (resGrpBean!=null && (resGrpBean.getMsg()==null || resGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdatePer(ResGrpBean resGrpBean, UserBean userBean, boolean hasImageUpload) {
		resGrpBean.setMsg("");

//Update DB
		PerDB perDB = new PerDB();
		
		resGrpBean.setOrgId(userBean.getAccOrgId());
		resGrpBean.getField("PER_STATUS").setValue("Y");
		resGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
		if(hasImageUpload) {
			resGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+resGrpBean.getOrgId()+"-"+resGrpBean.getPerId()+".jpg");
		}

		if(resGrpBean.getField("PER_CHI_NAME").getFormValue().length()>0 && resGrpBean.getField("PER_TEL").getFormValue().length()>0) {
			perDB.getPerBeanByNameTel(resGrpBean);
		}
		
		if(resGrpBean.getPerId()==null || resGrpBean.getPerId().length()==0) {
			resGrpBean.setPerId(perDB.getNextPerId(userBean.getOrgId()));
			perDB.performAddPer(resGrpBean, userBean);
		}else {
			perDB.performModPer(resGrpBean, userBean);
		}
		
		if(resGrpBean.getResBeanList().size()>0) {
			ResBean resBean = resGrpBean.getResBeanList().get(0);
			resBean.setOrgId(userBean.getAccOrgId());
			resBean.setPerId(resGrpBean.getPerId());
			resBean.getField("RES_STATUS").setValue("Y");
			resBean.getField("RES_MOD_BY").setValue(userBean.getUserId());
			
			if(resGrpBean.getMsg()==null || resGrpBean.getMsg().length()==0) {
				if(resBean.getBedId()!=null && resBean.getZoneId()!=null && resBean.getBedId().length()>0 && resBean.getZoneId().length()>0) {
					if(resBean.getResId()!=null && resBean.getResId().length()>0) {
						perDB.performModRes(resGrpBean, userBean);
					}else {
						resBean.setResId(perDB.getNextResId(userBean.getOrgId()));
						perDB.performAddRes(resGrpBean, userBean);
					}
				}
			}
		}
		
		perDB.performCleanPco(resGrpBean, userBean);
		
		if(resGrpBean.getMsg()==null || resGrpBean.getMsg().length()==0) {
			if(resGrpBean.getPcoBeanList().size()>0) {
				for(int i=0;i<resGrpBean.getPcoBeanList().size();i++) {
					PerBean pcoPerBean = resGrpBean.getPcoBeanList().get(i).getPerBean();
	
					if(pcoPerBean.getField("PER_CHI_NAME").getFormValue().length()>0 && pcoPerBean.getField("PER_TEL").getFormValue().length()>0) {
						perDB.getPerBeanByNameTel(pcoPerBean);
						pcoPerBean.getField("PER_NATURE").setValue("C");
						pcoPerBean.getField("PER_STATUS").setValue("Y");
						pcoPerBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
	
						if(pcoPerBean.getPerId()==null || pcoPerBean.getPerId().length()==0) {
							pcoPerBean.setPerId(perDB.getNextPerId(pcoPerBean.getOrgId()));
							perDB.performAddPcoPer(pcoPerBean, userBean);
						}else {
							perDB.performModPcoPer(pcoPerBean, userBean);
						}
						
						if(pcoPerBean.getMsg().length()>0) {
							resGrpBean.setMsg(pcoPerBean.getMsg());
						}else {
							PcoBean pcoBean = resGrpBean.getPcoBeanList().get(i);
							pcoBean.getField("PER_ID").setFormValue(resGrpBean.getPerId());
							pcoBean.getField("PCO_PER_ID").setFormValue(pcoPerBean.getField("PER_ID").getFormValue());
							pcoBean.getField("PCO_STATUS").setValue("Y");
							pcoBean.getField("PCO_MOD_BY").setValue(userBean.getUserId());
	
							perDB.performAddPco(pcoBean, userBean);
							if(pcoBean.getMsg().length()>0) {
								resGrpBean.setMsg(pcoBean.getMsg());
							}
						}
					}
				}
			}
		}
		
//Retrieve new Pat List
		perDB.performEnqResList(resGrpBean, userBean);
		perDB.performEnqEmptyBed(resGrpBean, userBean);
		
		if (resGrpBean!=null && (resGrpBean.getMsg()==null || resGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		

}
