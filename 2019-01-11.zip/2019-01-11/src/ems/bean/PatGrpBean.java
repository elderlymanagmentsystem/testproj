package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class PatGrpBean extends PatBean {
	
	String enqPatType = "";
	String enqPatName = "";
	String enqPatId = "";
	String jspPerId = "";
	String enqCitemId = "";
	String enqLivStatus = "";
	String enqLivExitReason = "";
	String enqDate = "";
	String enqStartDate = "";
	String enqEndDate = "";
	
	private ArrayList<ZoneBean> zoneBeanList = new ArrayList<ZoneBean>();
	private ArrayList<PatBean> patBeanList = new ArrayList<PatBean>();
	private ArrayList<BankBean> bankBeanList = new ArrayList<BankBean>();
	private ArrayList<StmtBean> stmtBeanList = new ArrayList<StmtBean>();
	TransBean transBean = new TransBean();	
	ResGrpBean resGrpBean = new ResGrpBean(); 
	QuoGrpBean quoGrpBean = new QuoGrpBean(); 
	AccGrpBean accGrpBean = new AccGrpBean(); 
	CperBean cperBean = new CperBean(); 
	CorgBean corgBean = new CorgBean();
	
		
	public PatGrpBean() {
	}
	

	public String getEnqPatType() {
		return enqPatType;
	}


	public void setEnqPatType(String enqPatType) {
		this.enqPatType = enqPatType;
	}


	public String getEnqPatName() {
		return enqPatName;
	}

	public void setEnqPatName(String enqPatName) {
		this.enqPatName = enqPatName;
	}

	public String getEnqPatId() {
		return enqPatId;
	}

	public void setEnqPatId(String enqPatId) {
		this.enqPatId = enqPatId;
	}

	public String getEnqCitemId() {
		return enqCitemId;
	}

	public void setEnqCitemId(String enqCitemId) {
		this.enqCitemId = enqCitemId;
	}

	public ArrayList<PatBean> getPatBeanList(){
		return patBeanList;
	}
	
	public void setPatBeanList(ArrayList<PatBean> patBeanList) {
		this.patBeanList = patBeanList;
	}

	public void addPatBeanList(PatBean patBean) {
		patBeanList.add(patBean);
	}

	public ArrayList<BankBean> getBankBeanList(){
		return bankBeanList;
	}
	
	public void setBankBeanList(ArrayList<BankBean> bankBeanList) {
		this.bankBeanList = bankBeanList;
	}

	public void addBankBeanList(BankBean bankBean) {
		bankBeanList.add(bankBean);
	}
	
	public ArrayList<ZoneBean> getZoneBeanList(){
		return zoneBeanList;
	}
	
	public void setZoneBeanList(ArrayList<ZoneBean> zoneBeanList) {
		this.zoneBeanList = zoneBeanList;
	}

	public void addZoneBeanList(ZoneBean zoneBean) {
		zoneBeanList.add(zoneBean);
	}

	public ZoneBean getZoneBean(String zoneId, String orgId){
		for(int i=0;i<zoneBeanList.size();i++) {
			if(zoneId != null && orgId != null && zoneId.equals(zoneBeanList.get(i).getZoneId()) && orgId.equals(zoneBeanList.get(i).getOrgId())){
				return zoneBeanList.get(i);
			}
		}
		return null;
	}
	
	public PatBean getPatBean(String patId, String orgId){
		for(int i=0;i<patBeanList.size();i++) {
			if(patId != null && orgId != null && patId.equals(patBeanList.get(i).getPatId()) && orgId.equals(patBeanList.get(i).getOrgId())){
				return patBeanList.get(i);
			}
		}
		return null;
	}
	
	public TransBean getTransBean() {
		return transBean;
	}


	public void setTransBean(TransBean transBean) {
		this.transBean = transBean;
	}


	public ResGrpBean getResGrpBean() {
		return resGrpBean;
	}


	public void setResGrpBean(ResGrpBean resGrpBean) {
		this.resGrpBean = resGrpBean;
	}

	
	public QuoGrpBean getQuoGrpBean() {
		return quoGrpBean;
	}


	public void setQuoGrpBean(QuoGrpBean quoGrpBean) {
		this.quoGrpBean = quoGrpBean;
	}

	public CperBean getCperBean() {
		return cperBean;
	}


	public void setCperBean(CperBean cperBean) {
		this.cperBean = cperBean;
	}


	public CorgBean getCorgBean() {
		return corgBean;
	}


	public void setCorgBean(CorgBean corgBean) {
		this.corgBean = corgBean;
	}


	public ArrayList<StmtBean> getStmtBeanList(){
		return stmtBeanList;
	}
	
	public void setStmtBeanList(ArrayList<StmtBean> stmtBeanList) {
		this.stmtBeanList = stmtBeanList;
	}

	public void addStmtBeanList(StmtBean stmtBean) {
		stmtBeanList.add(stmtBean);
	}
	


	public AccGrpBean getAccGrpBean() {
		return accGrpBean;
	}


	public void setAccGrpBean(AccGrpBean accGrpBean) {
		this.accGrpBean = accGrpBean;
	}


	public String getEnqLivStatus() {
		return enqLivStatus;
	}


	public void setEnqLivStatus(String enqLivStatus) {
		this.enqLivStatus = enqLivStatus;
	}


	public String getEnqLivExitReason() {
		return enqLivExitReason;
	}


	public void setEnqLivExitReason(String enqLivExitReason) {
		this.enqLivExitReason = enqLivExitReason;
	}


	public String getEnqDate() {
		return enqDate;
	}


	public void setEnqDate(String enqDate) {
		this.enqDate = enqDate;
	}


	public String getJspPerId() {
		return jspPerId;
	}


	public void setJspPerId(String jspPerId) {
		this.jspPerId = jspPerId;
	}


	public String getEnqStartDate() {
		return enqStartDate;
	}


	public void setEnqStartDate(String enqStartDate) {
		this.enqStartDate = enqStartDate;
	}


	public String getEnqEndDate() {
		return enqEndDate;
	}


	public void setEnqEndDate(String enqEndDate) {
		this.enqEndDate = enqEndDate;
	}


	public void cleanup() {
		setLivBeanList(new ArrayList<LivBean>());
		setPcoBeanList(new ArrayList<PcoBean>());
		setTransBean(new TransBean());
		setCperBean(new CperBean());
		super.cleanup();
	}
	
	public boolean validate() {
		boolean successFlag = true;
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
