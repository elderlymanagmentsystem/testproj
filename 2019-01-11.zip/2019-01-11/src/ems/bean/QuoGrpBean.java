package ems.bean;

import java.util.ArrayList;

import ems.bean.BasicBean.Field;
import ems.db.EmsDB;

public class QuoGrpBean extends PerBean {
	
	String enqPerType = "";
	String enqPerName = "";
	String enqPerId = "";
	String enqStartDate = "";
	String enqEndDate = "";
	String enqStatus = "";
	
	private ArrayList<BedBean> emptyBedBeanList = new ArrayList<BedBean>();
	private ArrayList<ZoneBean> zoneBeanList = new ArrayList<ZoneBean>();
	private ArrayList<QuoBean> quoteBeanList = new ArrayList<QuoBean>();
		
	public QuoGrpBean() {
	}
	

	public String getEnqPerType() {
		return enqPerType;
	}


	public void setEnqPerType(String enqPerType) {
		this.enqPerType = enqPerType;
	}


	public String getEnqPerName() {
		return enqPerName;
	}

	public void setEnqPerName(String enqPerName) {
		this.enqPerName = enqPerName;
	}

	public String getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(String enqPerId) {
		this.enqPerId = enqPerId;
	}

	public ArrayList<QuoBean> getQuoteBeanList(){
		return quoteBeanList;
	}
	
	public void setQuoteBeanList(ArrayList<QuoBean> quoteBeanList) {
		this.quoteBeanList = quoteBeanList;
	}

	public void addQuoteBeanList(QuoBean quoteBean) {
		quoteBeanList.add(quoteBean);
	}


	
	
	public ArrayList<BedBean> getEmptyBedBeanList(){
		return emptyBedBeanList;
	}
	
	public void setEmptyBedBeanList(ArrayList<BedBean> emptyBedBeanList) {
		this.emptyBedBeanList = emptyBedBeanList;
	}

	public void addEmptyBedBeanList(BedBean bedBean) {
		emptyBedBeanList.add(bedBean);
	}

	public ArrayList<ZoneBean> getZoneBeanList(){
		return zoneBeanList;
	}
	
	public void setZoneBeanList(ArrayList<ZoneBean> zoneBeanList) {
		this.zoneBeanList = zoneBeanList;
	}

	public void addZoneBeanList(ZoneBean zoneBean) {
		zoneBeanList.add(zoneBean);
	}

	public BedBean getEmptyBedBean(String bedId, String orgId){
		for(int i=0;i<emptyBedBeanList.size();i++) {
			if(bedId != null && orgId != null && bedId.equals(emptyBedBeanList.get(i).getBedId()) && orgId.equals(emptyBedBeanList.get(i).getOrgId())){
				return emptyBedBeanList.get(i);
			}
		}
		return null;
	}
	
	public QuoBean getQuoteBean(String quoId, String orgId){
		for(int i=0;i<quoteBeanList.size();i++) {
			if(quoId != null && orgId != null && quoId.equals(quoteBeanList.get(i).getQuoId()) && orgId.equals(quoteBeanList.get(i).getOrgId())){
				return quoteBeanList.get(i);
			}
		}
		return null;
	}
	
	public void cleanup() {
		setPcoBeanList(new ArrayList<PcoBean>());
		setQuoBeanList(new ArrayList<QuoBean>());
		super.cleanup();
	}
	
	public String getEnqStartDate() {
		return enqStartDate;
	}


	public void setEnqStartDate(String enqStartDate) {
		this.enqStartDate = enqStartDate;
	}


	public String getEnqEndDate() {
		return enqEndDate;
	}


	public void setEnqEndDate(String enqEndDate) {
		this.enqEndDate = enqEndDate;
	}


	public String getEnqStatus() {
		return enqStatus;
	}


	public void setEnqStatus(String enqStatus) {
		this.enqStatus = enqStatus;
	}


	public boolean validate() {
		boolean successFlag = true;
		
		for(int i=0;i<fields.size();i++) {
			Field field = fields.get(i); 
			successFlag = field.validate() ? successFlag : false;
		}
		
		if(!successFlag)
			msg = "輸入錯誤";
		return successFlag;
	}
}
