package ems.bean;

import java.util.ArrayList;

import ems.db.EmsDB;

public class BedBean extends BasicBean {
	
	ArrayList<LivBean> livBeanList = new ArrayList<LivBean>();
	ArrayList<ResBean> resBeanList = new ArrayList<ResBean>();
	ArrayList<QuoBean> quoBeanList = new ArrayList<QuoBean>();
	String bedFullName = "";
	
	public BedBean() {
		for(int i=0; i<EmsDB.EM_BED_INFO.length;i++) {
			if(getField(EmsDB.EM_BED_INFO[i][0])==null)
				fields.add(new Field(EmsDB.EM_BED_INFO[i]));
		}
	}
	
	public String getBedId() {
		return getField("BED_ID").getFormValue();
	}
	public void setBedId(String bedId) {
		getField("BED_ID").setFormValue(bedId);
	}

	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getZoneId() {
		return getField("ZON_ID").getFormValue();
	}
	public void setZoneId(String zoneId) {
		getField("ZON_ID").setFormValue(zoneId);
	}

	public String getBedName() {
		return getField("BED_NAME").getFormValue();
	}
	public void setBedName(String bedName) {
		getField("BED_NAME").setFormValue(bedName);
	}
	
	public String getBedFullName() {
		return bedFullName;
	}
	public void setBedFullName(String zoneName, String bedName) {
		this.bedFullName = bedName + "("+zoneName+")";
	}
	public void setBedFullName(String zoneName, String bedName, String resInd) {
		this.bedFullName = resInd + bedName + "("+zoneName+")";
	}
	
	public LivBean getLivBean(String livId, String orgId){
		for(int i=0;i<livBeanList.size();i++) {
			if(livId != null && orgId != null && livId.equals(livBeanList.get(i).getLivId()) && orgId.equals(livBeanList.get(i).getOrgId())){
				return livBeanList.get(i);
			}
		}
		return null;
	}	
	
	public void setLivBeanList(ArrayList<LivBean> livBeanList) {
		this.livBeanList = livBeanList;
	}

	public ArrayList<LivBean> getLivBeanList() {
		return livBeanList;
	}
	public void addLivBeanList(LivBean livBean) {
		livBeanList.add(livBean);
	}
	
	public ResBean getResBean(String resId, String orgId){
		for(int i=0;i<resBeanList.size();i++) {
			if(resId != null && orgId != null && resId.equals(resBeanList.get(i).getResId()) && orgId.equals(resBeanList.get(i).getOrgId())){
				return resBeanList.get(i);
			}
		}
		return null;
	}	
	
	public void setResBeanList(ArrayList<ResBean> resBeanList) {
		this.resBeanList = resBeanList;
	}

	public ArrayList<ResBean> getResBeanList() {
		return resBeanList;
	}
	public void addResBeanList(ResBean resBean) {
		resBeanList.add(resBean);
	}
	
	public QuoBean getQuoBean(String quoId, String orgId){
		for(int i=0;i<quoBeanList.size();i++) {
			if(quoId != null && orgId != null && quoId.equals(quoBeanList.get(i).getQuoId()) && orgId.equals(quoBeanList.get(i).getOrgId())){
				return quoBeanList.get(i);
			}
		}
		return null;
	}	

	
	public void setQuoBeanList(ArrayList<QuoBean> quoBeanList) {
		this.quoBeanList = quoBeanList;
	}

	public ArrayList<QuoBean> getQuoBeanList() {
		return quoBeanList;
	}
	public void addQuoBeanList(QuoBean quoBean) {
		quoBeanList.add(quoBean);
	}
	

}
