package ems.interceptor;

import java.util.Map;

import org.apache.struts2.util.TokenHelper;

import ems.bean.UserBean;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class AuthInterceptor implements Interceptor{
	
	@Override
	public void destroy(){
		
	}
	
	@Override
	public void init() {
		
	}
	
	@Override
	public String intercept(ActionInvocation actionInvocation) throws Exception {
		Map<String, Object> session = actionInvocation.getInvocationContext().getSession();
		
		//if not yet login or expired, go to login page
		UserBean userBean = (UserBean) session.get("userBean");
		if (userBean == null) {
			return ActionSupport.LOGIN;
		}
		
		//if user refresh the page, to avoid double submit, do not process the action and return to input page
		String tokenVal = TokenHelper.getToken();
		String token = (String) session.get("token");
		if (token == null) {
			session.put("token", tokenVal);
		} else {
			if (token.equals(tokenVal)){
				//System.out.println("same token");
				return ActionSupport.INPUT;
			} else if (tokenVal != null){
				//System.out.println("different token");
				session.put("token", tokenVal);
			}
		}
		return actionInvocation.invoke();
	}
}
