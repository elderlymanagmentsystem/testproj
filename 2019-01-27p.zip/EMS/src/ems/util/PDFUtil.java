package ems.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.codec.Base64;

public class PDFUtil {
	private static ITextRenderer renderer = new ITextRenderer();
	private static String fontPath = EmsCommonUtil.getRuntimePath() + "font" + File.separator + "mingliu.ttf";
	private static String HTML_BODY="";
	private static String HTML_TAIL = "</body></html>";
	private static String HTML_HEAD = "<!DOCTYPE html><html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>"
			+ "<style>"
			+ " body { "
			+ "    font-family: MingLiU; "
			+ " } "
			+ "@page { margin: 12mm; "
			+ " @top-right { "
			+ "     font-family: MingLiU; "
			+ "     font-size: 12px; "
			+ "     vertical-align: text-top; "
			+ "     padding-top: 6mm; "
			+ "	    content: '頁 ' counter(page) '/' counter(pages);"
			+ " } "
			+ " @bottom-left { "
			+ " vertical-align: text-top; "
			+ "    font-family: MingLiU; "
			+ "    font-size: 12px; "
			+ "    white-space: pre-wrap;"
			+ "    content: '{orgChiName} {orgEngName}\\A地址: {orgAddr}'"
			+ " } "
			+ " @bottom-right { "
			+ "    font-family: MingLiU; "
			+ "    vertical-align: text-bottom; "
			+ "    white-space: pre-wrap;"
			+ "    font-size: 12px; "
			+ "    content: '\\A電話: {orgTel} 傳真: {orgFax}'"
			+ " } "
			+ "} "
			+ "</style>"
			+ "</head><body>";
	
	
	public static boolean gen(String orgChiName, String orgEngName, String orgChiAddr, String orgTel, String orgFax, String htmlContent) {
		if (orgChiName == null) orgChiName = "";
		if (orgEngName == null) orgEngName = "";
		if (orgChiAddr == null) orgChiAddr = "";
		if (orgTel == null) orgTel = "";
		if (orgFax == null) orgFax = "";
		if (htmlContent == null) htmlContent = "";
		HTML_HEAD = HTML_HEAD.replace("{orgChiName}", orgChiName).replace("{orgEngName}", orgEngName).replace("{orgChiName}", orgChiName).replace("{orgTel}", orgTel).replace("{orgFax}", orgFax);
		HTML_BODY = htmlContent;
		
		try
        {
			String outputFile = "C:\\Users\\patri\\Desktop\\a.pdf";
			OutputStream os = new FileOutputStream(outputFile);
			renderer.getFontResolver().addFont(fontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.setDocumentFromString(HTML_HEAD+HTML_BODY+HTML_TAIL);
			renderer.layout();
			renderer.createPDF(os);
			os.close();
			
        }
        catch (Throwable t)
        {
            t.printStackTrace();
            return false;
        }
		return true;
    }
	
	public static String getImgTag(String path){
		return getImgTag(path, 0, 0);
	}
	
	public static String getImgTag(String path, int width, int height){
		FileInputStream fileInputStreamReader = null;
		try {
			File file = new File(EmsCommonUtil.getRuntimePath()+File.separator+"images"+File.separator+path);
			fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int)file.length()];
			fileInputStreamReader.read(bytes);
			fileInputStreamReader.close();
			String temp = (width != 0 && height != 0) ? "' width='" + width + "' height='" + height + "'/>" : "'/>" ;
			return "<img src='data:image/jpg;base64, " + new String(Base64.encodeBytes(bytes)) + temp ;
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
    }
	
	public static void main(String [] args) {
		PDFUtil.gen("香港仔安老院", "GRANYET (ABERDEEN) ELDERLY CARE CENTRE", "香港仔田灣漁歌街5號xxxxxxxx","12345678", "11112222", "testing1234");		
	}
}
