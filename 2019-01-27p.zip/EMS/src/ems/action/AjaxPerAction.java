package ems.action;

import java.util.ArrayList;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.PerBean;
import ems.bean.QuoGrpBean;
import ems.bean.ResGrpBean;
import ems.bean.PcoBean;
import ems.bean.UserBean;
import ems.module.QuoteModule;
import ems.module.ResModule;

public class AjaxPerAction extends ActionSupport implements SessionAware {
	private QuoGrpBean quoGrpBean;
	private ResGrpBean resGrpBean;
	private int enqPerId;
	private Map<String, Object> session;
	private String perId = "";
	private String[] pcoChiName;
	private String[] pcoRel;
	private String[] pcoTel;
	private String[] pcoEmail;
	private String[] pcoSeq;
	private String quoId = "";
	private String quoType = "";
	private String quoPDFId = "";
	private String quoStartDate = "";
	private String quoLivingFee = "";
	private String quoNursingFee = "";
	private String quoStatus = "";
	private String quoZoneId = "";
	private String quoBedId = "";
	private String bedFullName = "";
	private String resId = "";
	private String resType = "";
	private String resPDFId = "";
	private String resStartDate = "";
	private String resLivingFee = "";
	private String resNursingFee = "";
	private String resStatus = "";
	private String resZoneId = "";
	private String resBedId = "";

	private String perChiName = "";
	private String perEngName = "";
	private String perHKID = "";
	private String perGender = "";
	private String perNBirth = "";
	private String perLBirth = "";
	private String perTel = "";
	private String perEmail = "";
	private String perDesc = "";
	private String perImageLink = "";
	private String perLDSRef = "";
	private String perLDSResult = "";
	private String perLDSDate = "";
	private String perAss1 = "";
	private String perAss2 = "";
	private String perAss2Oth = "";
	private String perAss3 = "";
	private String perAss3Oth = "";
	private String perAss4 = "";
	private String perReferal = "";
	private String perReferalOth = "";
	private String perBankId = "";
	private String perBankAccNo = "";
	private String perBankAccName = "";
	
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		
		QuoteModule quoMod = new QuoteModule();
		if(quoGrpBean!=null && quoGrpBean.getEnqPerId() != null && quoGrpBean.getEnqPerId().length()>0) {
			quoMod.performEnqPerDetail(quoGrpBean, userBean);

			if(quoGrpBean.getPcoBeanList().size()>0) {
				ArrayList<String> pcoChiNameList = new ArrayList<String>();
				ArrayList<String> pcoTelList = new ArrayList<String>();
				ArrayList<String> pcoEmailList = new ArrayList<String>();
				ArrayList<String> pcoRelList = new ArrayList<String>();
				ArrayList<String> pcoSeqList = new ArrayList<String>();
				for(int i=0;i<quoGrpBean.getPcoBeanList().size();i++) {
					PcoBean pcoBean = quoGrpBean.getPcoBeanList().get(i);
					pcoChiNameList.add(pcoBean.getPerBean().getField("PER_CHI_NAME").getFormValue());
					pcoTelList.add(pcoBean.getPerBean().getField("PER_TEL").getFormValue());
					pcoEmailList.add(pcoBean.getPerBean().getField("PER_EMAIL").getFormValue());
					pcoRelList.add(pcoBean.getField("PCO_RELATION").getFormValue());
					pcoSeqList.add(pcoBean.getField("PCO_SEQ").getFormValue());
					setPcoChiName(pcoChiNameList.toArray(new String[0]));
					setPcoTel(pcoTelList.toArray(new String[0]));
					setPcoEmail(pcoEmailList.toArray(new String[0]));
					setPcoRel(pcoRelList.toArray(new String[0]));
					setPcoSeq(pcoSeqList.toArray(new String[0]));
					
				}
			}else {
				setPcoChiName(new String[] {""});
				setPcoTel(new String[] {""});
				setPcoEmail(new String[] {""});
				setPcoRel(new String[] {""});
				setPcoSeq(new String[] {""});
			}
			
			if(quoGrpBean.getQuoBeanList().size()>0) {
				setQuoId(quoGrpBean.getQuoBeanList().get(0).getQuoId());
				setQuoType(quoGrpBean.getQuoBeanList().get(0).getField("QUO_TYPE").getFormValue());
				setQuoPDFId(quoGrpBean.getQuoBeanList().get(0).getField("QUO_PDF_ID").getFormValue());
				setQuoStartDate(quoGrpBean.getQuoBeanList().get(0).getField("QUO_START_DATE").getFormValue());
				setQuoLivingFee(quoGrpBean.getQuoBeanList().get(0).getField("QUO_LIVING_FEE").getFormValue());
				setQuoNursingFee(quoGrpBean.getQuoBeanList().get(0).getField("QUO_NURSING_FEE").getFormValue());
				setQuoStatus(quoGrpBean.getQuoBeanList().get(0).getField("QUO_STATUS").getFormValue());
				setQuoZoneId(quoGrpBean.getQuoBeanList().get(0).getBedBean().getZoneId());
				setQuoBedId(quoGrpBean.getQuoBeanList().get(0).getBedBean().getBedId());
				setBedFullName(quoGrpBean.getQuoBeanList().get(0).getBedBean().getBedFullName());
			}
			
			setPerId(quoGrpBean.getPerId());
			setPerChiName(quoGrpBean.getField("PER_CHI_NAME").getFormValue());
			setPerEngName(quoGrpBean.getField("PER_ENG_NAME").getFormValue());
			setPerHKID(quoGrpBean.getField("PER_HKID").getFormValue());
			setPerGender(quoGrpBean.getField("PER_GENDER").getFormValue());
			setPerImageLink(quoGrpBean.getField("PER_IMAGE_LINK").getFormValue());
			setPerNBirth(quoGrpBean.getField("PER_NBIRTH").getFormValue());
			setPerLBirth(quoGrpBean.getField("PER_LBIRTH").getFormValue());
			setPerTel(quoGrpBean.getField("PER_TEL").getFormValue());
			setPerEmail(quoGrpBean.getField("PER_EMAIL").getFormValue());
			setPerDesc(quoGrpBean.getField("PER_DESC").getFormValue());
			setPerLDSRef(quoGrpBean.getField("PER_LDS_REF").getFormValue());
			setPerLDSResult(quoGrpBean.getField("PER_LDS_RESULT").getFormValue());
			setPerLDSDate(quoGrpBean.getField("PER_LDS_DATE").getFormValue());
			setPerAss1(quoGrpBean.getField("PER_ASS1").getFormValue());
			setPerAss2(quoGrpBean.getField("PER_ASS2").getFormValue());
			setPerAss2Oth(quoGrpBean.getField("PER_ASS2_OTH").getFormValue());
			setPerAss3(quoGrpBean.getField("PER_ASS3").getFormValue());
			setPerAss3Oth(quoGrpBean.getField("PER_ASS3_OTH").getFormValue());
			setPerAss4(quoGrpBean.getField("PER_ASS4").getFormValue());
			setPerReferal(quoGrpBean.getField("PER_REFERAL").getFormValue());
			setPerReferalOth(quoGrpBean.getField("PER_REFERAL_OTH").getFormValue());
			setPerBankId(quoGrpBean.getField("BAN_ID").getFormValue());
			setPerBankAccNo(quoGrpBean.getField("PER_BANK_ACC_NO").getFormValue());
			setPerBankAccName(quoGrpBean.getField("PER_BANK_ACC_NAME").getFormValue());

		}else if(resGrpBean.getEnqPerId() != null && resGrpBean.getEnqPerId().length()>0){
			
			ResModule resMod = new ResModule();
			resMod.performEnqPerDetail(resGrpBean, userBean);

			if(resGrpBean.getPcoBeanList().size()>0) {
				ArrayList<String> pcoChiNameList = new ArrayList<String>();
				ArrayList<String> pcoTelList = new ArrayList<String>();
				ArrayList<String> pcoEmailList = new ArrayList<String>();
				ArrayList<String> pcoRelList = new ArrayList<String>();
				ArrayList<String> pcoSeqList = new ArrayList<String>();
				for(int i=0;i<resGrpBean.getPcoBeanList().size();i++) {
					PcoBean pcoBean = resGrpBean.getPcoBeanList().get(i);
					pcoChiNameList.add(pcoBean.getPerBean().getField("PER_CHI_NAME").getFormValue());
					pcoTelList.add(pcoBean.getPerBean().getField("PER_TEL").getFormValue());
					pcoEmailList.add(pcoBean.getPerBean().getField("PER_EMAIL").getFormValue());
					pcoRelList.add(pcoBean.getField("PCO_RELATION").getFormValue());
					pcoSeqList.add(pcoBean.getField("PCO_SEQ").getFormValue());
					setPcoChiName(pcoChiNameList.toArray(new String[0]));
					setPcoTel(pcoTelList.toArray(new String[0]));
					setPcoEmail(pcoEmailList.toArray(new String[0]));
					setPcoRel(pcoRelList.toArray(new String[0]));
					setPcoSeq(pcoSeqList.toArray(new String[0]));
					
				}
			}else {
				setPcoChiName(new String[] {""});
				setPcoTel(new String[] {""});
				setPcoEmail(new String[] {""});
				setPcoRel(new String[] {""});
				setPcoSeq(new String[] {""});
			}
			
			if(resGrpBean.getResBeanList().size()>0) {
				setResId(resGrpBean.getResBeanList().get(0).getResId());
				setResPDFId(resGrpBean.getResBeanList().get(0).getField("RES_TYPE").getFormValue());
				setResType(resGrpBean.getResBeanList().get(0).getField("RES_PDF_ID").getFormValue());
				setResStartDate(resGrpBean.getResBeanList().get(0).getField("RES_START_DATE").getFormValue());
				setResLivingFee(resGrpBean.getResBeanList().get(0).getField("RES_LIVING_FEE").getFormValue());
				setResNursingFee(resGrpBean.getResBeanList().get(0).getField("RES_NURSING_FEE").getFormValue());
				setResStatus(resGrpBean.getResBeanList().get(0).getField("RES_STATUS").getFormValue());
				setResZoneId(resGrpBean.getResBeanList().get(0).getBedBean().getZoneId());
				setResBedId(resGrpBean.getResBeanList().get(0).getBedBean().getBedId());
				setBedFullName(resGrpBean.getResBeanList().get(0).getBedBean().getBedFullName());
			}
			
			setPerId(resGrpBean.getPerId());
			setPerChiName(resGrpBean.getField("PER_CHI_NAME").getFormValue());
			setPerEngName(resGrpBean.getField("PER_ENG_NAME").getFormValue());
			setPerHKID(resGrpBean.getField("PER_HKID").getFormValue());
			setPerGender(resGrpBean.getField("PER_GENDER").getFormValue());
			setPerImageLink(resGrpBean.getField("PER_IMAGE_LINK").getFormValue());
			setPerNBirth(resGrpBean.getField("PER_NBIRTH").getFormValue());
			setPerLBirth(resGrpBean.getField("PER_LBIRTH").getFormValue());
			setPerTel(resGrpBean.getField("PER_TEL").getFormValue());
			setPerEmail(resGrpBean.getField("PER_EMAIL").getFormValue());
			setPerDesc(resGrpBean.getField("PER_DESC").getFormValue());
			setPerLDSRef(resGrpBean.getField("PER_LDS_REF").getFormValue());
			setPerLDSResult(resGrpBean.getField("PER_LDS_RESULT").getFormValue());
			setPerLDSDate(resGrpBean.getField("PER_LDS_DATE").getFormValue());
			setPerAss1(resGrpBean.getField("PER_ASS1").getFormValue());
			setPerAss2(resGrpBean.getField("PER_ASS2").getFormValue());
			setPerAss2Oth(resGrpBean.getField("PER_ASS2_OTH").getFormValue());
			setPerAss3(resGrpBean.getField("PER_ASS3").getFormValue());
			setPerAss3Oth(resGrpBean.getField("PER_ASS3_OTH").getFormValue());
			setPerAss4(resGrpBean.getField("PER_ASS4").getFormValue());
			setPerReferal(resGrpBean.getField("PER_REFERAL").getFormValue());
			setPerReferalOth(resGrpBean.getField("PER_REFERAL_OTH").getFormValue());
			setPerBankId(resGrpBean.getField("BAN_ID").getFormValue());
			setPerBankAccNo(resGrpBean.getField("PER_BANK_ACC_NO").getFormValue());
			setPerBankAccName(resGrpBean.getField("PER_BANK_ACC_NAME").getFormValue());

			
			
		}

		return SUCCESS;
	}
	
	public QuoGrpBean getQuoGrpBean() {
		return quoGrpBean;
	}

	public void setQuoGrpBean(QuoGrpBean quoGrpBean) {
		this.quoGrpBean = quoGrpBean;
	}
    
	public ResGrpBean getResGrpBean() {
		return resGrpBean;
	}

	public void setResGrpBean(ResGrpBean resGrpBean) {
		this.resGrpBean = resGrpBean;
	}
    
	public String[] getPcoChiName() {
		return pcoChiName;
	}

	public void setPcoChiName(String[] pcoChiName) {
		this.pcoChiName = pcoChiName;
	}

	public String[] getPcoRel() {
		return pcoRel;
	}

	public void setPcoRel(String[] pcoRel) {
		this.pcoRel = pcoRel;
	}

	public String[] getPcoTel() {
		return pcoTel;
	}

	public void setPcoTel(String[] pcoTel) {
		this.pcoTel = pcoTel;
	}

	public String[] getPcoSeq() {
		return pcoSeq;
	}

	public void setPcoSeq(String[] pcoSeq) {
		this.pcoSeq = pcoSeq;
	}

	
	public String getQuoId() {
		return quoId;
	}

	public void setQuoId(String quoId) {
		this.quoId = quoId;
	}

	public String getPerChiName() {
		return perChiName;
	}

	public void setPerChiName(String perChiName) {
		this.perChiName = perChiName;
	}

	public String getPerEngName() {
		return perEngName;
	}

	public void setPerEngName(String perEngName) {
		this.perEngName = perEngName;
	}

	public String getPerHKID() {
		return perHKID;
	}

	public void setPerHKID(String perHKID) {
		this.perHKID = perHKID;
	}

	public String getPerGender() {
		return perGender;
	}

	public void setPerGender(String perGender) {
		this.perGender = perGender;
	}

	public String getPerNBirth() {
		return perNBirth;
	}

	public void setPerNBirth(String perNBirth) {
		this.perNBirth = perNBirth;
	}

	public String getPerLBirth() {
		return perLBirth;
	}

	public void setPerLBirth(String perLBirth) {
		this.perLBirth = perLBirth;
	}

	public String getPerTel() {
		return perTel;
	}

	public void setPerTel(String perTel) {
		this.perTel = perTel;
	}

	public String getPerEmail() {
		return perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerDesc() {
		return perDesc;
	}

	public void setPerDesc(String perDesc) {
		this.perDesc = perDesc;
	}

	public String getQuoZoneId() {
		return quoZoneId;
	}

	public void setQuoZoneId(String quoZoneId) {
		this.quoZoneId = quoZoneId;
	}

	public String getQuoBedId() {
		return quoBedId;
	}

	public void setQuoBedId(String quoBedId) {
		this.quoBedId = quoBedId;
	}

	public String getBedFullName() {
		return bedFullName;
	}

	public void setBedFullName(String bedFullName) {
		this.bedFullName = bedFullName;
	}

	public String getQuoType() {
		return quoType;
	}

	public void setQuoType(String quoType) {
		this.quoType = quoType;
	}

	public String getQuoPDFId() {
		return quoPDFId;
	}

	public void setQuoPDFId(String quoPDFId) {
		this.quoPDFId = quoPDFId;
	}

	public String getQuoStartDate() {
		return quoStartDate;
	}

	public void setQuoStartDate(String quoStartDate) {
		this.quoStartDate = quoStartDate;
	}

	public String getQuoLivingFee() {
		return quoLivingFee;
	}

	public void setQuoLivingFee(String quoLivingFee) {
		this.quoLivingFee = quoLivingFee;
	}

	public String getQuoNursingFee() {
		return quoNursingFee;
	}

	public void setQuoNursingFee(String quoNursingFee) {
		this.quoNursingFee = quoNursingFee;
	}

	
	
	public String getResId() {
		return resId;
	}

	public void setResId(String resId) {
		this.resId = resId;
	}

	public String getResType() {
		return resType;
	}

	public void setResType(String resType) {
		this.resType = resType;
	}

	public String getResPDFId() {
		return resPDFId;
	}

	public void setResPDFId(String resPDFId) {
		this.resPDFId = resPDFId;
	}

	public String getResStartDate() {
		return resStartDate;
	}

	public void setResStartDate(String resStartDate) {
		this.resStartDate = resStartDate;
	}

	public String getResLivingFee() {
		return resLivingFee;
	}

	public void setResLivingFee(String resLivingFee) {
		this.resLivingFee = resLivingFee;
	}

	public String getResNursingFee() {
		return resNursingFee;
	}

	public void setResNursingFee(String resNursingFee) {
		this.resNursingFee = resNursingFee;
	}

	public String getResStatus() {
		return resStatus;
	}

	public void setResStatus(String resStatus) {
		this.resStatus = resStatus;
	}

	public String getResZoneId() {
		return resZoneId;
	}

	public void setResZoneId(String resZoneId) {
		this.resZoneId = resZoneId;
	}

	public String getResBedId() {
		return resBedId;
	}

	public void setResBedId(String resBedId) {
		this.resBedId = resBedId;
	}

	public String getPerLDSRef() {
		return perLDSRef;
	}

	public void setPerLDSRef(String perLDSRef) {
		this.perLDSRef = perLDSRef;
	}

	public String getPerLDSResult() {
		return perLDSResult;
	}

	public void setPerLDSResult(String perLDSResult) {
		this.perLDSResult = perLDSResult;
	}

	public String getPerLDSDate() {
		return perLDSDate;
	}

	public void setPerLDSDate(String perLDSDate) {
		this.perLDSDate = perLDSDate;
	}

	public String getPerAss1() {
		return perAss1;
	}

	public void setPerAss1(String perAss1) {
		this.perAss1 = perAss1;
	}

	public String getPerAss2() {
		return perAss2;
	}

	public void setPerAss2(String perAss2) {
		this.perAss2 = perAss2;
	}

	public String getPerAss2Oth() {
		return perAss2Oth;
	}

	public void setPerAss2Oth(String perAss2Oth) {
		this.perAss2Oth = perAss2Oth;
	}

	public String getPerAss3() {
		return perAss3;
	}

	public void setPerAss3(String perAss3) {
		this.perAss3 = perAss3;
	}

	public String getPerAss3Oth() {
		return perAss3Oth;
	}

	public void setPerAss3Oth(String perAss3Oth) {
		this.perAss3Oth = perAss3Oth;
	}

	public String getPerAss4() {
		return perAss4;
	}

	public void setPerAss4(String perAss4) {
		this.perAss4 = perAss4;
	}

	public String getPerReferal() {
		return perReferal;
	}

	public void setPerReferal(String perReferal) {
		this.perReferal = perReferal;
	}

	public String getPerReferalOth() {
		return perReferalOth;
	}

	public void setPerReferalOth(String perReferalOth) {
		this.perReferalOth = perReferalOth;
	}

	public String getPerBankId() {
		return perBankId;
	}

	public void setPerBankId(String perBankId) {
		this.perBankId = perBankId;
	}

	public String getPerBankAccNo() {
		return perBankAccNo;
	}

	public void setPerBankAccNo(String perBankAccNo) {
		this.perBankAccNo = perBankAccNo;
	}

	public String getPerBankAccName() {
		return perBankAccName;
	}

	public void setPerBankAccName(String perBankAccName) {
		this.perBankAccName = perBankAccName;
	}

	public String getPerImageLink() {
		return perImageLink;
	}

	public void setPerImageLink(String perImageLink) {
		this.perImageLink = perImageLink;
	}

	public String getPerId() {
		return perId;
	}

	public void setPerId(String perId) {
		this.perId = perId;
	}

	public String getQuoStatus() {
		return quoStatus;
	}

	public void setQuoStatus(String quoStatus) {
		this.quoStatus = quoStatus;
	}

	public String[] getPcoEmail() {
		return pcoEmail;
	}

	public void setPcoEmail(String[] pcoEmail) {
		this.pcoEmail = pcoEmail;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	
	
}
