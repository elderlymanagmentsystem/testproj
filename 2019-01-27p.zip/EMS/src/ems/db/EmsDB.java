package ems.db;

public class EmsDB {
/*
	public static final String[] EM_ORG_ORGANIZATION = {"ORG_ID", 
														"ORG_ENG_NAME", 
														"ORG_CHI_NAME",
														"ORG_ENG_ADDR",
														"ORG_CHI_ADDR",
														"ORG_TEL",
														"ORG_FAX",
														"ORG_WEBSITE",
														"ORG_EMAIL",
														"ORG_LICENSE_NO",
														"ORG_LICENSE_EXP_DATE",
														"ORG_BR_NO",
														"ORG_NATURE",
														"ORG_TOTAL_BED",
														"ORG_GOV_BED",
														"ORG_SERVICE_AIM",
														"ORG_IMAGE_LINK",
														"ORG_START_DATE",
														"ORG_END_DATE", 
														"ORG_STATUS",
														"ORG_MOD_BY",
														"ORG_MOD_DATE"};
*/
	public static final String[][] EM_BAN_BANK_CODE = {
														{"BAN_ID", "銀行編號", "String", "3", "", "N"},
														{"BAN_NAME", "銀行名稱", "String", "200", "", "N"},
														{"BAN_STATUS", "狀態", "String", "1", "", "N"},
														{"BAN_MOD_BY", "修改人員", "String", "50", "", "N"},
														{"BAN_MOD_DATE", "修改日期", "String", "10", "", "N"}
														};	

	public static final String[][] EM_ORG_ORGANIZATION = {
														{"ORG_ID", "院舍編號", "Integer", "4", "", "N"},
														{"ORG_ENG_NAME", "院舍名稱(英文)", "String", "100", "", "N"},
														{"ORG_CHI_NAME", "院舍名稱(中文)", "String", "100", "", "Y"},
														{"ORG_ENG_ADDR", "地址(英文)", "String", "200", "", "N"},
														{"ORG_CHI_ADDR", "地址(中文)", "String", "200", "", "N"},
														{"ORG_TEL", "電話", "String", "20", "", "N"},
														{"ORG_FAX", "傳真", "String", "20", "", "N"},
														{"ORG_WEBSITE", "網址", "String", "50", "", "N"},
														{"ORG_EMAIL", "電郵", "String", "50", "", "N"},
														{"ORG_LICENSE_NO", "牌照號碼", "String", "30", "", "N"},
														{"ORG_LICENSE_EXP_DATE", "牌照到期日", "Date", "10", "", "N"},
														{"ORG_BR_NO", "商業登記號碼", "String", "30", "", "N"},
														{"ORG_NATURE", "院舍性質", "String", "100", "", "N"},
														{"ORG_BED_LIMIT", "床位數限制", "Integer", "4", "", "Y"},
														{"ORG_TOTAL_BED", "總床位數", "Integer", "4", "", "N"},
														{"ORG_GOV_BED", "政府買位床位數", "Integer", "4", "", "N"},
														{"ORG_SERVICE_AIM", "服務宗旨", "String", "1000", "", "N"},
														{"ORG_IMAGE_LINK", "圖檔", "String", "100", "", "N"},
														{"ORG_START_DATE", "開始日期", "Date", "10", "", "Y"},
														{"ORG_END_DATE", "結束日期", "Date", "10", "", "N"},
														{"ORG_INT_RATE", "利率", "BigDecimal", "11", "", "N"},
														{"ORG_CHARGE", "延期罰款", "BigDecimal", "11", "", "N"},
														{"ORG_CUTOFF_DATE", "結算日", "Integer", "2", "", "Y"},
														{"ORG_STM_DATE", "結算日期", "Date", "10", "", "N"},
														{"ORG_STATUS", "狀態", "String", "1", "", "N"},
														{"ORG_MOD_BY", "修改人員", "String", "50", "", "N"},
														{"ORG_MOD_DATE", "修改日期", "String", "10", "", "N"}
														};	
	
	public static final String[][] EM_PER_PERSONAL_PARTICULAR   = {
																{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
																{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
																{"PER_CHI_NAME", "中文姓名", "String", "50", "", "Y"},
																{"PER_ENG_NAME", "英文姓名", "String", "50", "", "N"},
																{"PER_NBIRTH", "出生日期", "Date", "10", "", "N"},
																{"PER_LBIRTH", "農曆出生日期", "Date", "10", "", "N"},
																{"PER_HKID", "身份證號碼", "String", "20", "", "N"},
																{"PER_GENDER", "性別", "String", "1", "", "Y"},
																{"PER_TEL", "電話", "String", "20", "", "Y"},
																{"PER_EMAIL", "電郵", "String", "50", "", "N"},
																{"PER_DESC", "資訊", "String", "200", "", "N"},
																{"PER_NATURE", "性質", "String", "1", "", "Y"},
																{"PER_IMAGE_LINK", "圖檔", "String", "100", "", "N"},
																{"PER_LDS_REF", "LDS 編號", "String", "20", "", "N"},
																{"PER_LDS_RESULT", "評核結果", "String", "20", "", "N"},
																{"PER_LDS_DATE", "評核日期", "Date", "10", "", "N"},
																{"PER_ASS1", "行動能力", "String", "1", "", "N"},
																{"PER_ASS2", "飲食種類", "String", "1", "", "Y"},
																{"PER_ASS2_OTH", "飲食種類", "String", "100", "", "N"},
																{"PER_ASS3", "護理服務", "String", "1", "", "Y"},
																{"PER_ASS3_OTH", "護理服務", "String", "100", "", "N"},
																{"PER_ASS4", "護理程度", "String", "1", "", "Y"},
																{"PER_REFERAL", "媒介", "String", "1", "", "N"},
																{"PER_REFERAL_OTH", "媒介", "String", "100", "", "N"},
																{"BAN_ID", "銀行(自動轉賬用)", "String", "3", "", "N"},
																{"PER_BANK_ACC_NO", "戶口號碼(自動轉賬用)", "String", "30", "", "N"},
																{"PER_BANK_ACC_NAME", "戶口姓名(自動轉賬用)", "String", "50", "", "N"},
																{"PER_STATUS", "狀態", "String", "1", "", "Y"},
																{"PER_MOD_BY", "修改人員", "String", "50", "", "N"},
																{"PER_MOD_DATE", "修改日期", "String", "10", "", "N"}
																};

	public static final String[][] EM_PCO_PERSONAL_CONTACT   = {
																{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
																{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
																{"PCO_SEQ", "聯絡順序", "Integer", "2", "", "Y"},
																{"PCO_PER_ID", "聯絡人用戶編號", "Integer", "6", "", "N"},
																{"PCO_RELATION", "聯絡人關係", "String", "20", "", "N"},
																{"PCO_STATUS", "狀態", "String", "1", "", "Y"},
																{"PCO_MOD_BY", "修改人員", "String", "50", "", "N"},
																{"PCO_MOD_DATE", "修改日期", "String", "10", "", "N"}
																};

	public static final String[][] EM_USE_USER_ACCT = {
														{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
														{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
														{"USE_ID", "用戶名稱", "String", "50", "", "Y"},
														{"USE_PWD", "密碼", "String", "50", "", "N"},
														{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
														{"USE_STATUS", "狀態", "String", "1", "", "N"},
														{"USE_MOD_BY", "修改人員", "String", "50", "", "N"},
														{"USE_MOD_DATE", "修改日期", "String", "10", "", "N"}
													 };
		
	public static final String[][] EM_FUN_FUNCTION = {
												{"FUN_ID", "功能編號", "String", "6", "", "Y"},
												{"FUN_PARENT_ID", "繼承功能編號", "Integer", "6", "", "Y"},
												{"FUN_NAME", "功能名稱", "String", "50", "", "Y"},
												{"FUN_NAVI", "瀏覽列", "String", "50", "", "Y"},
												{"FUN_URL", "連結", "String", "50", "", "Y"},
												{"FUN_STATUS", "狀態", "String", "1", "", "N"},
												{"FUN_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"FUN_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_ROL_ROLE = {
												{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
												{"ROL_NAME", "權限名稱", "String", "100", "", "Y"},
												{"ROL_STATUS", "狀態", "String", "1", "", "N"},
												{"ROL_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"ROL_MOD_DATE", "修改日期", "String", "10", "", "N"}
											   };

	public static final String[][] EM_RFR_ROL_FUN_REL = {
												{"ROL_ID", "權限編號", "Integer", "3", "", "Y"},
												{"FUN_ID", "功能編號", "String", "6", "", "Y"},
												{"RFR_STATUS", "狀態", "String", "1", "", "N"},
												{"RFR_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"RFR_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_URR_USER_ROLE_REL = {
												{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
												{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
												{"ACC_ORG_ID", "管理院舍", "Integer", "4", "", "Y"},
												{"URR_STATUS", "狀態", "String", "1", "", "N"},
												{"URR_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"URR_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};
	
	public static final String[][] EM_ZON_ZONE = {
												{"ZON_ID", "區域編號", "Integer", "3", "", "N"},
												{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
												{"ZON_NAME", "區域名稱", "String", "50", "", "Y"},
												{"ZON_STATUS", "狀態", "String", "1", "", "N"},
												{"ZON_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"ZON_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_BED_INFO = {
												{"BED_ID", "床位編號", "Integer", "5", "", "N"},
												{"ZON_ID", "區域編號", "Integer", "3", "", "Y"},
												{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
												{"BED_NAME", "區域名稱", "String", "50", "", "N"},
												{"BED_STATUS", "狀態", "String", "1", "", "N"},
												{"BED_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"BED_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_PAT_PATIENT_INFO = {
												{"PAT_ID", "院友編號", "Integer", "6", "", "N"},
												{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
												{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
												{"PAT_STATUS", "狀態", "String", "1", "", "N"},
												{"PAT_MOD_BY", "修改人員", "String", "50", "", "N"},
												{"PAT_MOD_DATE", "修改日期", "String", "10", "", "N"}
												};

	public static final String[][] EM_LIV_RECORD = {
											{"LIV_ID", "入住編號", "Integer", "6", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"BED_ID", "床位編號", "Integer", "5", "", "Y"},
											{"ZON_ID", "區域編號", "Integer", "3", "", "Y"},
											{"PAT_ID", "院友編號", "Integer", "6", "", "N"},
											{"LIV_START_DATE", "開始日期", "Date", "10", "", "Y"},
											{"LIV_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"LIV_LIVING_FEE", "床位費", "BigDecimal", "11", "", "Y"},
											{"LIV_NURSING_FEE", "護理費", "BigDecimal", "11", "", "Y"},
											{"LIV_TYPE", "床位類別", "String", "1", "", "N"},
											{"LIV_EXIT_REASON", "退院原因", "String", "1", "", "N"},
											{"LIV_EXIT_REMARK", "退院備註", "String", "200", "", "N"},
											{"LIV_PDF_ID", "收據編號", "String", "20", "", "N"},
											{"LIV_STATUS", "狀態", "String", "1", "", "N"},
											{"LIV_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"LIV_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_QUO_RECORD = {
											{"QUO_ID", "報價編號", "Integer", "6", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"BED_ID", "床位編號", "Integer", "5", "", "Y"},
											{"ZON_ID", "區域編號", "Integer", "3", "", "Y"},
											{"PER_ID", "院友編號", "Integer", "6", "", "N"},
											{"QUO_START_DATE", "開始日期", "Date", "10", "", "Y"},
											{"QUO_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"QUO_LIVING_FEE", "床位費", "BigDecimal", "11", "", "Y"},
											{"QUO_NURSING_FEE", "護理費", "BigDecimal", "11", "", "Y"},
											{"QUO_TYPE", "床位類別", "String", "1", "", "N"},
											{"QUO_PDF_ID", "收據編號", "String", "20", "", "N"},
											{"QUO_STATUS", "狀態", "String", "1", "", "N"},
											{"QUO_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"QUO_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_RES_RECORD = {
											{"RES_ID", "訂位編號", "Integer", "6", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"BED_ID", "床位編號", "Integer", "5", "", "Y"},
											{"ZON_ID", "區域編號", "Integer", "3", "", "Y"},
											{"PER_ID", "院友編號", "Integer", "6", "", "N"},
											{"RES_START_DATE", "開始日期", "Date", "10", "", "Y"},
											{"RES_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"RES_LIVING_FEE", "床位費", "BigDecimal", "11", "", "Y"},
											{"RES_NURSING_FEE", "護理費", "BigDecimal", "11", "", "Y"},
											{"RES_TYPE", "床位類別", "String", "1", "", "N"},
											{"RES_PDF_ID", "收據編號", "String", "20", "", "N"},
											{"RES_STATUS", "狀態", "String", "1", "", "N"},
											{"RES_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"RES_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_TRA_TRANSACTIONS = {
											{"TRA_ID", "交易編號", "Integer", "8", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"PER_ID", "院友編號", "Integer", "6", "", "N"},
											{"RES_ID", "訂位編號", "Integer", "6", "", "N"},
											{"LIV_ID", "入住編號", "Integer", "6", "", "N"},
											{"STM_ID", "結單編號", "Integer", "6", "", "N"}, 
											{"TRA_NAME", "交易名稱", "String", "100", "", "Y"},
											{"TRA_TYPE", "交易種類", "String", "1", "", "Y"}, //R - 訂金, D - 按金, S - 月結
											{"TRA_DATE", "交易日期", "Date", "10", "", "Y"},
											{"TRA_AMOUNT", "金額", "BigDecimal", "11", "", "Y"},
											{"TRA_METHOD", "付款方法", "String", "1", "", "N"},
											{"TRA_NOTE", "備註", "String", "200", "", "N"},
											{"TRA_RECEIPT_ID", "收據編號", "Integer", "8", "", "N"},
											{"TRA_REMARK1", "收據項目1", "String", "100", "", "N"},
											{"TRA_REMARK2", "收據項目2", "String", "100", "", "N"},
											{"TRA_REMARK3", "收據項目3", "String", "100", "", "N"},
											{"TRA_ACC_BAL", "戶口結餘", "BigDecimal", "11", "", "N"},
											{"TRA_PDF_ID", "收據編號", "String", "20", "", "N"},
											{"TRA_STATUS", "狀態", "String", "1", "", "N"},  //Y - Normal, N - VOID
											{"TRA_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"TRA_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_CHC_CHARGE_CAT = {
											{"CHC_ID", "分類編號", "Integer", "4", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"CHC_NAME", "分類名稱", "String", "100", "", "N"},
											{"CHC_STATUS", "狀態", "String", "1", "", "N"},
											{"CHC_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"CHC_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};
	
	public static final String[][] EM_CHI_CHARGE_ITEM = {
											{"CHI_ID", "項目編號", "Integer", "6", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"CHC_ID", "分類編號", "Integer", "4", "", "N"},
											{"CHI_NAME", "項目名稱", "String", "100", "", "N"},
											{"CHI_UNIT", "單位", "String", "10", "", "N"},
											{"CHI_UNIT_PRICE", "單價", "BigDecimal", "11", "", "N"},
											{"CHI_REMARK", "備註", "String", "200", "", "N"},
											{"CHI_STATUS", "狀態", "String", "1", "", "N"},
											{"CHI_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"CHI_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};
	
	public static final String[][] EM_CHP_CHARGE_PERSON = {
											{"CHP_ID", "帳目編號", "Integer", "8", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"PER_ID", "用戶編號", "Integer", "6", "", "Y"},
											{"CHI_ID", "項目編號", "Integer", "6", "", "Y"},
											{"CHP_NATURE", "性質", "String", "1", "", "Y"}, // O - One off, M - per month
											{"CHP_QUANTITY", "數量", "Integer", "6", "", "N"},
											{"CHP_UNIT_PRICE", "單價", "BigDecimal", "11", "", "N"},
											{"CHP_AMOUNT", "金額", "BigDecimal", "11", "", "Y"},
											{"CHP_START_DATE", "開始/入帳日", "Date", "10", "", "Y"},
											{"CHP_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"CHP_CURRENT_PAY_DATE", "繳款日期", "Date", "10", "", "N"},
											{"CHP_REMARK", "備註", "String", "200", "", "N"},
											{"CHP_STATUS", "狀態", "String", "1", "", "N"},
											{"CHP_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"CHP_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_CHO_CHARGE_ORG = {
											{"CHO_ID", "帳目編號", "Integer", "8", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
											{"CHI_ID", "項目編號", "Integer", "6", "", "Y"},
											{"CHO_NATURE", "性質", "String", "1", "", "Y"}, // O - One off, M - per month
											{"CHO_QUANTITY", "數量", "Integer", "6", "", "N"},
											{"CHO_UNIT_PRICE", "單價", "BigDecimal", "11", "", "N"},
											{"CHO_AMOUNT", "金額", "BigDecimal", "11", "", "Y"},
											{"CHO_START_DATE", "開始/入帳日", "Date", "10", "", "Y"},
											{"CHO_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"CHO_CURRENT_PAY_DATE", "繳款日期", "Date", "10", "", "N"},
											{"CHO_REMARK", "備註", "String", "200", "", "N"},
											{"CHO_STATUS", "狀態", "String", "1", "", "N"},
											{"CHO_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"CHO_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_STM_STATEMENT = {
											{"STM_ID", "結單編號", "Integer", "8", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"PER_ID", "用戶編號", "Integer", "6", "", "Y"},
											{"STM_DATE", "結單日", "Date", "10", "", "Y"},
											{"CHI_ID", "項目編號", "Integer", "6", "", "Y"},
											{"STM_SEQ", "序號", "Integer", "2", "", "N"},
											{"STM_START_DATE", "開始/入帳日", "Date", "10", "", "Y"},
											{"STM_END_DATE", "結束日期", "Date", "10", "", "N"},
											{"STM_QUANTITY", "數量", "Integer", "6", "", "N"},
											{"STM_UNIT_PRICE", "單價", "BigDecimal", "11", "", "N"},
											{"STM_AMOUNT", "金額", "BigDecimal", "11", "", "Y"},
											{"STM_PDF_ID", "收據編號", "String", "20", "", "N"},
											{"STM_STATUS", "狀態", "String", "1", "", "N"},
											{"STM_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"STM_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};

	public static final String[][] EM_ACC_BALANCE   = {
											{"PER_ID", "用戶編號", "Integer", "6", "", "N"},
											{"ORG_ID", "院舍編號", "Integer", "4", "", "Y"},
											{"ACC_UPD_DATE", "戶口更新日期", "Date", "10", "", "N"},
											{"ACC_DEPOSIT", "戶口按金", "BigDecimal", "11", "", "N"},
											{"ACC_BALANCE", "戶口結餘", "BigDecimal", "11", "", "Y"},
											{"ACC_LAST_BALANCE", "上月戶口結餘", "BigDecimal", "11", "", "N"},
											{"ACC_STATUS", "狀態", "String", "1", "", "Y"},
											{"ACC_MOD_BY", "修改人員", "String", "50", "", "N"},
											{"ACC_MOD_DATE", "修改日期", "String", "10", "", "N"}
											};
	
	public static final String FUNC_ENQ = "00";
	public static final String FUNC_ADD = "01";
	public static final String FUNC_MOD = "02";
	public static final String FUNC_DEL = "03";
	public static final String FUNC_ADD_SUB = "04";
	public static final String FUNC_MOD_SUB = "05";
	public static final String FUNC_DEL_SUB = "06";
	
}
