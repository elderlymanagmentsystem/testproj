package ems.module;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ems.bean.AccGrpBean;
import ems.bean.BedBean;
import ems.bean.CitemBean;
import ems.bean.CorgBean;
import ems.bean.LivBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.StmtBean;
import ems.bean.TransBean;
import ems.bean.CperBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.AccDB;
import ems.db.BedDB;
import ems.db.EmsDB;
import ems.db.OrgDB;
import ems.db.PatDB;
import ems.db.PerDB;
import ems.db.UserDB;
import ems.util.DataTypeUtil;
import ems.util.EmsCommonUtil;

public class PatModule {

	public boolean performEnqPatDetail(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		patDB.performEnqPatDetail(patGrpBean, userBean);
		patDB.performEnqCperDetail(patGrpBean, userBean);
		patDB.performEnqCorgDetail(patGrpBean, userBean);
		patDB.performEnqAccBalance(patGrpBean, userBean);
		patDB.performEnqStmtDetail(patGrpBean, userBean);

		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performEnqPatList(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		PerDB perDB = new PerDB();
		patGrpBean.setZoneBeanList(new ArrayList<ZoneBean>());
		patGrpBean.setPatBeanList(new ArrayList<PatBean>());

		if(patGrpBean.getEnqPatName()!=null && patGrpBean.getEnqPatName().length()>0) {
			patDB.performEnqPatList(patGrpBean, userBean);
		}
		
		patDB.performEnqZoneList(patGrpBean, userBean);
		patDB.performEnqBankList(patGrpBean, userBean);
		patGrpBean.getResGrpBean().setEnqStatus("Y");
		perDB.performEnqResList(patGrpBean.getResGrpBean(), userBean);
		patGrpBean.getQuoGrpBean().setEnqStatus("Y");
		perDB.performEnqQuoteList(patGrpBean.getQuoGrpBean(), userBean);
		
			
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdatePat(PatGrpBean patGrpBean, UserBean userBean, boolean hasImageUpload) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		PerDB perDB = new PerDB();
		
		patGrpBean.setOrgId(userBean.getAccOrgId());
		patGrpBean.getField("PER_STATUS").setValue("Y");
		patGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
		if(hasImageUpload) {
			patGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+patGrpBean.getOrgId()+"-"+patGrpBean.getPerId()+".jpg");
		}
		patGrpBean.getField("PAT_STATUS").setValue("Y");
		patGrpBean.getField("PAT_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getPerId()==null || patGrpBean.getPerId().length()==0) {
			patGrpBean.setPerId(patDB.getNextPerId(userBean.getOrgId()));
			patDB.performAddPer(patGrpBean, userBean);
		}else {
			patDB.performModPer(patGrpBean, userBean);
		}
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getPatId()==null || patGrpBean.getPatId().length()==0) {
				patGrpBean.setPatId(patDB.getNextPatId(userBean.getOrgId()));
				patDB.performAddPat(patGrpBean, userBean);
			}else {
				patDB.performModPat(patGrpBean, userBean);
			}
		}
		
		if(patGrpBean.getLivBeanList().size()>0) {
			LivBean livBean = patGrpBean.getLivBeanList().get(0);
			livBean.setOrgId(userBean.getAccOrgId());
			livBean.setPatId(patGrpBean.getPatId());
			livBean.getField("LIV_STATUS").setValue("Y");
			livBean.getField("LIV_MOD_BY").setValue(userBean.getUserId());
			
			TransBean transBean = patGrpBean.getTransBean();
			transBean.setOrgId(userBean.getAccOrgId());
			transBean.setPerId(patGrpBean.getPerId());
			transBean.getField("TRA_STATUS").setValue("Y");
			transBean.getField("TRA_MOD_BY").setValue(userBean.getUserId());
			
			if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
				if(livBean.getBedId()!=null && livBean.getZoneId()!=null && livBean.getBedId().length()>0 && livBean.getZoneId().length()>0) {
					if(livBean.getLivId()==null || livBean.getLivId().length()==0) {
						livBean.setLivId(patDB.getNextLivId(userBean.getOrgId()));
						transBean.getField("LIV_ID").setFormValue(livBean.getLivId());
						patDB.performAddToBed(patGrpBean, userBean);
						
						if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
							if(patGrpBean.getQuoGrpBean()!=null && patGrpBean.getQuoBeanList().size()>0 && (patGrpBean.getQuoBeanList().get(0)).getQuoId()!=null && (patGrpBean.getQuoBeanList().get(0)).getQuoId().length() > 0) {
								perDB.performQuoToLiv(patGrpBean, userBean);
							}
						}
						if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
							if(patGrpBean.getResGrpBean()!=null && patGrpBean.getResBeanList().size()>0 && (patGrpBean.getResBeanList().get(0)).getResId()!=null && (patGrpBean.getResBeanList().get(0)).getResId().length() > 0) {
								perDB.performResToLiv(patGrpBean, userBean);
							}
						}
						
					}else {
						transBean.getField("LIV_ID").setFormValue(livBean.getLivId());
						patDB.performChangeBed(patGrpBean, userBean);
					}

					if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
						if(transBean.getField("TRA_AMOUNT").getFormValue().length()>0 && ((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).intValue()!=0)
							 patDB.performDeposit(patGrpBean, userBean);
					}
				
				}
			}
		}
		
		patDB.performCleanPco(patGrpBean, userBean);
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getPcoBeanList().size()>0) {
				for(int i=0;i<patGrpBean.getPcoBeanList().size();i++) {
					PerBean pcoPerBean = patGrpBean.getPcoBeanList().get(i).getPerBean();
	
					if(pcoPerBean.getField("PER_CHI_NAME").getFormValue().length()>0 && pcoPerBean.getField("PER_TEL").getFormValue().length()>0) {
						patDB.getPerBeanByNameTel(pcoPerBean);
						pcoPerBean.getField("PER_NATURE").setValue("C");
						pcoPerBean.getField("PER_STATUS").setValue("Y");
						pcoPerBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
	
						if(pcoPerBean.getPerId()==null || pcoPerBean.getPerId().length()==0) {
							pcoPerBean.setPerId(patDB.getNextPerId(pcoPerBean.getOrgId()));
							patDB.performAddPcoPer(pcoPerBean, userBean);
						}else {
							patDB.performModPcoPer(pcoPerBean, userBean);
						}
						
						if(pcoPerBean.getMsg().length()>0) {
							patGrpBean.setMsg(pcoPerBean.getMsg());
						}else {
							PcoBean pcoBean = patGrpBean.getPcoBeanList().get(i);
							pcoBean.getField("PER_ID").setFormValue(patGrpBean.getPerId());
							pcoBean.getField("PCO_PER_ID").setFormValue(pcoPerBean.getField("PER_ID").getFormValue());
							pcoBean.getField("PCO_STATUS").setValue("Y");
							pcoBean.getField("PCO_MOD_BY").setValue(userBean.getUserId());
	
							patDB.performAddPco(pcoBean, userBean);
							if(pcoBean.getMsg().length()>0) {
								patGrpBean.setMsg(pcoBean.getMsg());
							}
						}
					}
				}
			}
		}
		
//Retrieve new Pat List
		patDB.performEnqZoneList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		

	
	public boolean performInactLiv(PatGrpBean patGrpBean, UserBean userBean, boolean hasImageUpload) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if((patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) && patGrpBean.getLivBeanList().size()>0) 
				patDB.performInactLiv(patGrpBean, userBean);
		}
		

//Retrieve new Pat List
		patDB.performEnqZoneList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}			
	
	public boolean performEnqCperList(PatGrpBean patGrpBean, UserBean userBean) {
		AccDB accDB = new AccDB();
		PatDB patDB = new PatDB();
		
		if(patGrpBean.getEnqLivStatus() == null || patGrpBean.getEnqLivStatus().length() == 0)
			patGrpBean.setEnqLivStatus("Y");
		patDB.performEnqPatList(patGrpBean, userBean);
		patDB.performEnqCperList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdateCper(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		AccDB accDB = new AccDB();

/*		
		patGrpBean.getAccGrpBean().setOrgId(userBean.getAccOrgId());
		patGrpBean.getAccGrpBean().getField("CHC_STATUS").setValue("Y");
		patGrpBean.getAccGrpBean().getField("CHC_MOD_BY").setValue(userBean.getUserId());
		patGrpBean.getAccGrpBean().getField("CHI_STATUS").setValue("Y");
		patGrpBean.getAccGrpBean().getField("CHI_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getAccGrpBean().getField("CHC_ID").getFormValue()==null || patGrpBean.getAccGrpBean().getField("CHC_ID").getFormValue().length()==0) {
			patGrpBean.getAccGrpBean().getField("CHC_ID").setFormValue(accDB.getNextCitemCatId(userBean.getOrgId()));
			accDB.performAddCitemCat(patGrpBean.getAccGrpBean(), userBean);
		}

		if(patGrpBean.getAccGrpBean().getCitemId()==null || patGrpBean.getAccGrpBean().getCitemId().length()==0) {
			patGrpBean.getAccGrpBean().setCitemId(accDB.getNextCitemId(userBean.getOrgId()));
			accDB.performAddCitem(patGrpBean.getAccGrpBean(), userBean);
			patGrpBean.getCorgId().setCitemId(patGrpBean.getAccGrpBean().getCitemId());
		}
*/
		patGrpBean.getCperBean().setOrgId(userBean.getAccOrgId());
		patGrpBean.getCperBean().getField("CHP_STATUS").setValue("Y");
		patGrpBean.getCperBean().getField("CHP_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getCperBean().getField("CHP_ID").getFormValue()==null || patGrpBean.getCperBean().getField("CHP_ID").getFormValue().length()==0) {
			patGrpBean.getCperBean().getField("CHP_ID").setFormValue(patDB.getNextCperId(userBean.getOrgId()));
			patDB.performAddCper(patGrpBean, userBean);
		}else {
			patDB.performModCper(patGrpBean, userBean);
		}


		
//Retrieve new Cper List
		patDB.performEnqPatList(patGrpBean, userBean);
		patDB.performEnqCperList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
		
	}		

	
	public boolean performInactCper(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		AccDB accDB = new AccDB();
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getCperBean().getCperId()!=null && patGrpBean.getCperBean().getCperId().length()>0 
					&& patGrpBean.getCperBean().getPerId()!=null && patGrpBean.getCperBean().getPerId().length()>0) {
				patDB.performInactCper(patGrpBean, userBean);
			}
		}
		

//Retrieve new Cper List
		patDB.performEnqPatList(patGrpBean, userBean);
		patDB.performEnqCperList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}			
	
	public boolean performEnqCorgList(PatGrpBean patGrpBean, UserBean userBean) {
		AccDB accDB = new AccDB();
		PatDB patDB = new PatDB();
		
		patDB.performEnqCorgList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		patDB.performEnqPatList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddOrUpdateCorg(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		AccDB accDB = new AccDB();

/*		
		patGrpBean.getAccGrpBean().setOrgId(userBean.getAccOrgId());
		patGrpBean.getAccGrpBean().getField("CHC_STATUS").setValue("Y");
		patGrpBean.getAccGrpBean().getField("CHC_MOD_BY").setValue(userBean.getUserId());
		patGrpBean.getAccGrpBean().getField("CHI_STATUS").setValue("Y");
		patGrpBean.getAccGrpBean().getField("CHI_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getAccGrpBean().getField("CHC_ID").getFormValue()==null || patGrpBean.getAccGrpBean().getField("CHC_ID").getFormValue().length()==0) {
			patGrpBean.getAccGrpBean().getField("CHC_ID").setFormValue(accDB.getNextCitemCatId(userBean.getOrgId()));
			accDB.performAddCitemCat(patGrpBean.getAccGrpBean(), userBean);
		}

		if(patGrpBean.getAccGrpBean().getCitemId()==null || patGrpBean.getAccGrpBean().getCitemId().length()==0) {
			patGrpBean.getAccGrpBean().setCitemId(accDB.getNextCitemId(userBean.getOrgId()));
			accDB.performAddCitem(patGrpBean.getAccGrpBean(), userBean);
			patGrpBean.getCperBean().setCitemId(patGrpBean.getAccGrpBean().getCitemId());
		}
*/
		patGrpBean.getCorgBean().setOrgId(userBean.getAccOrgId());
		patGrpBean.getCorgBean().getField("CHO_STATUS").setValue("Y");
		patGrpBean.getCorgBean().getField("CHO_MOD_BY").setValue(userBean.getUserId());

		
		if(patGrpBean.getCorgBean().getField("CHO_ID").getFormValue()==null || patGrpBean.getCorgBean().getField("CHO_ID").getFormValue().length()==0) {
			patGrpBean.getCorgBean().getField("CHO_ID").setFormValue(patDB.getNextCorgId(userBean.getOrgId()));
			patDB.performAddCorg(patGrpBean, userBean);
		}else {
			patDB.performDelCorg(patGrpBean, userBean);
			patDB.performAddCorg(patGrpBean, userBean);
		}


		
//Retrieve new Corg List
		patDB.performEnqCorgList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		patDB.performEnqPatList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
		
	}		

	
	public boolean performInactCorg(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		AccDB accDB = new AccDB();
		
		if(patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0) {
			if(patGrpBean.getCorgBean().getCorgId()!=null && patGrpBean.getCorgBean().getCorgId().length()>0) {
				patDB.performInactCorg(patGrpBean, userBean);
			}
		}
		

//Retrieve new Cper List
		patDB.performEnqCorgList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}			
	
	public boolean performUpdateStmt(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		patDB.performEnqCperDetail(patGrpBean, userBean);
		patDB.performEnqCorgDetail(patGrpBean, userBean);
		patDB.performEnqAccBalance(patGrpBean, userBean);

		String stmtId = patDB.getNextStmtId(userBean.getAccOrgId());
		int stmtSeq = 1;
		
		Calendar calendar = Calendar.getInstance();
		java.sql.Date stmtDate = new java.sql.Date(calendar.getTime().getTime());
		String stmtBal = "0";

		java.util.Date currDate = new java.util.Date(calendar.getTime().getTime());
		DateFormat dayFormat = new SimpleDateFormat("dd");
		boolean payNextMonth = true;

		BigDecimal lastAccBal = (BigDecimal)patGrpBean.getAccBalBean().getField("ACC_LAST_BALANCE").getValue();
		if(lastAccBal!=null && lastAccBal.doubleValue()<0) {
			BigDecimal intRate = (BigDecimal)userBean.getOrgBean().getField("ORG_INT_RATE").getValue();
			if(intRate!=null && intRate.doubleValue() >0) {
				StmtBean stmtBean = new StmtBean();
				stmtBean.setStmtId(stmtId);
				stmtBean.setOrgId(userBean.getAccOrgId());
				stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
				stmtBean.setPerId(patGrpBean.getPerId());
				stmtBean.getField("STM_DATE").setValue(stmtDate);
				stmtBean.getField("CHI_ID").setFormValue("100001");
				
				stmtBean.getField("STM_QUANTITY").setFormValue("");
				stmtBean.getField("STM_UNIT_PRICE").setFormValue("");
				stmtBean.getField("STM_START_DATE").setValue(stmtDate);
				stmtBean.getField("STM_END_DATE").setFormValue("");
				stmtBean.getField("STM_STATUS").setFormValue("Y");
				stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
				stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract((lastAccBal.multiply(intRate).divide(new BigDecimal("100"), 1, RoundingMode.HALF_UP)))));
				stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));

				patGrpBean.addStmtBeanList(stmtBean);
				
			}
			BigDecimal charge = (BigDecimal)userBean.getOrgBean().getField("ORG_CHARGE").getValue();
			if(charge!=null && charge.doubleValue() >0) {
				StmtBean stmtBean = new StmtBean();
				stmtBean.setStmtId(stmtId);
				stmtBean.setOrgId(userBean.getAccOrgId());
				stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
				stmtBean.setPerId(patGrpBean.getPerId());
				stmtBean.getField("STM_DATE").setValue(stmtDate);
				stmtBean.getField("CHI_ID").setFormValue("100002");
				
				stmtBean.getField("STM_QUANTITY").setFormValue("");
				stmtBean.getField("STM_UNIT_PRICE").setFormValue("");
				stmtBean.getField("STM_START_DATE").setValue(stmtDate);
				stmtBean.getField("STM_END_DATE").setFormValue("");
				stmtBean.getField("STM_STATUS").setFormValue("Y");
				stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
				stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt(charge));
				stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));

				patGrpBean.addStmtBeanList(stmtBean);
				
			}
		}
		
		
		for(int i=0;i<patGrpBean.getCperBeanList().size();i++) {
			CperBean cperBean = patGrpBean.getCperBeanList().get(i);
			
			java.util.Date itemStartDate = null;
			if(cperBean.getField("CHP_START_DATE").getValue() != null)
				itemStartDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_START_DATE").getValue()).getTime());
			java.util.Date itemEndDate = null;
			if(cperBean.getField("CHP_END_DATE").getValue() != null)
				itemEndDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_END_DATE").getValue()).getTime());
			java.util.Date currPayDate = null;
			if(cperBean.getField("CHP_CURRENT_PAY_DATE").getValue() != null)
				currPayDate = new java.util.Date(((java.sql.Date)cperBean.getField("CHP_CURRENT_PAY_DATE").getValue()).getTime());
			
			java.util.Date startDate = null;
			java.util.Date endDate = null;
			
			Calendar startCal = Calendar.getInstance();
			Calendar endCal = Calendar.getInstance();
			if(cperBean.getField("CHP_NATURE").getFormValue().equals("M")) {
				if(currPayDate !=null) {
					
					startCal.setTime(currPayDate);
					startCal.add(Calendar.DATE, 1);
					startDate = startCal.getTime();
					endCal.setTime(currPayDate);
					
				}else {
					startCal.setTime(itemStartDate);
					startDate = itemStartDate;
					endCal.setTime(currDate);
				}
				
				if(payNextMonth) {
					endCal.add(Calendar.MONTH, 1);
				}
				
				if(itemEndDate!= null) {
					Calendar itemEndCal = Calendar.getInstance();
					itemEndCal.setTime(itemEndDate);
					if(endCal.getTime().getTime() > itemEndCal.getTime().getTime())
					endCal.setTime(itemEndDate);
				} 

				if(itemEndDate!=null && currPayDate!=null && itemEndDate.getTime()<currPayDate.getTime()) {
					startCal.add(Calendar.DATE, -1);
					endCal.add(Calendar.DATE, +1);
					while(endCal.get(Calendar.YEAR) < startCal.get(Calendar.YEAR) || (endCal.get(Calendar.YEAR) == startCal.get(Calendar.YEAR) && endCal.get(Calendar.MONTH) <= startCal.get(Calendar.MONTH))) {
						startDate = startCal.getTime();
						startCal.set(Calendar.DATE, startCal.getActualMinimum(Calendar.DATE));
						endDate = startCal.getTime();
						if(itemEndDate!= null && endDate.getTime() < itemEndDate.getTime()+(24 * 60 * 60 * 1000))
							endDate.setTime(itemEndDate.getTime()+(24 * 60 * 60 * 1000));
						
						StmtBean stmtBean = new StmtBean();
						stmtBean.setStmtId(stmtId);
						stmtBean.setOrgId(userBean.getAccOrgId());
						stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
						stmtBean.setPerId(patGrpBean.getPerId());
						stmtBean.getField("STM_DATE").setValue(stmtDate);
						stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHI_ID").getFormValue());
						
						stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_QUANTITY").getFormValue());
						stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_UNIT_PRICE").getFormValue());
						stmtBean.getField("STM_START_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						stmtBean.getField("STM_END_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						stmtBean.getField("STM_STATUS").setFormValue("Y");
						stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
						
						patGrpBean.addStmtBeanList(stmtBean);
						
						
						cperBean.getField("CHP_CURRENT_PAY_DATE").setValue(new java.sql.Date(endDate.getTime()-(24 * 60 * 60 * 1000)));
						
						long daysOfTheMonth = startCal.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)cperBean.getField("CHO_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));
	
						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
						startCal.add(Calendar.DATE, -1);
					}						
				}else {				
					while(endCal.get(Calendar.YEAR) > startCal.get(Calendar.YEAR) || (endCal.get(Calendar.YEAR) == startCal.get(Calendar.YEAR) && endCal.get(Calendar.MONTH) >= startCal.get(Calendar.MONTH))) {
						startDate = startCal.getTime();
						startCal.set(Calendar.DATE, startCal.getActualMaximum(Calendar.DATE));
						endDate = startCal.getTime();
						if(itemEndDate!= null && endDate.getTime() > itemEndDate.getTime())
							endDate = itemEndDate;
						
						StmtBean stmtBean = new StmtBean();
						stmtBean.setStmtId(stmtId);
						stmtBean.setOrgId(userBean.getAccOrgId());
						stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
						stmtBean.setPerId(patGrpBean.getPerId());
						stmtBean.getField("STM_DATE").setValue(stmtDate);
						stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHI_ID").getFormValue());
						
						stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_QUANTITY").getFormValue());
						stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_UNIT_PRICE").getFormValue());
						stmtBean.getField("STM_START_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						stmtBean.getField("STM_END_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						stmtBean.getField("STM_STATUS").setFormValue("Y");
						stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
						
						patGrpBean.addStmtBeanList(stmtBean);
						
						cperBean.getField("CHP_CURRENT_PAY_DATE").setValue(new java.sql.Date(endDate.getTime()));
						
						long daysOfTheMonth = startCal.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)cperBean.getField("CHP_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));
	
						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
						
						startCal.add(Calendar.DATE, 1);
						
					}
				}
			}else {

				StmtBean stmtBean = new StmtBean();
				stmtBean.setStmtId(stmtId);
				stmtBean.setOrgId(userBean.getAccOrgId());
				stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
				stmtBean.setPerId(patGrpBean.getPerId());
				stmtBean.getField("STM_DATE").setValue(stmtDate);
				stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHI_ID").getFormValue());
				
				stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_QUANTITY").getFormValue());
				stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_UNIT_PRICE").getFormValue());
				stmtBean.getField("STM_START_DATE").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_START_DATE").getFormValue());
				stmtBean.getField("STM_END_DATE").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_END_DATE").getFormValue());
				stmtBean.getField("STM_STATUS").setFormValue("Y");
				stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
				stmtBean.getField("STM_AMOUNT").setFormValue(patGrpBean.getCperBeanList().get(i).getField("CHP_AMOUNT").getFormValue());
				patGrpBean.addStmtBeanList(stmtBean);
				stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
				
			}
		}
		
		BigDecimal accDeposit = (BigDecimal)patGrpBean.getAccBalBean().getField("ACC_DEPOSIT").getValue();
		if(accDeposit.compareTo(new BigDecimal("0"))>0) {
			
			StmtBean stmtBean = new StmtBean();
			stmtBean.setStmtId(stmtId);
			stmtBean.setOrgId(userBean.getAccOrgId());
			stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
			stmtBean.setPerId(patGrpBean.getPerId());
			stmtBean.getField("STM_DATE").setValue(stmtDate);
			stmtBean.getField("CHI_ID").setFormValue("100003");
			
			stmtBean.getField("STM_QUANTITY").setFormValue("");
			stmtBean.getField("STM_UNIT_PRICE").setFormValue("");
			stmtBean.getField("STM_START_DATE").setValue(stmtDate);
			stmtBean.getField("STM_END_DATE").setValue(stmtDate);
			stmtBean.getField("STM_STATUS").setFormValue("Y");
			stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
			stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt(new BigDecimal("0").subtract(accDeposit)));
			patGrpBean.addStmtBeanList(stmtBean);
			stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
		}
		
		for(int i=0;i<patGrpBean.getCorgBeanList().size();i++) {
			CorgBean corgBean = patGrpBean.getCorgBeanList().get(i);
			
			java.util.Date itemStartDate = null;
			if(corgBean.getField("CHO_START_DATE").getValue() != null)
				itemStartDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_START_DATE").getValue()).getTime());
			java.util.Date itemEndDate = null;
			if(corgBean.getField("CHO_END_DATE").getValue() != null)
				itemEndDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_END_DATE").getValue()).getTime());
			java.util.Date currPayDate = null;
			if(corgBean.getField("CHO_CURRENT_PAY_DATE").getValue() != null)
				currPayDate = new java.util.Date(((java.sql.Date)corgBean.getField("CHO_CURRENT_PAY_DATE").getValue()).getTime());
			
			java.util.Date startDate = null;
			java.util.Date endDate = null;
			
			Calendar startCal = Calendar.getInstance();
			Calendar endCal = Calendar.getInstance();
			if(corgBean.getField("CHO_NATURE").getFormValue().equals("M")) {
				if(currPayDate !=null) {
					
					startCal.setTime(currPayDate);
					startCal.add(Calendar.DATE, 1);
					startDate = startCal.getTime();
					endCal.setTime(currPayDate);
					
				}else {
					startCal.setTime(itemStartDate);
					startDate = itemStartDate;
					endCal.setTime(currDate);
				}
				
				if(payNextMonth) {
					endCal.add(Calendar.MONTH, 1);
				}
				
				if(itemEndDate!= null) {
					Calendar itemEndCal = Calendar.getInstance();
					itemEndCal.setTime(itemEndDate);
					if(endCal.getTime().getTime() > itemEndCal.getTime().getTime())
					endCal.setTime(itemEndDate);
				} 
				
				if(itemEndDate!=null && currPayDate!=null && itemEndDate.getTime()<currPayDate.getTime()) {
					startCal.add(Calendar.DATE, -1);
					endCal.add(Calendar.DATE, +1);
					while(endCal.get(Calendar.YEAR) < startCal.get(Calendar.YEAR) || (endCal.get(Calendar.YEAR) == startCal.get(Calendar.YEAR) && endCal.get(Calendar.MONTH) <= startCal.get(Calendar.MONTH))) {
						startDate = startCal.getTime();
						startCal.set(Calendar.DATE, startCal.getActualMinimum(Calendar.DATE));
						endDate = startCal.getTime();
						if(itemEndDate!= null && endDate.getTime() < itemEndDate.getTime()+(24 * 60 * 60 * 1000))
							endDate.setTime(itemEndDate.getTime()+(24 * 60 * 60 * 1000));
						
						StmtBean stmtBean = new StmtBean();
						stmtBean.setStmtId(stmtId);
						stmtBean.setOrgId(userBean.getAccOrgId());
						stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
						stmtBean.setPerId(patGrpBean.getPerId());
						stmtBean.getField("STM_DATE").setValue(stmtDate);
						stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHI_ID").getFormValue());
						
						stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_QUANTITY").getFormValue());
						stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_UNIT_PRICE").getFormValue());
						stmtBean.getField("STM_START_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						stmtBean.getField("STM_END_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						stmtBean.getField("STM_STATUS").setFormValue("Y");
						stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
						
						patGrpBean.addStmtBeanList(stmtBean);
						
						
						corgBean.getField("CHO_CURRENT_PAY_DATE").setValue(new java.sql.Date(endDate.getTime()-(24 * 60 * 60 * 1000)));
						
						long daysOfTheMonth = startCal.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)corgBean.getField("CHO_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));
	
						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
						startCal.add(Calendar.DATE, -1);
					}						
				}else {
				
					while(endCal.get(Calendar.YEAR) > startCal.get(Calendar.YEAR) || (endCal.get(Calendar.YEAR) == startCal.get(Calendar.YEAR) && endCal.get(Calendar.MONTH) >= startCal.get(Calendar.MONTH))) {
						startDate = startCal.getTime();
						startCal.set(Calendar.DATE, startCal.getActualMaximum(Calendar.DATE));
						endDate = startCal.getTime();
						if(itemEndDate!= null && endDate.getTime() > itemEndDate.getTime())
							endDate = itemEndDate;
						
						StmtBean stmtBean = new StmtBean();
						stmtBean.setStmtId(stmtId);
						stmtBean.setOrgId(userBean.getAccOrgId());
						stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
						stmtBean.setPerId(patGrpBean.getPerId());
						stmtBean.getField("STM_DATE").setValue(stmtDate);
						stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHI_ID").getFormValue());
						
						stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_QUANTITY").getFormValue());
						stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_UNIT_PRICE").getFormValue());
						stmtBean.getField("STM_START_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(startDate.getTime())));
						stmtBean.getField("STM_END_DATE").setFormValue(DataTypeUtil.beanDate2FormDate(new java.sql.Date(endDate.getTime())));
						stmtBean.getField("STM_STATUS").setFormValue("Y");
						stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
						
						patGrpBean.addStmtBeanList(stmtBean);
						
						corgBean.getField("CHO_CURRENT_PAY_DATE").setValue(new java.sql.Date(endDate.getTime()));
						
						long daysOfTheMonth = startCal.getActualMaximum(Calendar.DAY_OF_MONTH); 
						long days = (endDate.getTime() - startDate.getTime()+(24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000);
						stmtBean.getField("STM_AMOUNT").setFormValue(DataTypeUtil.beanAmt2FormAmt((((BigDecimal)corgBean.getField("CHO_AMOUNT").getValue()).multiply(new BigDecimal(days)).divide(new BigDecimal(daysOfTheMonth), 1, RoundingMode.HALF_UP))));
	
						stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
						startCal.add(Calendar.DATE, 1);
						
					}
				}
			}else {

				StmtBean stmtBean = new StmtBean();
				stmtBean.setStmtId(stmtId);
				stmtBean.setOrgId(userBean.getAccOrgId());
				stmtBean.getField("STM_SEQ").setValue((new Integer(stmtSeq++)));
				stmtBean.setPerId(patGrpBean.getPerId());
				stmtBean.getField("STM_DATE").setValue(stmtDate);
				stmtBean.getField("CHI_ID").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHI_ID").getFormValue());
				
				stmtBean.getField("STM_QUANTITY").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_QUANTITY").getFormValue());
				stmtBean.getField("STM_UNIT_PRICE").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_UNIT_PRICE").getFormValue());
				stmtBean.getField("STM_START_DATE").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_START_DATE").getFormValue());
				stmtBean.getField("STM_END_DATE").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_END_DATE").getFormValue());
				stmtBean.getField("STM_STATUS").setFormValue("Y");
				stmtBean.getField("STM_MOD_BY").setFormValue(userBean.getUserId());
				stmtBean.getField("STM_AMOUNT").setFormValue(patGrpBean.getCorgBeanList().get(i).getField("CHO_AMOUNT").getFormValue());
				patGrpBean.addStmtBeanList(stmtBean);
				stmtBal = DataTypeUtil.beanAmt2FormAmt(new BigDecimal(stmtBal).subtract(new BigDecimal(stmtBean.getField("STM_AMOUNT").getFormValue())));
				
			}
		}		
		
		patDB.performAddStmt(patGrpBean, userBean);
		
		
		TransBean transBean = patGrpBean.getTransBean();
		transBean.setTransId(patDB.getNextTransId(userBean.getAccOrgId()));
		transBean.setOrgId(userBean.getAccOrgId());
		transBean.setPerId(patGrpBean.getPerId());
		transBean.getField("STM_ID").setFormValue(stmtId);
		transBean.getField("TRA_NAME").setFormValue("月結單");
		transBean.getField("TRA_TYPE").setFormValue("S");
		transBean.getField("TRA_DATE").setValue(stmtDate);
		transBean.getField("TRA_AMOUNT").setFormValue(stmtBal);
		
		transBean.getField("TRA_STATUS").setValue("Y");
		transBean.getField("TRA_MOD_BY").setValue(userBean.getUserId());
		
		patGrpBean.setTransBean(transBean);
		
		patDB.performAddTrans(patGrpBean, userBean);
		
		
		AccDB accDB = new AccDB();

//Retrieve new Cper List
		patDB.performEnqPatList(patGrpBean, userBean);
		patDB.performEnqCperList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}			

	public boolean performAddTrans(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		patDB.performEnqCperDetail(patGrpBean, userBean);
		patDB.performEnqCorgDetail(patGrpBean, userBean);

		TransBean transBean = patGrpBean.getTransBean();
		transBean.setTransId(patDB.getNextTransId(userBean.getAccOrgId()));
		transBean.setOrgId(userBean.getAccOrgId());
		transBean.setPerId(patGrpBean.getPerId());
		transBean.getField("TRA_NAME").setFormValue("付款");
		transBean.getField("TRA_TYPE").setFormValue("S");
		patGrpBean.getTransBean().getField("TRA_STATUS").setValue("Y");
		patGrpBean.getTransBean().getField("TRA_MOD_BY").setValue(userBean.getUserId());
		patDB.performAddTrans(patGrpBean, userBean);

		AccDB accDB = new AccDB();
		patDB.performEnqPatList(patGrpBean, userBean);
		patDB.performEnqCperList(patGrpBean, userBean);
		accDB.performEnqCitemList(patGrpBean.getAccGrpBean(), userBean);
		accDB.performEnqCitemCatList(patGrpBean.getAccGrpBean(), userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}
}
