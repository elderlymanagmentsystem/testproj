package ems.sch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import ems.util.DBUtil;

public class MonthyJob implements Runnable {
@Override
	public void run() {
    	
    	Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<String> stmtOrg = new ArrayList<String>();
		
		try {
			conn = DBUtil.getDataSource().getConnection();		
		
			String sql = "SELECT ORG_ID, ORG_CUTOFF_DATE, ORG_STM_DATE FROM EM_ORG_ORGANIZATION";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next()){
				Calendar stmtCal = Calendar.getInstance();
				Calendar currCal = Calendar.getInstance();
				Calendar cutoffCal = Calendar.getInstance();
				String cutoffDate = rs.getString("ORG_CUTOFF_DATE");
				if(cutoffDate!=null && !cutoffDate.equals("")) {
					try {
						cutoffCal.set(currCal.get(Calendar.YEAR), currCal.get(Calendar.MONTH), (new Integer(cutoffDate)).intValue());
					}catch(Exception e) {
						cutoffCal.set(currCal.get(Calendar.YEAR), currCal.get(Calendar.MONTH), currCal.getActualMinimum(Calendar.DATE));
					}
				}
				java.sql.Date stmtDate = rs.getDate("ORG_STM_DATE");
				if(stmtDate!=null) {
					stmtCal.setTime(new java.util.Date(stmtDate.getTime()));
					if((currCal.get(Calendar.YEAR) > stmtCal.get(Calendar.YEAR) || (currCal.get(Calendar.YEAR) == stmtCal.get(Calendar.YEAR) && currCal.get(Calendar.MONTH) > stmtCal.get(Calendar.MONTH))) && currCal.getTime().compareTo(cutoffCal.getTime())>=0) {
						stmtOrg.add(rs.getString("ORG_ID"));
					}
				}else {
					if(currCal.getTime().compareTo(cutoffCal.getTime())>=0) {
						stmtOrg.add(rs.getString("ORG_ID"));
					}
				}
			}
			
			for(int i=0;i<stmtOrg.size();i++) 
				System.out.println(stmtOrg.get(i));
			
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }



	public static void main(String [] args) throws SQLException, ClassNotFoundException {
		MonthyJob hourlyJob = new MonthyJob();
		hourlyJob.run();
	}
	
}
