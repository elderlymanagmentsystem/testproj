package ems;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;

public class TestingAction extends ActionSupport {
	private UserBean userBean;
	
	public String execute()
	{
		String success=SUCCESS;
		if (userBean != null)
			System.out.println("execute" + userBean.getUserId());
		else
			System.out.println("execute null");
		return success;
	}
	
	public void validate() {
		addActionMessage("OK message 123123123123123123123123123");
		//addActionError("FAIL message");
		
		if (userBean != null)
			System.out.println("validate" + userBean.getUserId());
		else
			System.out.println("validate null");
			
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	 
}
