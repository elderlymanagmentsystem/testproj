package ems;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.UserBean;
import ems.TestingActionDB;

public class TestingAction extends ActionSupport {
	private UserBean userBean;
	
	public String execute()
	{
		/*
		TestingActionDB.testConn();
		String success=SUCCESS;
		if (userBean != null)
			System.out.println("execute" + userBean.getUserId());
		else
			System.out.println("execute null");
		*/
		return SUCCESS;
	}
	
	public void validate() {
		//addActionMessage("OK message 1231231231231231233");
		//addActionError("FAIL message");
		/*
		if (userBean != null)
			System.out.println("validate" + userBean.getUserId());
		else
			System.out.println("validate null");
		*/
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
    
	 
}
