package ems.module;

import java.util.ArrayList;

import ems.bean.BedBean;
import ems.bean.OrgBean;
import ems.bean.PatGrpBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.db.BedDB;
import ems.db.OrgDB;
import ems.db.PatDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class PatModule {

	public boolean performEnqPatDetail(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		patDB.performEnqPatDetail(patGrpBean, userBean);

		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performEnqPatList(PatGrpBean patGrpBean, UserBean userBean) {
		PatDB patDB = new PatDB();
		if(patGrpBean.getEnqPatName()!=null && patGrpBean.getEnqPatName().length()>0) {
			patDB.performEnqPatList(patGrpBean, userBean);
		}else {
			patDB.performEnqZoneList(patGrpBean, userBean);
		}

		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performAddPat(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		patGrpBean.setPatId(patDB.getNextPatId(userBean.getOrgId()));
		patGrpBean.getField("PAT_MOD_BY").setValue(userBean.getUserId());
		patGrpBean.getField("PAT_STATUS").setValue("Y");
		
		patDB.performAddPat(patGrpBean, userBean);
		if(patGrpBean.getMsg()==null && patGrpBean.getMsg().length()==0)
			patGrpBean = new PatGrpBean();

//Retrieve new Pat List
		patDB.performEnqPatList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}		
	
	public boolean performModPat(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		patGrpBean.getField("PAT_MOD_BY").setValue(userBean.getUserId());
		patGrpBean.getField("PAT_STATUS").setValue("Y");
		patDB.performModPer(patGrpBean, userBean);
		if(patGrpBean.getMsg()==null && patGrpBean.getMsg().length()==0)
			patGrpBean = new PatGrpBean();
		
//Retrieve new Pat List
		patDB.performEnqPatList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	
	public boolean performExitPat(PatGrpBean patGrpBean, UserBean userBean) {
		patGrpBean.setMsg("");

//Update DB
		PatDB patDB = new PatDB();
		patDB.performModPer(patGrpBean, userBean);
		if(patGrpBean.getMsg()==null && patGrpBean.getMsg().length()==0)
			patGrpBean = new PatGrpBean();
		
//Retrieve new Pat List
patDB.performEnqPatList(patGrpBean, userBean);
		
		if (patGrpBean!=null && (patGrpBean.getMsg()==null || patGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
}
