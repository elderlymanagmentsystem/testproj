package ems.bean;

import ems.db.EmsDB;

public class PcoBean extends BasicBean {
	
	private PerBean perBean = new PerBean();
		
	public PcoBean() {
		for(int i=0; i<EmsDB.EM_PCO_PERSONAL_CONTACT.length;i++) {
			fields.add(new Field(EmsDB.EM_PCO_PERSONAL_CONTACT[i]));
		}
	}
	
	public String getOrgId() {
		return getField("ORG_ID").getFormValue();
	}
	public void setOrgId(String orgId) {
		getField("ORG_ID").setFormValue(orgId);
	}

	public String getPerId() {
		return getField("PER_ID").getFormValue();
	}
	public void setPerId(String perId) {
		getField("PER_ID").setFormValue(perId);
	}

	public String getPcoPerId() {
		return getField("PCO_PER_ID").getFormValue();
	}
	public void setPcoPerId(String pcoPerId) {
		getField("PCO_PER_ID").setFormValue(pcoPerId);
	}

	public PerBean getPerBean() {
		return perBean;
	}

	public void setPerBean(PerBean perBean) {
		this.perBean = perBean;
	}

}
