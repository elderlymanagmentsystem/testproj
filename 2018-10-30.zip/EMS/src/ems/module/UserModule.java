package ems.module;

import java.util.ArrayList;

import ems.bean.OrgBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneGrpBean;
import ems.db.OrgDB;
import ems.db.UserDB;
import ems.util.EmsCommonUtil;

public class UserModule {

	public boolean performLogin(UserBean userBean) {
		UserDB userDB = new UserDB();
		userBean = userDB.login(userBean);
		if (userBean!=null && userBean.getRolBean()!=null && userBean.getRolBean().getFunIdList()!=null && userBean.getRolBean().getFunIdList().size()>0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean performEnqUserGrp(UserGrpBean userGrpBean, UserBean userBean) {
		UserDB userDB = new UserDB();
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, userBean);

		return true;
	}	
	
	public boolean performAddUser(UserGrpBean userGrpBean, UserBean userBean, boolean hasImageUpload) {
		userGrpBean.setMsg("");

//Update DB
		userGrpBean.getField("USE_MOD_BY").setValue(userBean.getUserId());
		userGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());
		
		UserDB userDB = new UserDB();
		if(userDB.isUserExist(userGrpBean)) {
			userGrpBean.setMsg("用戶名稱已使用");
		}else{
			if(hasImageUpload) {
				userGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+userGrpBean.getOrgId()+"-"+userGrpBean.getPerId()+".jpg");
			}
				
			userGrpBean.setPerId(userDB.getNextPerId(userGrpBean.getOrgId()));
			userDB.performAddUser(userGrpBean);
			
		}
//Retrieve new User List
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, userBean);
		
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
	public boolean performModUser(UserGrpBean userGrpBean, UserBean userBean, boolean hasImageUpload) {
		userGrpBean.setMsg("");

//Update DB
		userGrpBean.getField("USE_MOD_BY").setValue(userBean.getUserId());
		userGrpBean.getField("PER_MOD_BY").setValue(userBean.getUserId());

		UserDB userDB = new UserDB();
		if(hasImageUpload) {
			userGrpBean.getField("PER_IMAGE_LINK").setFormValue("img"+userGrpBean.getOrgId()+"-"+userGrpBean.getPerId()+".jpg");
		}
		
		userDB.performModUser(userGrpBean);
		
//Retrieve new User List
		userGrpBean = userDB.performEnqUserGrp(userGrpBean, userBean);
		
		if (userGrpBean!=null && (userGrpBean.getMsg()==null || userGrpBean.getMsg().length()==0)) {
			return true;
		}else {
			return false;
		}
	}	
	
}
