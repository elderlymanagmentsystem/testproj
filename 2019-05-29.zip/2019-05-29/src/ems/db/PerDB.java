package ems.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import ems.bean.BedBean;
import ems.bean.FuncBean;
import ems.bean.LivBean;
import ems.bean.QuoBean;
import ems.bean.OrgBean;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.QuoGrpBean;
import ems.bean.ResBean;
import ems.bean.ResGrpBean;
import ems.bean.PcoBean;
import ems.bean.PerBean;
import ems.bean.QuoGrpBean;
import ems.bean.RolBean;
import ems.bean.TransBean;
import ems.bean.UserBean;
import ems.bean.UserGrpBean;
import ems.bean.ZoneBean;
import ems.bean.ZoneGrpBean;
import ems.util.DBUtil;
import ems.util.DataTypeUtil;
import ems.util.PDFUtil;

public class PerDB {

	public QuoGrpBean performEnqQuoteList(QuoGrpBean quoGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			quoGrpBean.setQuoteBeanList(new ArrayList<QuoBean>());

			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT QUO_ID, QUO.ORG_ID, QUO.ZON_ID, QUO.BED_ID, QUO_START_DATE, QUO_END_DATE, QUO_LIVING_FEE, QUO_NURSING_FEE, QUO_ADD_LIVING_FEE, QUO_TYPE, QUO_PDF_FILE, QUO_STATUS, QUO_MOD_BY, QUO_MOD_DATE, " + 
					"	  PER.PER_ID, PER.PER_CHI_NAME, PER.PER_ENG_NAME, PER.PER_HKID, PER.PER_GENDER, PER.PER_NBIRTH, PER.PER_LBIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_IMAGE_LINK, PER.PER_LDS_REF, PER.PER_LDS_RESULT, PER.PER_LDS_DATE, PER.PER_ASS1, PER.PER_ASS2, PER.PER_ASS2_OTH, PER.PER_ASS3, PER.PER_ASS3_OTH, PER.PER_ASS4, PER.PER_REFERAL, PER.PER_REFERAL_OTH, PER.BAN_ID, PER.PER_BANK_ACC_NO, PER.PER_BANK_ACC_NAME, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE " + 
					"	  ZON_ID, ZON_ID, ZON_NAME, ZON_STATUS, ZON_MOD_BY, ZON_MOD_DATE, " +
					"	  BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE " + 
					"	  FROM EM_QUO_RECORD QUO, EM_PER_PERSONAL_PARTICULAR PER, EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
					"	  WHERE QUO.ORG_ID = ? AND QUO.PER_ID = PER.PER_ID AND QUO.ORG_ID = PER.ORG_ID AND QUO_STATUS = ? AND PER_STATUS = 'Y' " + 
					"	  AND BED_STATUS = 'Y' AND QUO.ORG_ID = BED.ORG_ID AND QUO.ZON_ID = BED.ZON_ID AND QUO.BED_ID = BED.BED_ID " +
					"	  AND ZON_STATUS = 'Y' AND QUO.ORG_ID = ZON.ORG_ID AND QUO.ZON_ID = ZON.ZON_ID ";
					
			if(quoGrpBean.getEnqPerName()!=null && quoGrpBean.getEnqPerName().length()>0) {
				if("Q".equals(quoGrpBean.getEnqPerType()))
					sql = sql + "AND QUO.QUO_ID = ? ";
				else if("I".equals(quoGrpBean.getEnqPerType()))
					sql = sql + "AND PER.PER_HKID LIKE ? ";
				else if("N".equals(quoGrpBean.getEnqPerType())) 
					sql = sql + "AND PER_CHI_NAME LIKE ? ";
			}

			if(quoGrpBean.getEnqStartDate()!=null && quoGrpBean.getEnqStartDate().length()>0) {
				sql = sql + "AND QUO.QUO_MOD_DATE >= ? ";
			}
			
			if(quoGrpBean.getEnqEndDate()!=null && quoGrpBean.getEnqEndDate().length()>0) {
				sql = sql + "AND QUO.QUO_MOD_DATE <= ? ";
			}
			
				sql = sql + "					ORDER BY QUO_MOD_DATE DESC, QUO.QUO_ID ";
			
			pst = conn.prepareStatement(sql);

			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			if(quoGrpBean.getEnqStatus()!=null && quoGrpBean.getEnqStatus().length()>0)
				pst.setString(pos++, quoGrpBean.getEnqStatus());
			else
				pst.setString(pos++, "Y");
			
			if(quoGrpBean.getEnqPerName()!=null && quoGrpBean.getEnqPerName().length()>0) {
				if("Q".equals(quoGrpBean.getEnqPerType()))
					pst.setString(pos++, quoGrpBean.getEnqPerName());
				else if("I".equals(quoGrpBean.getEnqPerType()))
					pst.setString(pos++, "%"+quoGrpBean.getEnqPerName()+"%");
				else 
					pst.setString(pos++, "%"+quoGrpBean.getEnqPerName()+"%");
			}
			
			if(quoGrpBean.getEnqStartDate()!=null && quoGrpBean.getEnqStartDate().length()>0) {
				pst.setDate(pos++, DataTypeUtil.formDate2BeanDate(quoGrpBean.getEnqStartDate()));
			}
			
			if(quoGrpBean.getEnqEndDate()!=null && quoGrpBean.getEnqEndDate().length()>0) {
				pst.setDate(pos++, DataTypeUtil.formDate2BeanDate(quoGrpBean.getEnqEndDate()));
			}
			
			rs = pst.executeQuery();
			while(rs.next()){
				QuoBean quoBean = new QuoBean();
				for(int i=0;i<quoBean.getFields().size();i++) {
					quoBean.getFields().get(i).setFormValue(rs.getString(quoBean.getFields().get(i).getName()));
				}
				quoGrpBean.addQuoteBeanList(quoBean);
				
				PerBean perBean = quoBean.getPerBean();
				for(int i=0;i<perBean.getFields().size();i++) {
					perBean.getFields().get(i).setFormValue(rs.getString(perBean.getFields().get(i).getName()));
				}
			
				BedBean bedBean = quoBean.getBedBean();
				for(int i=0;i<bedBean.getFields().size();i++) {
					bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
				}
				bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}

	public ResGrpBean performEnqResList(ResGrpBean resGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			resGrpBean.setReserveBeanList(new ArrayList<ResBean>());

			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT RES_ID, RES.ORG_ID, RES.ZON_ID, RES.BED_ID, RES_START_DATE, RES_END_DATE, RES_LIVING_FEE, RES_NURSING_FEE, RES_ADD_LIVING_FEE, RES_TYPE, RES_PDF_FILE, RES_STATUS, RES_MOD_BY, RES_MOD_DATE, " + 
					"	  PER.PER_ID, PER.PER_CHI_NAME, PER.PER_ENG_NAME, PER.PER_HKID, PER.PER_GENDER, PER.PER_NBIRTH, PER.PER_LBIRTH, PER.PER_TEL, PER.PER_EMAIL, PER.PER_DESC, PER.PER_NATURE, PER.PER_IMAGE_LINK, PER.PER_LDS_REF, PER.PER_LDS_RESULT, PER.PER_LDS_DATE, PER.PER_ASS1, PER.PER_ASS2, PER.PER_ASS2_OTH, PER.PER_ASS3, PER.PER_ASS3_OTH, PER.PER_ASS4, PER.PER_REFERAL, PER.PER_REFERAL_OTH, PER.BAN_ID, PER.PER_BANK_ACC_NO, PER.PER_BANK_ACC_NAME, PER.PER_STATUS, PER.PER_MOD_BY, PER.PER_MOD_DATE " + 
					"	  ZON_ID, ZON_ID, ZON_NAME, ZON_STATUS, ZON_MOD_BY, ZON_MOD_DATE, " +
					"	  BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " + 
					"	  TRA_ID, LIV_ID, STM_ID, TRA_NAME, TRA_TYPE, TRA_DATE, TRA_AMOUNT, TRA_METHOD, TRA_NOTE, TRA_RECEIPT_ID, TRA_REMARK1, TRA_REMARK2, TRA_REMARK3, TRA_ACC_BAL, TRA_PDF_FILE, TRA_STATUS, TRA_MOD_BY, TRA_MOD_DATE " + 
					"	  FROM EM_RES_RECORD RES, EM_PER_PERSONAL_PARTICULAR PER, EM_BED_INFO BED, EM_ZON_ZONE ZON LEFT JOIN " +
					"	  (SELECT TRA_ID, PER_ID, ORG_ID, RES_ID, LIV_ID, STM_ID, TRA_NAME, TRA_TYPE, TRA_DATE, TRA_AMOUNT, TRA_METHOD, TRA_NOTE, TRA_RECEIPT_ID, TRA_REMARK1, TRA_REMARK2, TRA_REMARK3, TRA_ACC_BAL, TRA_PDF_FILE, TRA_STATUS, TRA_MOD_BY, TRA_MOD_DATE " +
					"     FROM EM_TRA_TRANSACTIONS) TRA ON RES.PER_ID = TRA.PER_ID AND RES.ORG_ID = TRA.ORG_ID AND RES.RES_ID = TRA.RES_ID AND TRA.TRA_TYPE = 'R' " +
					"	  WHERE RES.ORG_ID = ? AND RES.PER_ID = PER.PER_ID AND RES.ORG_ID = PER.ORG_ID AND RES_STATUS = ? AND PER_STATUS = 'Y' " + 
					"	  AND BED_STATUS = 'Y' AND RES.ORG_ID = BED.ORG_ID AND RES.ZON_ID = BED.ZON_ID AND RES.BED_ID = BED.BED_ID " +
					"	  AND ZON_STATUS = 'Y' AND RES.ORG_ID = ZON.ORG_ID AND RES.ZON_ID = ZON.ZON_ID ";
					
			if(resGrpBean.getEnqPerName()!=null && resGrpBean.getEnqPerName().length()>0) {
				if("R".equals(resGrpBean.getEnqPerType()))
					sql = sql + "AND RES.RES_ID = ? ";
				else if("I".equals(resGrpBean.getEnqPerType()))
					sql = sql + "AND PER.PER_HKID LIKE ? ";
				else if("N".equals(resGrpBean.getEnqPerType())) 
					sql = sql + "AND PER_CHI_NAME LIKE ? ";
			}

			if(resGrpBean.getEnqStartDate()!=null && resGrpBean.getEnqStartDate().length()>0) {
				sql = sql + "AND RES.RES_MOD_DATE >= ? ";
			}
			
			if(resGrpBean.getEnqEndDate()!=null && resGrpBean.getEnqEndDate().length()>0) {
				sql = sql + "AND RES.RES_MOD_DATE <= ? ";
			}
			
				sql = sql + "					ORDER BY RES_MOD_DATE DESC, RES.RES_ID ";
			
			pst = conn.prepareStatement(sql);

			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			if(resGrpBean.getEnqStatus()!=null && resGrpBean.getEnqStatus().length()>0)
				pst.setString(pos++, resGrpBean.getEnqStatus());
			else
				pst.setString(pos++, "Y");
			
			if(resGrpBean.getEnqPerName()!=null && resGrpBean.getEnqPerName().length()>0) {
				if("R".equals(resGrpBean.getEnqPerType()))
					pst.setString(pos++, resGrpBean.getEnqPerName());
				else if("I".equals(resGrpBean.getEnqPerType()))
					pst.setString(pos++, "%"+resGrpBean.getEnqPerName()+"%");
				else 
					pst.setString(pos++, "%"+resGrpBean.getEnqPerName()+"%");
			}
			
			if(resGrpBean.getEnqStartDate()!=null && resGrpBean.getEnqStartDate().length()>0) {
				pst.setDate(pos++, DataTypeUtil.formDate2BeanDate(resGrpBean.getEnqStartDate()));
			}
			
			if(resGrpBean.getEnqEndDate()!=null && resGrpBean.getEnqEndDate().length()>0) {
				pst.setDate(pos++, DataTypeUtil.formDate2BeanDate(resGrpBean.getEnqEndDate()));
			}
			
			rs = pst.executeQuery();
			while(rs.next()){
				
				
				ResBean resBean = new ResBean();
				for(int i=0;i<resBean.getFields().size();i++) {
					resBean.getFields().get(i).setFormValue(rs.getString(resBean.getFields().get(i).getName()));
				}
				if(resGrpBean.getResBean(resBean.getResId(), resBean.getOrgId())==null)
					resGrpBean.addReserveBeanList(resBean);
				else
					resBean = resGrpBean.getResBean(resBean.getResId(), resBean.getOrgId());
				
				PerBean perBean = resBean.getPerBean();
				for(int i=0;i<perBean.getFields().size();i++) {
					perBean.getFields().get(i).setFormValue(rs.getString(perBean.getFields().get(i).getName()));
				}
			
				TransBean transBean = new TransBean();
				for(int i=0;i<transBean.getFields().size();i++) {
					transBean.getFields().get(i).setFormValue(rs.getString(transBean.getFields().get(i).getName()));
				}
				perBean.addTransBeanList(transBean);

				BedBean bedBean = resBean.getBedBean();
				for(int i=0;i<bedBean.getFields().size();i++) {
					bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
				}
				bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}

	public QuoGrpBean performEnqEmptyBed(QuoGrpBean quoGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			quoGrpBean.setEmptyBedBeanList(new ArrayList<BedBean>());

			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT ZON.ORG_ID, ZON.ZON_ID, ZON.ZON_NAME, ZON.ZON_STATUS, ZON.ZON_MOD_BY, ZON.ZON_MOD_DATE, " + 
					"					BED.BED_ID, BED.BED_NAME, BED.BED_STATUS, BED.BED_MOD_BY, BED.BED_MOD_DATE " + 
					"					FROM EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
					"					WHERE NOT EXISTS (SELECT 1 FROM EM_LIV_RECORD LIV WHERE BED.ZON_ID = LIV.ZON_ID AND BED.BED_ID = LIV.BED_ID AND BED.ORG_ID = LIV.ORG_ID AND LIV.LIV_STATUS = 'Y') " + 
					"					AND BED.ORG_ID = ZON.ORG_ID AND BED.ZON_ID = ZON.ZON_ID AND ZON.ZON_STATUS = 'Y' " +
					"					AND BED.ORG_ID = ? AND BED.BED_STATUS = 'Y' " +
					"					ORDER BY ZON.ZON_ID, BED.BED_ID ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			rs = pst.executeQuery();
			while(rs.next()){
				BedBean bedBean = new BedBean();
				for(int i=0;i<bedBean.getFields().size();i++) {
					bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
				}
				quoGrpBean.addEmptyBedBeanList(bedBean);
				
				bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}


	public QuoGrpBean performEnqPerDetail(QuoGrpBean quoGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT PER_ID, ORG_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, BAN_ID, PER_BANK_ACC_NO, PER_BANK_ACC_NAME, PER_STATUS, PER_MOD_BY, PER_MOD_DATE, " + 
					"					QUO_ID, QUO_START_DATE, QUO_END_DATE, QUO_LIVING_FEE, QUO_NURSING_FEE, QUO_ADD_LIVING_FEE, QUO_TYPE, QUO_PDF_FILE, QUO_STATUS, QUO_MOD_BY, QUO_MOD_DATE, " + 
					"					ZON.ZON_NAME, BED.ZON_ID, BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " +
					"                   PCO_PER_ID, PCO_RELATION, PCO_CHI_NAME, PCO_TEL, PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE " + 
					"	  FROM EM_QUO_RECORD QUO, EM_BED_INFO BED, EM_ZON_ZONE ZON, EM_PER_PERSONAL_PARTICULAR PER LEFT JOIN " +
					"			(SELECT PCO.PER_ID, PCO.ORG_ID, PCO.PCO_PER_ID, PCO.PCO_RELATION, PER.PER_CHI_NAME PCO_CHI_NAME, PER.PER_TEL PCO_TEL, PER.PER_EMAIL PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE " +
					"			FROM EM_PCO_PERSONAL_CONTACT PCO, EM_PER_PERSONAL_PARTICULAR PER " +
					"			WHERE PCO.PCO_STATUS = 'Y' AND PER.PER_STATUS = 'Y' " +
					"			AND PCO.PCO_PER_ID = PER.PER_ID AND PCO.ORG_ID = PER.ORG_ID) PCO " +
					"			ON PER.PER_ID = PCO.PER_ID AND PER.ORG_ID = PCO.ORG_ID " +
					"	  WHERE PER.PER_ID = QUO.PER_ID AND PER.ORG_ID = QUO.ORG_ID " + 
					"	  AND BED_STATUS = 'Y' AND QUO.ORG_ID = BED.ORG_ID AND QUO.ZON_ID = BED.ZON_ID AND QUO.BED_ID = BED.BED_ID " + 
					"	  AND ZON_STATUS = 'Y' AND BED.ORG_ID = ZON.ORG_ID AND BED.ZON_ID = ZON.ZON_ID " + 
					"	  AND PER.ORG_ID = ? AND PER.PER_ID = ? " +  
					"	  ORDER BY QUO.QUO_MOD_DATE DESC, PCO.PCO_SEQ ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			pst.setInt(pos++, Integer.parseInt(quoGrpBean.getEnqPerId()));

			rs = pst.executeQuery();
			quoGrpBean.setQuoBeanList(new ArrayList<QuoBean>());
			while(rs.next()){
				String perId = rs.getString("PER_ID");
				String pcoPerId = rs.getString("PCO_PER_ID");
				String quoId = rs.getString("QUO_ID");
				String orgId = rs.getString("ORG_ID");
				
				for(int i=0;i<quoGrpBean.getFields().size();i++) {
					quoGrpBean.getFields().get(i).setFormValue(rs.getString(quoGrpBean.getFields().get(i).getName()));
				}

				if(pcoPerId != null && pcoPerId.length() >0) {
					PcoBean pcoBean = quoGrpBean.getPcoBean(pcoPerId, orgId);

					if(pcoBean==null) {
						pcoBean = new PcoBean();
						for(int i=0;i<pcoBean.getFields().size();i++) {
							pcoBean.getFields().get(i).setFormValue(rs.getString(pcoBean.getFields().get(i).getName()));
						}
						pcoBean.getPerBean().setPerId(pcoPerId);
						pcoBean.getPerBean().setOrgId(orgId);
						pcoBean.getPerBean().getField("PER_CHI_NAME").setValue((rs.getString("PCO_CHI_NAME")));
						pcoBean.getPerBean().getField("PER_TEL").setValue(rs.getString("PCO_TEL"));
						pcoBean.getPerBean().getField("PER_EMAIL").setValue(rs.getString("PCO_EMAIL"));
						
						quoGrpBean.addPcoBeanList(pcoBean);
					}
				}
				
				QuoBean quoBean = quoGrpBean.getQuoBean(quoId, orgId);
				if(quoBean == null && quoId != null && quoId.length()>0) {
					quoBean = new QuoBean();
					for(int i=0;i<quoBean.getFields().size();i++) {
						quoBean.getFields().get(i).setFormValue(rs.getString(quoBean.getFields().get(i).getName()));
					}
					quoGrpBean.addQuoBeanList(quoBean);
				
					BedBean bedBean = quoBean.getBedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				}
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}
		
	public ResGrpBean performEnqEmptyBed(ResGrpBean resGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			resGrpBean.setEmptyBedBeanList(new ArrayList<BedBean>());

			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT ZON.ORG_ID, ZON.ZON_ID, ZON.ZON_NAME, ZON.ZON_STATUS, ZON.ZON_MOD_BY, ZON.ZON_MOD_DATE, " + 
					"					BED.BED_ID, BED.BED_NAME, BED.BED_STATUS, BED.BED_MOD_BY, BED.BED_MOD_DATE " + 
					"					FROM EM_BED_INFO BED, EM_ZON_ZONE ZON " + 
					"					WHERE NOT EXISTS (SELECT 1 FROM EM_LIV_RECORD LIV WHERE BED.ZON_ID = LIV.ZON_ID AND BED.BED_ID = LIV.BED_ID AND BED.ORG_ID = LIV.ORG_ID AND LIV.LIV_STATUS = 'Y') " + 
					"					AND BED.ORG_ID = ZON.ORG_ID AND BED.ZON_ID = ZON.ZON_ID AND ZON.ZON_STATUS = 'Y' " +
					"					AND BED.ORG_ID = ? AND BED.BED_STATUS = 'Y' " +
					"					ORDER BY ZON.ZON_ID, BED.BED_ID ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			rs = pst.executeQuery();
			while(rs.next()){
				BedBean bedBean = new BedBean();
				for(int i=0;i<bedBean.getFields().size();i++) {
					bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
				}
				resGrpBean.addEmptyBedBeanList(bedBean);
				
				bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}


	public ResGrpBean performEnqPerDetail(ResGrpBean resGrpBean, UserBean userBean) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			String sql = "SELECT PER_ID, ORG_ID, PER_CHI_NAME, PER_ENG_NAME, PER_HKID, PER_GENDER, PER_NBIRTH, PER_LBIRTH, PER_TEL, PER_EMAIL, PER_DESC, PER_NATURE, PER_IMAGE_LINK, PER_LDS_REF, PER_LDS_RESULT, PER_LDS_DATE, PER_ASS1, PER_ASS2, PER_ASS2_OTH, PER_ASS3, PER_ASS3_OTH, PER_ASS4, PER_REFERAL, PER_REFERAL_OTH, BAN_ID, PER_BANK_ACC_NO, PER_BANK_ACC_NAME, PER_STATUS, PER_MOD_BY, PER_MOD_DATE, " + 
					"					RES_ID, RES_START_DATE, RES_END_DATE, RES_LIVING_FEE, RES_NURSING_FEE, RES_ADD_LIVING_FEE, RES_TYPE, RES_PDF_FILE, RES_STATUS, RES_MOD_BY, RES_MOD_DATE, " + 
					"					ZON.ZON_NAME, BED.ZON_ID, BED_ID, BED_NAME, BED_STATUS, BED_MOD_BY, BED_MOD_DATE, " +
					"                   PCO_PER_ID, PCO_RELATION, PCO_CHI_NAME, PCO_TEL, PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE " + 
					"	  FROM EM_RES_RECORD RES, EM_BED_INFO BED, EM_ZON_ZONE ZON, EM_PER_PERSONAL_PARTICULAR PER LEFT JOIN " +
					"			(SELECT PCO.PER_ID, PCO.ORG_ID, PCO.PCO_PER_ID, PCO.PCO_RELATION, PER.PER_CHI_NAME PCO_CHI_NAME, PER.PER_TEL PCO_TEL, PER.PER_EMAIL PCO_EMAIL, PCO_SEQ, PCO_STATUS, PCO_MOD_BY, PCO_MOD_DATE " +
					"			FROM EM_PCO_PERSONAL_CONTACT PCO, EM_PER_PERSONAL_PARTICULAR PER " +
					"			WHERE PCO.PCO_STATUS = 'Y' AND PER.PER_STATUS = 'Y' " +
					"			AND PCO.PCO_PER_ID = PER.PER_ID AND PCO.ORG_ID = PER.ORG_ID) PCO " +
					"			ON PER.PER_ID = PCO.PER_ID AND PER.ORG_ID = PCO.ORG_ID " +
					"	  WHERE PER.PER_ID = RES.PER_ID AND PER.ORG_ID = RES.ORG_ID " + 
					"	  AND BED_STATUS = 'Y' AND RES.ORG_ID = BED.ORG_ID AND RES.ZON_ID = BED.ZON_ID AND RES.BED_ID = BED.BED_ID " + 
					"	  AND ZON_STATUS = 'Y' AND BED.ORG_ID = ZON.ORG_ID AND BED.ZON_ID = ZON.ZON_ID " + 
					"	  AND PER.ORG_ID = ? AND PER.PER_ID = ? " +  
					"	  ORDER BY RES.RES_MOD_DATE DESC, PCO.PCO_SEQ ";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(userBean.getAccOrgId()));
			if(resGrpBean.getEnqPerId()!=null && resGrpBean.getEnqPerId().length()>0)
				pst.setInt(pos++, Integer.parseInt(resGrpBean.getEnqPerId()));
			else
				pst.setInt(pos++, Integer.parseInt(resGrpBean.getPerId()));
			
			rs = pst.executeQuery();
			resGrpBean.setResBeanList(new ArrayList<ResBean>());
			while(rs.next()){
				String perId = rs.getString("PER_ID");
				String pcoPerId = rs.getString("PCO_PER_ID");
				String resId = rs.getString("RES_ID");
				String orgId = rs.getString("ORG_ID");
				
				for(int i=0;i<resGrpBean.getFields().size();i++) {
					resGrpBean.getFields().get(i).setFormValue(rs.getString(resGrpBean.getFields().get(i).getName()));
				}

				if(pcoPerId != null && pcoPerId.length() >0) {
					PcoBean pcoBean = resGrpBean.getPcoBean(pcoPerId, orgId);

					if(pcoBean==null) {
						pcoBean = new PcoBean();
						for(int i=0;i<pcoBean.getFields().size();i++) {
							pcoBean.getFields().get(i).setFormValue(rs.getString(pcoBean.getFields().get(i).getName()));
						}
						pcoBean.getPerBean().setPerId(pcoPerId);
						pcoBean.getPerBean().setOrgId(orgId);
						pcoBean.getPerBean().getField("PER_CHI_NAME").setValue((rs.getString("PCO_CHI_NAME")));
						pcoBean.getPerBean().getField("PER_TEL").setValue(rs.getString("PCO_TEL"));
						pcoBean.getPerBean().getField("PER_EMAIL").setValue(rs.getString("PCO_EMAIL"));
						
						resGrpBean.addPcoBeanList(pcoBean);
					}
				}
				
				ResBean resBean = resGrpBean.getResBean(resId, orgId);
				if(resBean == null && resId != null && resId.length()>0) {
					resBean = new ResBean();
					for(int i=0;i<resBean.getFields().size();i++) {
						resBean.getFields().get(i).setFormValue(rs.getString(resBean.getFields().get(i).getName()));
					}
					resGrpBean.addResBeanList(resBean);
				
					BedBean bedBean = resBean.getBedBean();
					for(int i=0;i<bedBean.getFields().size();i++) {
						bedBean.getFields().get(i).setFormValue(rs.getString(bedBean.getFields().get(i).getName()));
					}
					bedBean.setBedFullName(rs.getString("ZON_NAME"), rs.getString("BED_NAME"));
				}
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}
		
	
	public String getNextPerId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String perId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(PER_ID)+1 NEW_PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_PER_ID")!=null)
	        		perId = rs.getString("NEW_PER_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perId;
	}	
		
	public String getNextQuoId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String quoId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(QUO_ID)+1 NEW_QUO_ID FROM EM_QUO_RECORD WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_QUO_ID")!=null)
	        		quoId = rs.getString("NEW_QUO_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoId;
	}	
	
	public String getNextResId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String resId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(RES_ID)+1 NEW_RES_ID FROM EM_RES_RECORD WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_RES_ID")!=null)
	        		resId = rs.getString("NEW_RES_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resId;
	}	
	
	public String getNextTransId(String orgId) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String transId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(TRA_ID)+1 NEW_TRA_ID FROM EM_TRA_TRANSACTIONS WHERE ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_TRA_ID")!=null)
	        		transId = rs.getString("NEW_TRA_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return transId;
	}	
	
	public String getNextTraReceiptId(String orgId, String traStatus) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		String traReceiptId = "100001";
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT MAX(TRA_RECEIPT_ID)+1 NEW_TRA_RECEIPT_ID FROM EM_TRA_TRANSACTIONS WHERE ORG_ID = ? AND TRA_TYPE = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(orgId));
			pst.setString(pos++, traStatus);
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("NEW_TRA_RECEIPT_ID")!=null)
	        		traReceiptId = rs.getString("NEW_TRA_RECEIPT_ID");
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return traReceiptId;
	}	
		
	
	public QuoGrpBean performAddQuote(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			QuoBean quoBean = quoGrpBean.getQuoBeanList().get(0);
			pos = 1;
			String sql = "INSERT INTO EM_QUO_RECORD QUO ( ";
					for(int i=0;i<EmsDB.EM_QUO_RECORD.length-1;i++) {
						if(i != EmsDB.EM_QUO_RECORD.length-2)
							sql = sql + EmsDB.EM_QUO_RECORD[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_QUO_RECORD[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_QUO_RECORD.length-1;i++) {
						if(i != EmsDB.EM_QUO_RECORD.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_QUO_RECORD.length-1;i++) {
				
				if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				quoGrpBean.setMsg("不能新加報價");
			}
					
		}catch(SQLException se){
			quoGrpBean.setMsg("不能新加報價");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能新加報價");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}		

	public QuoGrpBean performModQuote(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			QuoBean quoBean = quoGrpBean.getQuoBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_QUO_RECORD QUO SET ";
					for(int i=2;i<EmsDB.EM_QUO_RECORD.length-1;i++) {
						if(i != EmsDB.EM_QUO_RECORD.length-2)
							sql = sql + EmsDB.EM_QUO_RECORD[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_QUO_RECORD[i][0] + " = ? ";
					}
					sql = sql + "WHERE QUO.QUO_ID = ? AND QUO.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_QUO_RECORD.length-1;i++) {
				
				if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else if(EmsDB.EM_QUO_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)quoBean.getField(EmsDB.EM_QUO_RECORD[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(quoBean.getQuoId()));
			pst.setInt(pos++, Integer.parseInt(quoBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				quoGrpBean.setMsg("不能更新報價");
			}
		}catch(SQLException se){
			quoGrpBean.setMsg("不能更新報價");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能更新報價");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}	

	public QuoGrpBean performInactQuote(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			QuoBean quoBean = quoGrpBean.getQuoBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_QUO_RECORD QUO SET QUO_STATUS = 'N' WHERE QUO.PER_ID = ? AND QUO.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(quoBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(quoBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				quoGrpBean.setMsg("不能更新報價");
			}
		}catch(SQLException se){
			quoGrpBean.setMsg("不能更新報價");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能更新報價");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}	
	
	public ResGrpBean performQuoToRes(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			QuoBean quoBean = resGrpBean.getQuoBeanList().get(0);
			
			//update Bed 
			String sql = "UPDATE EM_QUO_RECORD QUO SET QUO_STATUS = 'C' WHERE QUO.QUO_ID = ? AND QUO.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(quoBean.getQuoId()));
			pst.setInt(pos++, Integer.parseInt(quoBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				resGrpBean.setMsg("不能完成報價");
			}
		}catch(SQLException se){
			resGrpBean.setMsg("不能完成報價");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能完成報價");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}	
	
	public PatGrpBean performQuoToLiv(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			QuoBean quoBean = patGrpBean.getQuoBeanList().get(0);
			
			//update Bed 
			String sql = "UPDATE EM_QUO_RECORD QUO SET QUO_STATUS = 'C' WHERE QUO.PER_ID = ? AND QUO.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(quoBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(quoBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能完成報價");
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能完成報價");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能完成報價");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
	
	public ResGrpBean performAddRes(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();

			ResBean resBean = resGrpBean.getResBeanList().get(0);
			pos = 1;
			String sql = "INSERT INTO EM_RES_RECORD RES ( ";
					for(int i=0;i<EmsDB.EM_RES_RECORD.length-1;i++) {
						if(i != EmsDB.EM_RES_RECORD.length-2)
							sql = sql + EmsDB.EM_RES_RECORD[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_RES_RECORD[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_RES_RECORD.length-1;i++) {
						if(i != EmsDB.EM_RES_RECORD.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_RES_RECORD.length-1;i++) {
				
				if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				resGrpBean.setMsg("不能新加訂位");
			}else if(resGrpBean.getTransBean().getField("TRA_AMOUNT").getFormValue().length()>0 && ((BigDecimal)resGrpBean.getTransBean().getField("TRA_AMOUNT").getValue()).intValue()>0) {
				TransBean transBean = resGrpBean.getTransBean();
				transBean.setTransId(getNextTransId(userBean.getAccOrgId()));
				transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "R"));
				pos = 1;
				sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
						for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
							if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
								sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
							else
								sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
						}
						for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
							if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
								sql = sql + "?, ";
							else
								sql = sql + "?) ";
						}

				pst = conn.prepareStatement(sql);
				
				for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
					
					if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else
						pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
				}
				row = pst.executeUpdate();
				if (row != 1)
				{
					resGrpBean.setMsg("不能新加訂位");
				}
			}
					
		}catch(SQLException se){
			resGrpBean.setMsg("不能新加訂位");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能新加訂位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}		

	public ResGrpBean performModRes(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			ResBean resBean = resGrpBean.getResBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_RES_RECORD RES SET ";
					for(int i=2;i<EmsDB.EM_RES_RECORD.length-1;i++) {
						if(i != EmsDB.EM_RES_RECORD.length-2)
							sql = sql + EmsDB.EM_RES_RECORD[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_RES_RECORD[i][0] + " = ? ";
					}
					sql = sql + "WHERE RES.RES_ID = ? AND RES.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_RES_RECORD.length-1;i++) {
				
				if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else if(EmsDB.EM_RES_RECORD[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getValue());
				else
					pst.setString(pos++, (String)resBean.getField(EmsDB.EM_RES_RECORD[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
			pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				resGrpBean.setMsg("不能更新訂位");
			}else if(resGrpBean.getTransBean().getField("TRA_AMOUNT").getFormValue().length()>0 && ((BigDecimal)resGrpBean.getTransBean().getField("TRA_AMOUNT").getValue()).intValue()>0){
				TransBean transBean = resGrpBean.getTransBean();
				transBean.setTransId(getNextTransId(userBean.getAccOrgId()));
				transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "R"));
				pos = 1;
				sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
						for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
							if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
								sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
							else
								sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
						}
						for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
							if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
								sql = sql + "?, ";
							else
								sql = sql + "?) ";
						}

				pst = conn.prepareStatement(sql);
				
				for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
					
					if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
						pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
					}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
						pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
						pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
						pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
					else
						pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
				}
				row = pst.executeUpdate();
				if (row != 1)
				{
					resGrpBean.setMsg("不能更新訂位");
				}
			}
		}catch(SQLException se){
			resGrpBean.setMsg("不能更新訂位");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能更新訂位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}	

	public ResGrpBean performInactRes(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			ResBean resBean = resGrpBean.getResBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_RES_RECORD RES SET RES_STATUS = 'N' WHERE RES.RES_ID = ? AND RES.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
			pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				resGrpBean.setMsg("不能取消訂位");
			}else {
				pos = 1;
				sql = "SELECT TRA_ID, ORG_ID, PER_ID, RES_ID, TRA_AMOUNT FROM EM_TRA_TRANSACTIONS WHERE RES_ID = ? AND ORG_ID = ? AND TRA_STATUS ='Y' ";
				pst = conn.prepareStatement(sql);
				pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
				pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
				rs = pst.executeQuery();
				BigDecimal resAmt = new BigDecimal(0);
		        while(rs.next()){
					if(rs.getBigDecimal("TRA_AMOUNT")!=null)
						resAmt = resAmt.add(rs.getBigDecimal("TRA_AMOUNT"));
					String traId = rs.getString("TRA_ID");
					
					pos = 1;
					sql = "UPDATE EM_TRA_TRANSACTIONS TRA SET TRA_STATUS = 'C' WHERE TRA.TRA_ID = ? AND TRA.ORG_ID = ?";
					pst = conn.prepareStatement(sql);
					pst.setInt(pos++, Integer.parseInt(traId));
					pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
					row = pst.executeUpdate();
					if (row < 0)
					{
						resGrpBean.setMsg("不能退回訂金");
					}	
		        	
		        }
		        
		        TransBean transBean = resGrpBean.getTransBean();
			    if(transBean.getField("TRA_AMOUNT").getFormValue().length()>0 && ((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).intValue()!=0) {
			        transBean.setTransId(getNextTransId(userBean.getAccOrgId()));
					transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "R"));
					BigDecimal rtnAmount = (BigDecimal)transBean.getField("TRA_AMOUNT").getValue();
					
					resAmt = resAmt.add(rtnAmount);
					pos = 1;
					sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
								else
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
							}
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + "?, ";
								else
									sql = sql + "?) ";
							}
	
					pst = conn.prepareStatement(sql);
					
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						
						if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
							pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
						}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
							pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
							pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
							pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else
							pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
					}
					row = pst.executeUpdate();
					if (row != 1)
					{
						resGrpBean.setMsg("不能退回訂金");
					}
					PDFUtil.genDownPaymentSlip(resGrpBean, userBean);

		        }
				
			if(resAmt.intValue() != 0) {
					transBean.setTransId(getNextTransId(userBean.getAccOrgId()));
					transBean.getField("TRA_NAME").setFormValue("取消訂金");
					transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "R"));
					transBean.getField("TRA_AMOUNT").setValue((new BigDecimal(0)).subtract(resAmt));
					transBean.getField("TRA_METHOD").setFormValue("");
					PatDB patDB = new PatDB();
					transBean.getField("TRA_PDF_FILE").setFormValue("file/org" + userBean.getAccOrgId() + "/per"+resGrpBean.getPerId()+"/pdf/"+patDB.getNextPdfId(userBean.getAccOrgId())+".pdf");

					pos = 1;
					sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
								else
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
							}
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + "?, ";
								else
									sql = sql + "?) ";
							}
	
					pst = conn.prepareStatement(sql);
					
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						
						if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
							pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
						}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
							pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
							pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
							pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else
							pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
					}
					row = pst.executeUpdate();
					if (row != 1)
					{
						resGrpBean.setMsg("不能取消訂金");
					}
					PDFUtil.genDownPaymentSlip(resGrpBean, userBean);
				}
				
			}
		}catch(SQLException se){
			resGrpBean.setMsg("不能取消訂位");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能取消訂位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}	
	
	public PatGrpBean performResToLiv(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			PatDB patDB = new PatDB();
			conn = DBUtil.getDataSource().getConnection();
			ResBean resBean = patGrpBean.getResBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_RES_RECORD RES SET RES_STATUS = 'C' WHERE RES.RES_ID = ? AND RES.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
			pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能取消訂位");
			}

		}catch(SQLException se){
			patGrpBean.setMsg("不能取消訂位");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能取消訂位");
			e.printStackTrace();
	    } finally {
	        try {
	            if (conn != null && !conn.isClosed()) {
	                conn.close();
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	        try {
	        	pst.close();
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }
		
		return patGrpBean;
	}		

	public PatGrpBean performReturnTrans(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		TransBean transBean = patGrpBean.getTransBean();
		try {
			PatDB patDB = new PatDB();
			conn = DBUtil.getDataSource().getConnection();
			//update Bed 
			String sql = "SELECT TRA_ID, ORG_ID, PER_ID, RES_ID, TRA_AMOUNT FROM EM_TRA_TRANSACTIONS WHERE PER_ID = ? AND ORG_ID = ? AND TRA_TYPE = ? AND TRA_STATUS ='Y' ";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(patGrpBean.getOrgId()));
			pst.setString(pos++, transBean.getField("TRA_TYPE").getFormValue());
			rs = pst.executeQuery();
				
			BigDecimal resAmt = new BigDecimal(0);
			String perId = "";
	        while(rs.next()){
				if(rs.getBigDecimal("TRA_AMOUNT")!=null)
					resAmt = resAmt.add(rs.getBigDecimal("TRA_AMOUNT"));
				if(rs.getString("PER_ID")!=null)
					perId = rs.getString("PER_ID");
				String traId = rs.getString("TRA_ID");
					
				pos = 1;
				sql = "UPDATE EM_TRA_TRANSACTIONS TRA SET TRA_STATUS = 'C' WHERE TRA.TRA_ID = ? AND TRA.ORG_ID = ?";
				pst = conn.prepareStatement(sql);
				pst.setInt(pos++, Integer.parseInt(traId));
				pst.setInt(pos++, Integer.parseInt(patGrpBean.getOrgId()));
				int row = pst.executeUpdate();
				if (row < 0)
				{
					patGrpBean.setMsg("不能退款");
				}	
		        	
		    }
		        
			Calendar calendar = Calendar.getInstance();

			if(resAmt.intValue() != 0) {
				transBean.setTransId(getNextTransId(userBean.getAccOrgId()));
				transBean.getField("TRA_AMOUNT").setValue((new BigDecimal(0)).subtract(resAmt));
				transBean.getField("TRA_PDF_FILE").setFormValue("file/org" + userBean.getAccOrgId() + "/per"+patGrpBean.getPerId()+"/pdf/"+patDB.getNextPdfId(userBean.getAccOrgId())+".pdf");
				transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), transBean.getField("TRA_TYPE").getFormValue()));
				transBean.getField("TRA_STATUS").setValue("C");
				
					pos = 1;
					sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
								else
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
							}
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + "?, ";
								else
									sql = sql + "?) ";
							}
	
					pst = conn.prepareStatement(sql);
					
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						
						if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
							pst.setObject(pos++, (Integer)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
						}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
							pst.setDate(pos++, (Date)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
							pst.setBigDecimal(pos++, (BigDecimal)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
							pst.setTimestamp(pos++, (Timestamp)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else
							pst.setString(pos++, (String)transBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
					}
					int row = pst.executeUpdate();
					if (row != 1)
					{
						patGrpBean.setMsg("不能退款");
					}else if(transBean.getField("TRA_TYPE").getFormValue().equals("D")){
						patDB.performAddOrUpdAccDeposit(patGrpBean, userBean);
					}			        
				}
				
		}catch(SQLException se){
			patGrpBean.setMsg("不能退款");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能退款");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	

	
	public PatGrpBean performResToLivWithDepositHandle(PatGrpBean patGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			PatDB patDB = new PatDB();
			conn = DBUtil.getDataSource().getConnection();
			ResBean resBean = patGrpBean.getResBeanList().get(0);
			//update Bed 
			String sql = "UPDATE EM_RES_RECORD RES SET RES_STATUS = 'C' WHERE RES.RES_ID = ? AND RES.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
			pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row < 0)
			{
				patGrpBean.setMsg("不能取消訂位");
			}else {
				pos = 1;
				sql = "SELECT TRA_ID, ORG_ID, PER_ID, RES_ID, TRA_AMOUNT FROM EM_TRA_TRANSACTIONS WHERE RES_ID = ? AND ORG_ID = ? AND TRA_STATUS ='Y' ";
				pst = conn.prepareStatement(sql);
				pst.setInt(pos++, Integer.parseInt(resBean.getResId()));
				pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
				rs = pst.executeQuery();
				BigDecimal resAmt = new BigDecimal(0);
				String perId = "";
		        while(rs.next()){
					if(rs.getBigDecimal("TRA_AMOUNT")!=null)
						resAmt = resAmt.add(rs.getBigDecimal("TRA_AMOUNT"));
					if(rs.getString("PER_ID")!=null)
						perId = rs.getString("PER_ID");
					String traId = rs.getString("TRA_ID");
					
					pos = 1;
					sql = "UPDATE EM_TRA_TRANSACTIONS TRA SET TRA_STATUS = 'C' WHERE TRA.TRA_ID = ? AND TRA.ORG_ID = ?";
					pst = conn.prepareStatement(sql);
					pst.setInt(pos++, Integer.parseInt(traId));
					pst.setInt(pos++, Integer.parseInt(resBean.getOrgId()));
					row = pst.executeUpdate();
					if (row < 0)
					{
						patGrpBean.setMsg("不能退回訂金");
					}	
		        	
		        }
		        
				Calendar calendar = Calendar.getInstance();

				if(resAmt.intValue() != 0) {
					TransBean resTransBean = new TransBean();
					resTransBean.setTransId(getNextTransId(userBean.getAccOrgId()));
					resTransBean.setOrgId(userBean.getAccOrgId());
					resTransBean.setPerId(patGrpBean.getPerId());
					resTransBean.getField("RES_ID").setFormValue(resBean.getResId());
					resTransBean.getField("LIV_ID").setFormValue(patGrpBean.getLivBeanList().get(0).getLivId());
					resTransBean.getField("TRA_NAME").setFormValue("退回訂金");
					resTransBean.getField("TRA_TYPE").setFormValue("R");
					resTransBean.getField("TRA_DATE").setValue( new java.sql.Date(calendar.getTime().getTime()));
					resTransBean.getField("TRA_AMOUNT").setValue((new BigDecimal(0)).subtract(resAmt));
					resTransBean.getField("TRA_PDF_FILE").setFormValue("file/org" + userBean.getAccOrgId() + "/per"+patGrpBean.getPerId()+"/pdf/"+patDB.getNextPdfId(userBean.getAccOrgId())+".pdf");
					resTransBean.getField("TRA_METHOD").setFormValue("");
					resTransBean.getField("TRA_NOTE").setFormValue("訂金轉按金");
					resTransBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "R"));
					resTransBean.getField("TRA_STATUS").setValue("C");
					resTransBean.getField("TRA_MOD_BY").setValue(userBean.getUserId());
					
					pos = 1;
					sql = "INSERT INTO EM_TRA_TRANSACTIONS TRA ( ";
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ", ";
								else
									sql = sql + EmsDB.EM_TRA_TRANSACTIONS[i][0] + ") VALUES ( ";
							}
							for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
								if(i != EmsDB.EM_TRA_TRANSACTIONS.length-2)
									sql = sql + "?, ";
								else
									sql = sql + "?) ";
							}
	
					pst = conn.prepareStatement(sql);
					
					for(int i=0;i<EmsDB.EM_TRA_TRANSACTIONS.length-1;i++) {
						
						if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Integer")) {
							pst.setObject(pos++, (Integer)resTransBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue(), java.sql.Types.INTEGER);
						}else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Date"))
							pst.setDate(pos++, (Date)resTransBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("BigDecimal"))
							pst.setBigDecimal(pos++, (BigDecimal)resTransBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else if(EmsDB.EM_TRA_TRANSACTIONS[i][2].equalsIgnoreCase("Timestamp"))
							pst.setTimestamp(pos++, (Timestamp)resTransBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getValue());
						else
							pst.setString(pos++, (String)resTransBean.getField(EmsDB.EM_TRA_TRANSACTIONS[i][0]).getFormValue());
					}
					row = pst.executeUpdate();
					if (row != 1)
					{
						patGrpBean.setMsg("不能取消訂金");
					} else {
						//gen withdrawal slip
						ResGrpBean resGrpBean = new ResGrpBean();
						resGrpBean.setOrgId(patGrpBean.getOrgId());
						resGrpBean.getField("PER_CHI_NAME").setFormValue(patGrpBean.getField("PER_CHI_NAME").getFormValue());
						resGrpBean.setTransBean(resTransBean);
						PDFUtil.genDownPaymentSlip(resGrpBean, userBean);
					}
					
			        TransBean transBean = patGrpBean.getTransBean();
					transBean.getField("TRA_PDF_FILE").setFormValue("file/org" + userBean.getAccOrgId() + "/per"+patGrpBean.getPerId()+"/pdf/"+patDB.getNextPdfId(userBean.getAccOrgId())+".pdf");
					transBean.getField("RES_ID").setFormValue(resBean.getResId());
					
					if(transBean.getField("TRA_AMOUNT").getFormValue().length() == 0 || ((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).intValue() == 0) {
						transBean.getField("TRA_AMOUNT").setValue(resAmt);	

					}else {
						transBean.getField("TRA_RECEIPT_ID").setFormValue(getNextTraReceiptId(userBean.getAccOrgId(), "D"));
						transBean.getField("TRA_AMOUNT").setValue(((BigDecimal)transBean.getField("TRA_AMOUNT").getValue()).add(resAmt));
					}
			        
				}
				
			}
		}catch(SQLException se){
			patGrpBean.setMsg("不能取消訂位");
			se.printStackTrace();
		}catch(Exception e){
			patGrpBean.setMsg("不能取消訂位");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return patGrpBean;
	}	
	

	public PerBean getPerBeanByNameTel(PerBean perBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "SELECT PER_ID FROM EM_PER_PERSONAL_PARTICULAR WHERE ORG_ID = ? AND PER_CHI_NAME = ? AND PER_TEL = ?";
			
			pst = conn.prepareStatement(sql);
			pst.setInt(pos++, Integer.parseInt(perBean.getOrgId()));
			pst.setString(pos++, perBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, perBean.getField("PER_TEL").getFormValue());
			rs = pst.executeQuery();
	        while(rs.next()){
	        	if(rs.getString("PER_ID")!=null)
	        		perBean.setPerId(rs.getString("PER_ID"));
	        }
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return perBean;
	}	
	
	public QuoGrpBean performAddPer(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PER ( ";
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				quoGrpBean.setMsg("不能新增院友");
			}
			
		}catch(SQLException se){
			quoGrpBean.setMsg("不能新增院友");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能新增院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}			
	
	public ResGrpBean performAddPer(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PER ( ";
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				resGrpBean.setMsg("不能新增院友");
			}
			
		}catch(SQLException se){
			resGrpBean.setMsg("不能新增院友");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能新增院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}			
	
	public PerBean performAddPcoPer(PerBean pcoPerBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PER_PERSONAL_PARTICULAR PAT (PER_ID, ORG_ID, PER_CHI_NAME, PER_TEL, PER_EMAIL, PER_NATURE, PER_STATUS, PER_MOD_BY) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ";

			pst = conn.prepareStatement(sql);
			
			pst.setObject(pos++, (Integer)pcoPerBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)pcoPerBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);
			pst.setString(pos++, pcoPerBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_TEL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_EMAIL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_NATURE").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_STATUS").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_MOD_BY").getFormValue());
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoPerBean.setMsg("不能新增連絡人");
			}
			
		}catch(SQLException se){
			pcoPerBean.setMsg("不能新增連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoPerBean.setMsg("不能新增連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoPerBean;
	}			
	
	public PcoBean performAddPco(PcoBean pcoBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			conn = DBUtil.getDataSource().getConnection();
			String sql = "INSERT INTO EM_PCO_PERSONAL_CONTACT PCO ( ";
					for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
						if(i != EmsDB.EM_PCO_PERSONAL_CONTACT.length-2)
							sql = sql + EmsDB.EM_PCO_PERSONAL_CONTACT[i][0] + ", ";
						else
							sql = sql + EmsDB.EM_PCO_PERSONAL_CONTACT[i][0] + ") VALUES ( ";
					}
					for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
						if(i != EmsDB.EM_PCO_PERSONAL_CONTACT.length-2)
							sql = sql + "?, ";
						else
							sql = sql + "?) ";
					}

			pst = conn.prepareStatement(sql);
			
			for(int i=0;i<EmsDB.EM_PCO_PERSONAL_CONTACT.length-1;i++) {
				
				if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else if(EmsDB.EM_PCO_PERSONAL_CONTACT[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getValue());
				else
					pst.setString(pos++, (String)pcoBean.getField(EmsDB.EM_PCO_PERSONAL_CONTACT[i][0]).getFormValue());
			}
			
			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoBean.setMsg("不能新增連絡人");
			}
			
		}catch(SQLException se){
			pcoBean.setMsg("不能新增連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoBean.setMsg("不能新增連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoBean;
	}			
	
	
	public QuoGrpBean performModPer(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET ";
					for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? ";
					}
					sql = sql + "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)quoGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(quoGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(quoGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				quoGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			quoGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}	

	public ResGrpBean performModPer(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET ";
					for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
						if(i != EmsDB.EM_PER_PERSONAL_PARTICULAR.length-2)
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? , ";
						else
							sql = sql + EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0] + " = ? ";
					}
					sql = sql + "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			for(int i=2;i<EmsDB.EM_PER_PERSONAL_PARTICULAR.length-1;i++) {
				
				if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Integer")) {
					pst.setObject(pos++, (Integer)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue(), java.sql.Types.INTEGER);
				}else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Date"))
					pst.setDate(pos++, (Date)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("BigDecimal"))
					pst.setBigDecimal(pos++, (BigDecimal)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else if(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][2].equalsIgnoreCase("Timestamp"))
					pst.setTimestamp(pos++, (Timestamp)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getValue());
				else
					pst.setString(pos++, (String)resGrpBean.getField(EmsDB.EM_PER_PERSONAL_PARTICULAR[i][0]).getFormValue());
			}
			
			pst.setInt(pos++, Integer.parseInt(resGrpBean.getPerId()));
			pst.setInt(pos++, Integer.parseInt(resGrpBean.getOrgId()));
			int row = pst.executeUpdate();
			if (row != 1)
			{
				resGrpBean.setMsg("不能更新院友");
			}
		}catch(SQLException se){
			resGrpBean.setMsg("不能更新院友");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能更新院友");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}	

	public PerBean performModPcoPer(PerBean pcoPerBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update personal particular 
			String sql = "UPDATE EM_PER_PERSONAL_PARTICULAR PER SET PER_CHI_NAME = ?, "
					+ "PER_TEL = ?, PER_EMAIL = ?, PER_STATUS = ?, PER_MOD_BY = ? "
					+ "WHERE PER.PER_ID = ? AND PER.ORG_ID = ?";
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(pos++, pcoPerBean.getField("PER_CHI_NAME").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_TEL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_EMAIL").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_STATUS").getFormValue());
			pst.setString(pos++, pcoPerBean.getField("PER_MOD_BY").getFormValue());
			pst.setObject(pos++, (Integer)pcoPerBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)pcoPerBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);

			int row = pst.executeUpdate();
			if (row != 1)
			{
				pcoPerBean.setMsg("不能更新連絡人");
			}
		}catch(SQLException se){
			pcoPerBean.setMsg("不能更新連絡人");
			se.printStackTrace();
		}catch(Exception e){
			pcoPerBean.setMsg("不能更新連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return pcoPerBean;
	}	

	public QuoGrpBean performCleanPco(QuoGrpBean quoGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Clean Existing Contact
			String sql = "DELETE FROM EM_PCO_PERSONAL_CONTACT PCO WHERE PCO.PER_ID = ? AND PCO.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			
			pst.setObject(pos++, (Integer)quoGrpBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)quoGrpBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);

			int row = pst.executeUpdate();
			if (row < 0)
			{
				quoGrpBean.setMsg("不能清除連絡人");
			}
		}catch(SQLException se){
			quoGrpBean.setMsg("不能清除連絡人");
			se.printStackTrace();
		}catch(Exception e){
			quoGrpBean.setMsg("不能清除連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return quoGrpBean;
	}	

	public ResGrpBean performCleanPco(ResGrpBean resGrpBean, UserBean userBean) {
		Connection conn = null;
		PreparedStatement pst = null;
		int pos = 1;
		
		try {
			
			conn = DBUtil.getDataSource().getConnection();
			//update Clean Existing Contact
			String sql = "DELETE FROM EM_PCO_PERSONAL_CONTACT PCO WHERE PCO.PER_ID = ? AND PCO.ORG_ID = ? ";
			
			pst = conn.prepareStatement(sql);
			
			pst.setObject(pos++, (Integer)resGrpBean.getField("PER_ID").getValue(), java.sql.Types.INTEGER);
			pst.setObject(pos++, (Integer)resGrpBean.getField("ORG_ID").getValue(), java.sql.Types.INTEGER);

			int row = pst.executeUpdate();
			if (row < 0)
			{
				resGrpBean.setMsg("不能清除連絡人");
			}
		}catch(SQLException se){
			resGrpBean.setMsg("不能清除連絡人");
			se.printStackTrace();
		}catch(Exception e){
			resGrpBean.setMsg("不能清除連絡人");
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
		
		return resGrpBean;
	}	
}
