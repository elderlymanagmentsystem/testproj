package ems.sch;

import java.io.File;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ems.util.DBUtil;
import ems.util.EmsCommonUtil;

public class HourlyJob implements Runnable {
@Override
	public void run() {	
		System.out.println("Job trigged by scheduler");
    	
    	Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			//---------------for PRD-------------//
			//conn = DBUtil.getDataSource().getConnection();
			
			//---------------for main test only-------------//
			Class.forName("org.hsqldb.jdbc.JDBCDriver");  
			String dbURL = "jdbc:hsqldb:hsql://localhost/EMS_DB";
	        String user = "SA";
	        String pass = "";
	        conn = DriverManager.getConnection(dbURL, user, pass);
	        //-----------------------------------------------//
			
			String sql = "SELECT * FROM EM_ROL_ROLE";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString("ROL_ID"));
			}
			
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            try {
        		rs.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
            	pst.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }



	public static void main(String [] args) throws SQLException, ClassNotFoundException {
		HourlyJob hourlyJob = new HourlyJob();
		hourlyJob.run();
	}
	
}
