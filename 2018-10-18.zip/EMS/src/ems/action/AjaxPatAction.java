package ems.action;

import java.util.ArrayList;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import ems.bean.PatBean;
import ems.bean.PatGrpBean;
import ems.bean.PcoBean;
import ems.bean.UserBean;
import ems.module.PatModule;

public class AjaxPatAction extends ActionSupport implements SessionAware {
	private PatGrpBean patGrpBean;
	private int enqPerId;
	private Map<String, Object> session;
	private String patId = "";
	private String perId = "";
	private String[] pcoChiName;
	private String[] pcoRel;
	private String[] pcoTel;
	private String[] pcoEmail;
	private String[] pcoSeq;
	private String livId = "";
	private String livType = "";
	private String livStartDate = "";
	private String livLivingFee = "";
	private String livNursingFee = "";
	private String livStatus = "";
	private String livZoneId = "";
	private String livBedId = "";
	private String bedFullName = "";
	private String perChiName = "";
	private String perEngName = "";
	private String perHKID = "";
	private String perGender = "";
	private String perNBirth = "";
	private String perLBirth = "";
	private String perTel = "";
	private String perEmail = "";
	private String perDesc = "";
	private String perImageLink = "";
	private String perLDSRef = "";
	private String perLDSResult = "";
	private String perLDSDate = "";
	private String perAss1 = "";
	private String perAss2 = "";
	private String perAss2Oth = "";
	private String perAss3 = "";
	private String perAss3Oth = "";
	private String perAss4 = "";
	private String perReferal = "";
	private String perReferalOth = "";
	
	public String execute() throws Exception {
		UserBean userBean = (UserBean)session.get("userBean");
		
		PatModule patMod = new PatModule();
		if(patGrpBean.getEnqPatId() != null && patGrpBean.getEnqPatId().length()>0)
			patMod.performEnqPatDetail(patGrpBean, userBean);
		
		if(patGrpBean.getPcoBeanList().size()>0) {
			ArrayList<String> pcoChiNameList = new ArrayList<String>();
			ArrayList<String> pcoTelList = new ArrayList<String>();
			ArrayList<String> pcoEmailList = new ArrayList<String>();
			ArrayList<String> pcoRelList = new ArrayList<String>();
			ArrayList<String> pcoSeqList = new ArrayList<String>();
			for(int i=0;i<patGrpBean.getPcoBeanList().size();i++) {
				PcoBean pcoBean = patGrpBean.getPcoBeanList().get(i);
				pcoChiNameList.add(pcoBean.getPerBean().getField("PER_CHI_NAME").getFormValue());
				pcoTelList.add(pcoBean.getPerBean().getField("PER_TEL").getFormValue());
				pcoEmailList.add(pcoBean.getPerBean().getField("PER_EMAIL").getFormValue());
				pcoRelList.add(pcoBean.getField("PCO_RELATION").getFormValue());
				pcoSeqList.add(pcoBean.getField("PCO_SEQ").getFormValue());
				setPcoChiName(pcoChiNameList.toArray(new String[0]));
				setPcoTel(pcoTelList.toArray(new String[0]));
				setPcoEmail(pcoEmailList.toArray(new String[0]));
				setPcoRel(pcoRelList.toArray(new String[0]));
				setPcoSeq(pcoSeqList.toArray(new String[0]));
				
			}
		}else {
			setPcoChiName(new String[] {""});
			setPcoTel(new String[] {""});
			setPcoEmail(new String[] {""});
			setPcoRel(new String[] {""});
			setPcoSeq(new String[] {""});
		}
		
		if(patGrpBean.getLivBeanList().size()>0) {
			setLivId(patGrpBean.getLivBeanList().get(0).getLivId());
			setLivType(patGrpBean.getLivBeanList().get(0).getField("LIV_TYPE").getFormValue());
			setLivStartDate(patGrpBean.getLivBeanList().get(0).getField("LIV_START_DATE").getFormValue());
			setLivLivingFee(patGrpBean.getLivBeanList().get(0).getField("LIV_LIVING_FEE").getFormValue());
			setLivNursingFee(patGrpBean.getLivBeanList().get(0).getField("LIV_NURSING_FEE").getFormValue());
			setLivStatus(patGrpBean.getLivBeanList().get(0).getField("LIV_STATUS").getFormValue());
			setLivZoneId(patGrpBean.getLivBeanList().get(0).getBedBean().getZoneId());
			setLivBedId(patGrpBean.getLivBeanList().get(0).getBedBean().getBedId());
			setBedFullName(patGrpBean.getLivBeanList().get(0).getBedBean().getBedFullName());
		}
		
		setPatId(patGrpBean.getPatId());
		setPerId(patGrpBean.getPerId());
		setPerChiName(patGrpBean.getField("PER_CHI_NAME").getFormValue());
		setPerEngName(patGrpBean.getField("PER_ENG_NAME").getFormValue());
		setPerHKID(patGrpBean.getField("PER_HKID").getFormValue());
		setPerGender(patGrpBean.getField("PER_GENDER").getFormValue());
		setPerImageLink(patGrpBean.getField("PER_IMAGE_LINK").getFormValue());
		setPerNBirth(patGrpBean.getField("PER_NBIRTH").getFormValue());
		setPerLBirth(patGrpBean.getField("PER_LBIRTH").getFormValue());
		setPerTel(patGrpBean.getField("PER_TEL").getFormValue());
		setPerEmail(patGrpBean.getField("PER_EMAIL").getFormValue());
		setPerDesc(patGrpBean.getField("PER_DESC").getFormValue());
		setPerLDSRef(patGrpBean.getField("PER_LDS_REF").getFormValue());
		setPerLDSResult(patGrpBean.getField("PER_LDS_RESULT").getFormValue());
		setPerLDSDate(patGrpBean.getField("PER_LDS_DATE").getFormValue());
		setPerAss1(patGrpBean.getField("PER_ASS1").getFormValue());
		setPerAss2(patGrpBean.getField("PER_ASS2").getFormValue());
		setPerAss2Oth(patGrpBean.getField("PER_ASS2_OTH").getFormValue());
		setPerAss3(patGrpBean.getField("PER_ASS3").getFormValue());
		setPerAss3Oth(patGrpBean.getField("PER_ASS3_OTH").getFormValue());
		setPerAss4(patGrpBean.getField("PER_ASS4").getFormValue());
		setPerReferal(patGrpBean.getField("PER_REFERAL").getFormValue());
		setPerReferalOth(patGrpBean.getField("PER_REFERAL_OTH").getFormValue());
		
		return SUCCESS;
	}
	
	public PatGrpBean getPatGrpBean() {
		return patGrpBean;
	}

	public void setPatGrpBean(PatGrpBean patGrpBean) {
		this.patGrpBean = patGrpBean;
	}
    
	public String[] getPcoChiName() {
		return pcoChiName;
	}

	public void setPcoChiName(String[] pcoChiName) {
		this.pcoChiName = pcoChiName;
	}

	public String[] getPcoRel() {
		return pcoRel;
	}

	public void setPcoRel(String[] pcoRel) {
		this.pcoRel = pcoRel;
	}

	public String[] getPcoTel() {
		return pcoTel;
	}

	public void setPcoTel(String[] pcoTel) {
		this.pcoTel = pcoTel;
	}

	public String[] getPcoSeq() {
		return pcoSeq;
	}

	public void setPcoSeq(String[] pcoSeq) {
		this.pcoSeq = pcoSeq;
	}

	
	public String getLivId() {
		return livId;
	}

	public void setLivId(String livId) {
		this.livId = livId;
	}

	public String getPerChiName() {
		return perChiName;
	}

	public void setPerChiName(String perChiName) {
		this.perChiName = perChiName;
	}

	public String getPerEngName() {
		return perEngName;
	}

	public void setPerEngName(String perEngName) {
		this.perEngName = perEngName;
	}

	public String getPerHKID() {
		return perHKID;
	}

	public void setPerHKID(String perHKID) {
		this.perHKID = perHKID;
	}

	public String getPerGender() {
		return perGender;
	}

	public void setPerGender(String perGender) {
		this.perGender = perGender;
	}

	public String getPerNBirth() {
		return perNBirth;
	}

	public void setPerNBirth(String perNBirth) {
		this.perNBirth = perNBirth;
	}

	public String getPerLBirth() {
		return perLBirth;
	}

	public void setPerLBirth(String perLBirth) {
		this.perLBirth = perLBirth;
	}

	public String getPerTel() {
		return perTel;
	}

	public void setPerTel(String perTel) {
		this.perTel = perTel;
	}

	public String getPerEmail() {
		return perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerDesc() {
		return perDesc;
	}

	public void setPerDesc(String perDesc) {
		this.perDesc = perDesc;
	}

	public String getLivZoneId() {
		return livZoneId;
	}

	public void setLivZoneId(String livZoneId) {
		this.livZoneId = livZoneId;
	}

	public String getLivBedId() {
		return livBedId;
	}

	public void setLivBedId(String livBedId) {
		this.livBedId = livBedId;
	}

	public String getBedFullName() {
		return bedFullName;
	}

	public void setBedFullName(String bedFullName) {
		this.bedFullName = bedFullName;
	}

	public String getLivType() {
		return livType;
	}

	public void setLivType(String livType) {
		this.livType = livType;
	}

	public String getLivStartDate() {
		return livStartDate;
	}

	public void setLivStartDate(String livStartDate) {
		this.livStartDate = livStartDate;
	}

	public String getLivLivingFee() {
		return livLivingFee;
	}

	public void setLivLivingFee(String livLivingFee) {
		this.livLivingFee = livLivingFee;
	}

	public String getLivNursingFee() {
		return livNursingFee;
	}

	public void setLivNursingFee(String livNursingFee) {
		this.livNursingFee = livNursingFee;
	}

	public String getPerLDSRef() {
		return perLDSRef;
	}

	public void setPerLDSRef(String perLDSRef) {
		this.perLDSRef = perLDSRef;
	}

	public String getPerLDSResult() {
		return perLDSResult;
	}

	public void setPerLDSResult(String perLDSResult) {
		this.perLDSResult = perLDSResult;
	}

	public String getPerLDSDate() {
		return perLDSDate;
	}

	public void setPerLDSDate(String perLDSDate) {
		this.perLDSDate = perLDSDate;
	}

	public String getPerAss1() {
		return perAss1;
	}

	public void setPerAss1(String perAss1) {
		this.perAss1 = perAss1;
	}

	public String getPerAss2() {
		return perAss2;
	}

	public void setPerAss2(String perAss2) {
		this.perAss2 = perAss2;
	}

	public String getPerAss2Oth() {
		return perAss2Oth;
	}

	public void setPerAss2Oth(String perAss2Oth) {
		this.perAss2Oth = perAss2Oth;
	}

	public String getPerAss3() {
		return perAss3;
	}

	public void setPerAss3(String perAss3) {
		this.perAss3 = perAss3;
	}

	public String getPerAss3Oth() {
		return perAss3Oth;
	}

	public void setPerAss3Oth(String perAss3Oth) {
		this.perAss3Oth = perAss3Oth;
	}

	public String getPerAss4() {
		return perAss4;
	}

	public void setPerAss4(String perAss4) {
		this.perAss4 = perAss4;
	}

	public String getPerReferal() {
		return perReferal;
	}

	public void setPerReferal(String perReferal) {
		this.perReferal = perReferal;
	}

	public String getPerReferalOth() {
		return perReferalOth;
	}

	public void setPerReferalOth(String perReferalOth) {
		this.perReferalOth = perReferalOth;
	}

	public String getPerImageLink() {
		return perImageLink;
	}

	public void setPerImageLink(String perImageLink) {
		this.perImageLink = perImageLink;
	}

	public String getPatId() {
		return patId;
	}

	public void setPatId(String patId) {
		this.patId = patId;
	}

	public String getPerId() {
		return perId;
	}

	public void setPerId(String perId) {
		this.perId = perId;
	}

	public String getLivStatus() {
		return livStatus;
	}

	public void setLivStatus(String livStatus) {
		this.livStatus = livStatus;
	}

	public String[] getPcoEmail() {
		return pcoEmail;
	}

	public void setPcoEmail(String[] pcoEmail) {
		this.pcoEmail = pcoEmail;
	}

	public int getEnqPerId() {
		return enqPerId;
	}

	public void setEnqPerId(int enqPerId) {
		this.enqPerId = enqPerId;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	
	
}
