package ems.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;


public class DataTypeUtil {

	static public Date formDate2BeanDate(String formDate) {
	    if (formDate != null && formDate.length() == 8){
	    	if(formDate.equals("00000000")){
	    		return null;
	    	}
	        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            try {
                java.util.Date d = dateFormat.parse(formDate);          
                return (new Date(d.getTime()));
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
	    } else if (formDate != null && formDate.length() == 10){
	        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            try {
                java.util.Date d = dateFormat.parse(formDate);          
                return (new Date(d.getTime()));
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
	    } else {
	        return null;
	    }
	}
	
	static public String beanDate2FormDate(Date beanDate) {
		if (beanDate == null) return "";

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");      
		return dateFormat.format(beanDate);
	}
	
	
	static public Integer formNumber2BeanNumber(String hostNum) {
		if (hostNum == null || hostNum.length() == 0) return null;
		return Integer.valueOf(hostNum);
	}
	
	static public String beanNumber2FormNumber(Integer beanNum) {
		if (beanNum == null) return "";
		return beanNum.toString();
	}
	
	static public BigDecimal formAmt2BeanAmt(String formAmt) {
		if (formAmt == null || formAmt.length() == 0) return null;
		return new BigDecimal(formAmt);
	}
	
	static public String beanAmt2FormAmt(BigDecimal beanAmt,boolean nullFlag) {
		if (beanAmt == null) 
		{
			if(nullFlag) return null;
			else return "";
		}
		else return beanAmt2FormAmt(beanAmt);
	}
		
	static public String beanAmt2FormAmt(BigDecimal beanAmt) {
		if (beanAmt == null) return "0";

		DecimalFormat df = new DecimalFormat("#0.00");
		return (df.format(beanAmt.doubleValue()));
	}

    static public Timestamp formTimestamp2BeanTimestamp (String formTimestamp) {
        if (formTimestamp == null || "0".equalsIgnoreCase(formTimestamp)) return null;
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        try {
            return new Timestamp(dateFormat.parse(formTimestamp).getTime());
        } catch (Exception e) {
            return null;
        }
    }	

	static public String beanRate2FormRate(BigDecimal beanRate) {
		if (beanRate == null) return "0";

		DecimalFormat df = new DecimalFormat("#0.000000");
		return (df.format(beanRate.doubleValue()));
	}

    static public String beanTimestamp2FormTimestamp(Timestamp t) {
        if (t == null) return null;
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        return dateFormat.format(t);
    }    
    
	
}
